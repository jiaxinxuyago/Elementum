# 03 · Ten-god templates (the ten personas and the 50 element × god cells)

_Elementum reading templates · review pack · generated 2026-09-17 from the station (Reading/Database/templates/by_axis/json). Read 00_READ_FIRST first._

Part A is the ten gods as the app names them (personas, one per god). Part B is the 50 cells where a god meets an element: the overview and functional line, the adjective chips, the three ruling-domain readings, and the keyword ledger (three keywords per pole, each with three "doors" the app rotates through). The app shows the reader only the cells for the gods actually present in their chart.

## Part A · The ten gods as personas

| God | Persona | Definition line | Keyword | Catalyst pole | Friction pole | Catalyst adjectives | Friction adjectives | Domains | Face teaser |
|---|---|---|---|---|---|---|---|---|---|
| 比肩 | The Twin | Same nature, same register — the standard you hold yourself to | Independence | Self-trust | Isolation | Self-reliant · Steady · Unshakeable | Walled-off · Solitary · Immovable | Peers · Independence · Self-reliance | You trust your own counsel first. Self-reliance is a strength — and, now and then, a wall others can’t get past. You begin without waiting for permission and finish without needing rescue. The art is knowing the moment standing alone costs more than it’s worth. |
| 劫财 | The Rival | Same nature, different register — the edge of comparison | Rivalry | Daring | Drain | Bold · Fired-up · Fearless | Combative · Envious · Reckless | Rivalry · Shared stakes · Boldness | You rise to a contest. Comparison sharpens you, though it can also spend the energy you meant to keep. Put an equal in front of you and you find a gear you forgot you had. Just watch that the race doesn’t cost more than the finish line pays. |
| 食神 | The Artisan | Output that flows from you — giving that feels like being | Flow | Grace | Coasting | Effortless · Warm · Generous | Coasting · Indulgent · Unchallenged | Expression · Enjoyment · Children | Ideas come easily and you give them away gladly. Creation, for you, is play before it is ever work. You make rooms lighter and tables fuller without seeming to try. The one caution is drift — when everything flows, it’s easy to coast past your best. |
| 伤官 | The Virtuoso | Cross-current output — brilliance made of what it meets | Brilliance | Spark | Pushback | Dazzling · Unruly · Rule-breaking | Rebellious · Over-exposed · Biting | Talent · Performance · Defiance | You dazzle when you break form. The same spark that wins the room can unsettle the ones who run it. You’d rather be brilliant than merely correct — and often you’re both. The craft is aiming it where invention is wanted, not just where rules happen to be. |
| 偏财 | The Horizon | Wide-ranging engagement — opportunity sensed at a distance | Reach | Momentum | Scatter | Resourceful · Venturing · Magnetic | Restless · Overextended · Ungrounded | Opportunity · Ventures · Father | You read money as movement — pulled toward the deal on the horizon more than the one already in hand. Opportunity registers at a distance, and you back the bet others hesitate on. Windfall energizes you; routine quietly bores you. The skill is choosing which horizons are actually worth crossing. |
| 正财 | The Steward | Methodical, directed acquisition — value built and kept | Caution | Security | Hoarding | Reliable · Compounding · Loyal | Clenched · Risk-averse · Unyielding | Wealth · Savings · Steady love | Worth, to you, is built slowly and kept. Security is something earned in steady, deliberate increments. You trust the slow ledger over the lucky break, and it makes you dependable with what matters. The only real risk is holding a thing so tightly it stops growing. |
| 七杀 | The General | Pressure that doesn't grant permission — the trial that forges | Force | Command | Harshness | Decisive · Cool-headed · Battle-ready | Punishing · Domineering · Burned-out | Pressure · Command · Crisis | Pressure never asks your permission. You’re sharpened by the trials you would never have chosen. You meet the hard thing head-on where others flinch — decisive, and hard to rattle. The watch is for when force becomes a reflex on what only needed a lighter hand. |
| 正官 | The Magistrate | Framework-mediated pressure — the standard that steadies | Order | Integrity | Rigidity | Principled · Trusted · Fair | Conforming · Over-dutiful · Unbending | Career · Status · Order | A discipline to grow into: measured authority that holds the line without forcing it. People trust you with responsibility because you carry it evenly. You’d rather be fair than feared, and it shows. The caution is rigidity — keeping the rule after it has outlived its reason. |
| 偏印 | The Alchemist | Unconventional nourishment — insight that transmutes | Insight | Vision | Distance | Intuitive · Penetrating · Inventive | Aloof · Overthinking · Shut-off | Learning · Intuition · Solitude | You feed on the strange and the oblique — understanding tends to arrive sideways, rarely on cue. You turn raw, unpromising material into sense the way few others can. Original and self-sufficient, you think best alone. Just don’t let the wondering become a room you never leave. |
| 正印 | The Sage | Nourishment that deepens without redirecting — the root that holds | Care | Wisdom | Comfort | Patient · Sheltering · Recharging | Passive · Over-protected · Inert | Knowledge · Shelter · Mother | You learn deeply and keep what you learn. Support — given or received — is never wasted on you. You’re nourished by what others hurry past, and steadied by roots that run long and quiet. The watch is for when “not ready yet” quietly becomes a place to stay. |

## Part B · The 50 element × god cells

---

### 木_七杀 · Wood × 七杀

- **Structural interaction:** Wood pressing Earth same-polarity — the destabilising reach that roots break stone
- **Overview (k2_overview):** Your Wood moves as the General: growth under discipline. Your ambition climbs like bamboo, fast, segmented, unstoppable, turning pressure into height. You command by growing first, taking the arrows meant for everyone behind you. Just remember trees also bend. The rigid campaign is the one that snaps.
- **Functional line (k2_functional):** Your discipline is espalier: severe training, few branches, everything bent toward the chosen wall.
- **Adjective chips:** catalyst Hard-trained · Focused · Storm-tested | friction Severe · Straining · Overdriven
- **Ruling domain · Pressure:** Pressure accelerates your growth: deadlines, competition, expectation all read as sunlight. Choose pressures that build height, and shed the ones that only strip bark.
- **Ruling domain · Command:** You command by example and altitude: first up, most exposed, setting pace. It inspires and it isolates. Grow lieutenants deliberately so the canopy is not one tree.
- **Ruling domain · Crisis:** In crisis you are the tree others shelter under: bending, holding, regrowing what storms take. After each one, tend your own roots first. Shelter has a maintenance cost.
- **Keyword ledger, catalyst:**
  - **Hard-trained**
    - trait: Discipline shaped you the way wind shapes a coastal tree, early and permanently. The training you put yourself through would read as punishment in someone else’s diary. In yours it reads as Tuesday, and the strength it built shows in everything you hold up.
    - scene: Five-thirty alarm, the same drills, the log filled in daily for six years without an audience. When the crisis finally needed someone with exactly that conditioning, you were ready in a way that cannot be improvised. Everyone else called it luck. Your notebook disagrees.
    - outside: People meet your regimen with a mix of awe and concern, then borrow pieces of it when their own lives wobble. The full program breaks everyone who tries it wholesale. You built it ring by ring, which is the part imitators always skip.
  - **Focused**
    - trait: Aiming at one thing is your natural state, and everything else becomes background. When a goal locks in, the noise drops away like leaves in November: one target, one season, one line of growth. Scattered people orbit you just to remember what direction feels like.
    - scene: For eight months the exam was the only thing on the whiteboard, and the whiteboard was the only decoration you allowed. Friends sent invitations and got back polite versions of after June. June came. You passed in the top percentile, and repainted the whiteboard.
    - outside: Interrupting you mid-pursuit is a known impossibility, and people schedule around your seasons of aim. Their word for it is intensity, said with respect and a little distance. Projects that need a spearpoint get handed to you. Projects that need a committee do not.
  - **Storm-tested**
    - trait: Hard weather already came for you, and you are still standing, which changed what pressure means. New crises get measured against old ones and usually lose. You bend, hold, and straighten, with the particular calm of wood that has already survived its worst forecast.
    - scene: When the company shed half its staff, panic moved through the office in waves and broke around your desk. You had rebuilt from worse in 2018. You spent the afternoon making two lists and booking one call, and by Friday people were borrowing your lists.
    - outside: People check your face during bad news the way sailors check the barometer. If you are steady, the situation is survivable, and your steadiness was calibrated by real storms rather than confidence. The calibration shows. Nobody can fake rings.
- **Keyword ledger, friction:**
  - **Severe**
    - trait: Your standards fall on people like frost, necessary in your mind, killing in effect. The praise is rare, the corrections are exact, and small errors get treated as character evidence. You are hardest on yourself, which is true, and which warms nobody.
    - scene: The intern’s report came back with forty-one margin notes and no sentence about the parts that worked, of which there were several. They redid it, better and frightened. You filed the improvement as proof of method. Their transfer request came three weeks later.
    - outside: People perform excellence around you and save their real drafts, real doubts, and real questions for softer weather. What you read as high standards working, they experience as a climate. Things grow around you, carefully, the way plants grow near a cold window.
  - **Straining**
    - trait: Effort past sense is your signature strain. The bar goes up the moment you clear it, rest gets rescheduled, and your body files complaints your calendar refuses to read. Growth needs push, and push is the only gift you know how to give it.
    - scene: The physio said six weeks off, and you negotiated it down to two in the parking lot, with yourself. The knee had opinions in week three. You called it information and trained through it, and the six weeks eventually happened anyway, doubled, in a brace.
    - outside: People around you feel the pull of your pace and either sprint or step back. Teammates burn out trying to match a load you never announced was heavy. The strain you carry silently sets the building’s tempo, and the building is getting tired.
  - **Overdriven**
    - trait: Your engine has no idle. Rest feels like falling behind, holidays get converted into projects, and even recovery has metrics now. Somewhere the drive stopped being toward anything. It just drives, and you are both the driver and the surface being worn down.
    - scene: The vacation itinerary had seven cities in nine days and a spreadsheet with column headers. On day five your family staged a small intervention at a fountain, requesting one afternoon of nothing. You granted it, checked messages twice, and called the afternoon productive.
    - outside: Watching you rest makes other people anxious, because you do it like a task with a deadline. Friends have stopped suggesting you slow down and started placing quiet bets on when the crash lands. The bets have gotten shorter every year. Nobody says so at dinner.

---

### 木_伤官 · Wood × 伤官

- **Structural interaction:** Water generating Wood cross-polarity — depth producing reach that exceeds its container
- **Overview (k2_overview):** Your Wood moves as the Virtuoso: growth that will not stay trellised. You branch where the plan said hedge, flower out of season, and produce originality the way forests produce spring, excessively and without apology. Every constraint reads as a suggestion. Your best work grows exactly where they told you nothing could.
- **Functional line (k2_functional):** You express organically and abundantly, ideas leafing faster than any format can hold.
- **Adjective chips:** catalyst Free-growing · Original · Untamed | friction Chaotic · Sprawling · Defiant
- **Ruling domain · Talent:** Your talent is generative: new shoots daily, whole canopies of ideas. The gift needs an editor the way forests need clearings. Cut sightlines through your own abundance so the best trees show.
- **Ruling domain · Performance:** You perform by unveiling growth: the project no one authorized, suddenly in bloom. Time the reveals. A garden shown at flowering converts skeptics that a garden shown as seeds cannot.
- **Ruling domain · Defiance:** Your defiance is botanical: quiet, continuous, growing over walls rather than arguing with them. It wins by finished fact. Just verify the wall you are overgrowing is not holding your own soil.
- **Keyword ledger, catalyst:**
  - **Free-growing**
    - trait: Your expression grows wherever it wants, and forcing it into rows kills it. Give you a template and the life drains out. Give you open ground and something appears that nobody planted, better than what was planned, impossible to have ordered in advance.
    - scene: The brief asked for a standard newsletter, and what you delivered was a running column with a voice, a following, and eventually a waiting list. Nobody approved the change. It grew past the approval stage while the approvers were in meetings, and readership tripled.
    - outside: Editors, managers, and one long-suffering teacher all learned the same lesson: fence you and you produce hedges, free you and you produce forests. The people who benefit most from your work are the ones who learned to stop supervising the growing.
  - **Original**
    - trait: Your ideas arrive without ancestors. Where others improve on the existing, you sprout something with no clear parent, odd at first sight and obvious in hindsight. Imitation is genuinely difficult for you, which cost you in school and pays you everywhere else.
    - scene: The party game you invented on a napkin has now been played at four weddings and one corporate retreat, mutating slightly each time. Someone recently asked where you found it. The napkin is framed in your friend’s kitchen, which is its citation.
    - outside: People carry your ideas into places you never visit, usually without your name attached, always with your fingerprints visible to anyone who knows you. Being copied stopped bothering you once you noticed the copies cannot make the next one. Only the source does that.
  - **Untamed**
    - trait: Nobody ever quite domesticated your voice, and the wildness is the value. You say the thing with the bark still on it, unsanded by committee. Polished people find you alarming and then find themselves quoting you, because the rough version was the true one.
    - scene: At the panel, between two rehearsed speakers, you answered the question everyone was avoiding, in the words everyone was avoiding it in. The moderator blinked. The clip, forty seconds long, outlived the entire conference, and next year they booked you first.
    - outside: Organizers invite you with a specific mix of hope and bracing, the way towns invite weather. Something will happen, it will be alive, and it will not be what the agenda said. The agenda-keepers grumble. The audiences keep coming back for the weather.
- **Keyword ledger, friction:**
  - **Chaotic**
    - trait: Direction is your allergy. The plan says left, and something in you veers right on principle, even when left was your own idea last week. Paths bore you the moment they firm up, which keeps life interesting and keeps arrival permanently postponed.
    - scene: You quit the program two months before certification, the third finish line abandoned in five years, each exit backed by a compelling reason that shares no logic with the others. The certificates would spell a career by now. The reasons, laid end to end, spell only motion.
    - outside: People stopped mapping your trajectory and started just asking where you are this season. Mentors who invested in one direction watched you grow in another, and the generous ones call it range. The honest ones ask what all this growing is refusing to become.
  - **Sprawling**
    - trait: Your expression spreads faster than it deepens. The podcast, the essays, the half-built app, the sketchbooks: green shoots in every direction, canopy in none. Each new tendril takes light from the last one. The garden is enormous and, so far, fruitless.
    - scene: The essay was going well until minute forty, when it became a second essay, which spawned a video idea, which required a new microphone, which arrived to find you starting a third essay. All four projects share one folder. The folder is named Focus.
    - outside: Your feeds show a person of astonishing range and no address. Followers love the variety, and the industry people who could open doors keep asking the same question in different words: what is the one thing. You keep answering with five.
  - **Defiant**
    - trait: Rules read as dares to you, including the ones that were protecting something. Authority triggers your sap like spring: the tone sharpens, the counterargument grows thorns, and suddenly the fight is the point. Half your battles improved things. The other half just cost you allies.
    - scene: The new policy was mildly inconvenient and your response was a manifesto, posted in the all-hands channel at four on a Friday. It got eleven reactions and one meeting invite. The policy stayed. Your name moved onto a list nobody prints but everyone consults.
    - outside: People with power approach you pre-flinched, which you enjoy more than is useful. Doors open more slowly for you than your talent justifies, and everyone except you can name the reason. The reason has thorns and posts on Fridays.

---

### 木_偏印 · Wood × 偏印

- **Structural interaction:** Wood generating Fire same-polarity — reach as fuel sustaining warmth
- **Overview (k2_overview):** Your Wood moves as the Alchemist: knowledge grown rather than gathered. Understanding grafts onto you slowly and lives, ideas cross-pollinating in ways textbooks never planned. Your learning is a garden with strange hybrids. Tend it privately as you must, then let people taste the fruit. It is stranger and better than you think.
- **Functional line (k2_functional):** You think by grafting: splicing distant ideas until something new takes root.
- **Adjective chips:** catalyst Connects dots · Perceptive · Self-taught | friction Tangled · Secretive · Reclusive
- **Ruling domain · Learning:** You learn like an ecosystem: slowly, laterally, everything connecting to everything. Formal courses feel like pots. Give yourself wild ground, mixed sources, and the hybrids will astonish.
- **Ruling domain · Intuition:** Your intuition grows on the underside of awareness: a slow mycelium that suddenly fruits an answer. Give questions dormancy. What you cannot force overnight arrives by spring.
- **Ruling domain · Solitude:** Your solitude is a greenhouse: ideas need protected warmth before weather. Take the seclusion without guilt. Just transplant finished thoughts outdoors. Gardens are meant to be walked in.
- **Keyword ledger, catalyst:**
  - **Connects dots**
    - trait: Your mind grafts ideas across fields that never formally met. The biology podcast fixes the pricing problem, the poetry course improves your code reviews. Nothing you learn stays in its own bed, and the hybrids that result are yours alone.
    - scene: The shipping fix that saved the quarter came, by your own account, from a documentary about ant colonies watched at one in the morning. You explained the connection twice and it survived neither explanation. It worked anyway. The warehouse now runs on ants, unofficially.
    - outside: Colleagues have learned that your reading list is a leading indicator of next quarter’s ideas, and that none of it will look relevant at the time. Mushrooms, medieval trade, birdsong. Six months later one of them is a strategy. Nobody can predict which.
  - **Perceptive**
    - trait: You notice the understory, the layer below what people say. The pause before the yes, the meeting scheduled suspiciously early, the plant someone stopped watering. Your reads arrive quietly and early, and they are right often enough to be slightly unsettling.
    - scene: You told your partner the neighbors were splitting up three months before the moving truck confirmed it, citing only the way they parked. It sounded absurd in March. In June it sounded like surveillance. It was neither. It was the parking, plus attention.
    - outside: Friends run their situations past you the way farmers check soil, quietly and before committing. You rarely volunteer what you see, which people mistake for not seeing. The few who ask directly get answers that reorganize their month, and they learn to ask again.
  - **Self-taught**
    - trait: Everything important you know, you taught yourself, sideways. No course covered it, no mentor assigned it: you found the forum, the old manual, the strange book, and built the skill in private. Diplomas confuse people about you. The knowledge is real and the paper does not exist.
    - scene: You learned the trade from a decade-old forum thread, two library books, and four hundred evenings of trying, and the certified people at work now quietly ask you the hard questions. Someone asked where you studied. The honest answer, nowhere, ended the conversation strangely.
    - outside: People cannot place your education, and it bothers the ones with framed diplomas. You cite no school and beat their methods anyway, using approaches with no names. Eventually they stop asking where it came from and start asking how it works. You mostly cannot explain that either.
- **Keyword ledger, friction:**
  - **Tangled**
    - trait: Your thoughts grow into each other until no single thread pulls free. The simple question triggers the whole system: history, caveats, three related concerns, and an hour later the original question is still standing there, unanswered, holding its coat.
    - scene: Asked whether you wanted the Thursday or Friday slot, you produced a consideration of both, touching childcare, traffic patterns, an article about decision fatigue, and your mother. The organizer waited, then assigned Thursday. You are still not sure Thursday was right.
    - outside: People simplify their questions before bringing them to you, stripping out anything your mind might climb. It half works. What they get back is still a thicket, thorough beyond use, and they thank you and go make the decision with a coin.
  - **Secretive**
    - trait: Information flows into you and does not flow out. Your projects, your feelings, your Tuesday afternoons: all filed under later. Nobody is deceived, exactly. They are just standing outside a hedge that grew so gradually no one remembers planting it.
    - scene: Your closest friend learned about the job interview after you got the job, the apartment after you signed, and the surgery after the stitches came out. Each time they asked why. Each time the honest answer was that telling never occurred to you.
    - outside: The people who love you assemble you from fragments, comparing notes like researchers with a rare species. Someone knows about the writing, someone else about the debt, nobody about both. Your privacy is total, and from their side it looks a lot like distance.
  - **Reclusive**
    - trait: Given a free evening, you choose the den, every time, and the evenings are increasingly free because people stopped asking. Solitude feeds your mind and quietly starves the rest. The difference between retreat and disappearance is a return date, and yours keeps sliding.
    - scene: The last three invitations got the same reply, drafted with real intention: next time. There was a fourth invitation. There was not a fifth. The group photo from the trip you skipped hangs in another house, complete without you, and nobody meant anything by it.
    - outside: Friends now describe you in past-adjacent tense, fondly, the way people describe a lighthouse keeper. Brilliant, out there somewhere, presumably fine. Re-entry gets harder each season you stay in the trees, and the seasons have started agreeing with each other.

---

### 木_偏财 · Wood × 偏财

- **Structural interaction:** Metal directing Wood broadly — precision ranging across living material
- **Overview (k2_overview):** Your Wood moves as the Horizon: growth that reaches for distant light. Opportunity, for you, is territory: new markets, new cities, branches extended where no one from home has grown. You expand naturally and prune reluctantly. Fortune arrives through the reaching. Roots decide how much of it you keep.
- **Functional line (k2_functional):** You grow toward opportunity steadily, extending reach every season without retreating.
- **Adjective chips:** catalyst Wide-branching · Enterprising · Open-handed | friction Scattered · Overgrown · Fickle
- **Ruling domain · Opportunity:** Opportunities appear to you as open land: markets unplanted, niches unclaimed. You see fertile ground others call wilderness. Scout it, but check the soil before transplanting everything.
- **Ruling domain · Ventures:** Your ventures grow in groves: several trunks sharing a root system of skills and contacts. Let each mature before seeding the next. Orchards fail from planting fever, not planting.
- **Ruling domain · Father:** The father-thread runs green and rangy: a paternal figure of journeys, enterprises, or restlessness. His pattern of reaching shaped yours. Keep the reach, and plant the roots he may have skipped.
- **Keyword ledger, catalyst:**
  - **Wide-branching**
    - trait: Your effort naturally runs in several directions at once, and the directions feed each other more than they collide. Focus, as commonly preached, never fit you: your luck lives in the overlaps, where one venture waters the next. So you stopped apologizing for the branching.
    - scene: The supplier from the first venture became the landlord of the second, and a customer from the second just introduced the third. On paper it is three businesses in two cities. In practice it is one root system wearing three names, and it feeds itself.
    - outside: People who chase one goal at a time find your calendar hard to explain. You keep three ventures alive across two cities, and somehow the overlaps feed each other instead of colliding. Spreading is simply how opportunity finds enough doors to knock on.
  - **Enterprising**
    - trait: Seeing the opening before others see the wall is your standing advantage. Where most people need proof, you need one walk past the site, and the plan assembles itself uninvited. Most of what you imagine stays imaginary. The fraction you build pays for the whole habit.
    - scene: You walked past the empty lot once and the café appeared in your head, tables and all, a year before anyone else saw potential. By the time the neighborhood caught up, you had already moved on twice. Early is the only schedule you have ever kept.
    - outside: Friends have learned to listen when you point at nothing and describe a business. Half your ideas sound absurd on the sidewalk and obvious five years later. The people who laughed at the first one quietly ask about the next.
  - **Open-handed**
    - trait: Money moves through your hands easily, and it keeps coming back with interest of a kind no bank tracks. You give without counting, on instinct, and the instinct has been running a quietly profitable book for years without ever once being audited.
    - scene: You covered the dinner without thinking, the way you seeded the friend’s shop and floated the cousin’s rent. Nobody kept a ledger, least of all you. Somehow the shop sends customers, the cousin sends leads, and generosity keeps turning out to be your best-performing account.
    - outside: The word on you is generous, and the word travels further than money does. Doors open because you propped one open for someone else two years back. Tight-fisted people never see this economy at all, and they keep wondering how you afford your luck.
- **Keyword ledger, friction:**
  - **Scattered**
    - trait: Starting is your genuine talent, and staying is the tax you keep finding ways around. Your energy is all spring and no autumn: everything gets planted, nothing gets brought in, and the finish line remains a rumor from other people’s lives.
    - scene: Four projects, all around forty percent, none moving. The oldest one needed two weekends of work in March, and it is October, and those weekends went to the newest one, which has since also stopped. The finish line has never once seen you up close.
    - outside: People have stopped asking how the projects are going, because the answer is always the same word, almost. Your talent was never the question. What they are waiting for, some more patiently than others, is a single finished thing to point at.
  - **Overgrown**
    - trait: Adding commitments is a reflex you no longer notice, the way a hedge never notices new branches. Every yes seemed small at the moment of signing. The sum runs your life now, and the important thing keeps not happening inside a calendar too full to hold it.
    - scene: There is no white space left in the calendar, and reading it honestly is uncomfortable: half the entries are things you volunteered for while already busy. Each one was one small yes. Together they are the reason the important thing keeps not happening.
    - outside: From outside, your life looks impressively full, and people say so with admiration. Up close, the fullness has no center. Even your closest people book you two weeks out, and the thing you say matters most has not appeared on the calendar in months.
  - **Fickle**
    - trait: Your interest burns hottest at the start and moves on before results arrive, and the pattern is old enough to have its own shelf. Enthusiasm was never the missing ingredient in any of it. Week seven is, and week seven always has been.
    - scene: The guitar got six good weeks, then the course got its six, then the market stall. Each one was the real thing while it lasted, and the shelf where they ended up is running out of space. Week seven has beaten you more often than any rival.
    - outside: Friends now respond to your new obsessions with a warmth they privately ration, because they have met week seven. Nobody doubts the passion. They have simply watched enough six-week eras end to know the shelf, and never the stage, is where this one is headed too.

---

### 木_劫财 · Wood × 劫财

- **Structural interaction:** Reach meeting reach cross-polarity — growth competing with growth
- **Overview (k2_overview):** Your Wood moves as the Rival: growth that races the grove. Another’s success reads to you as proof of reachable height, and it pulls you upward faster than any plan. You share ground generously and compete on it constantly. Handled well, that doubles every harvest. Handled loosely, the roots start strangling.
- **Functional line (k2_functional):** Your energy feeds on contest and outdoor motion, and sours in idle shade.
- **Adjective chips:** catalyst Fast-climbing · Gutsy · Rivalry-fueled | friction Overreaching · Turf-guarding · Impulsive
- **Ruling domain · Rivalry:** Your rivalries are growth spurts: every worthy competitor adds a ring. Keep them seasonal rather than permanent. A race that never ends stops being training and becomes a root war.
- **Ruling domain · Shared stakes:** You pool naturally: gardens, ventures, family plots tended together. Write down whose branch is whose before the fruit comes in. Shared soil grows the most and disputes the hardest.
- **Ruling domain · Boldness:** Your daring is springlike: sudden reach toward light others have not noticed yet. Trust it early in ventures and slow it near contracts. Green wood bends into bad deals when the sun is exciting.
- **Keyword ledger, catalyst:**
  - **Fast-climbing**
    - trait: Upward is your body’s default direction, and speed is its signature. New job, new ladder, new wall: you find the holds faster than anyone expects, and you are halfway up before the group finishes stretching. Height that takes others years takes you seasons.
    - scene: You joined in March as the junior hire and by December were running the standup, through momentum rather than coup. The org chart caught up to reality in the spring. Somebody checked the dates twice, assuming a typo. The dates were right.
    - outside: Peers track your ascent with a mix of inspiration and vertigo. Some train harder because you exist, which you would take as the highest compliment. The ones who resent it are mostly resenting the mirror. You climb past both kinds without slowing.
  - **Gutsy**
    - trait: Nerve is your renewable resource. You ask for the number with a straight face, take the shot with the game on the line, sign up before feeling ready. Fear shows up on schedule and finds you already moving, which it never quite gets used to.
    - scene: You asked for forty percent above the posted range, out loud, in the actual meeting, while your co-applicants asked for the midpoint. The pause lasted four seconds. You got thirty-two percent and a reputation. Both are still compounding.
    - outside: People borrow your nerve for their own risky moments, asking what you would do and then, crucially, whether you would come along. You usually would. Half your circle’s boldest stories feature you standing just off-camera, having dared them into the frame.
  - **Rivalry-fueled**
    - trait: Competition is your fertilizer. A rival in the field and your growth doubles: the training sharpens, the hours deepen, the work finds another gear you did not know the engine had. You do not resent your rivals. You privately thank them, at the finish line.
    - scene: The gym was dying at six in the morning until the newcomer started matching your pace. Within a month you were both twenty percent stronger and nodding like diplomats. Neither of you has ever named the arrangement. Both of you check the other’s numbers first.
    - outside: Coaches and managers quietly use you as the pace car, placing you near whoever needs pushing. It works every time. The people you pull upward mostly like you, once they recover, and the record boards in several places carry the results of arguments you started.
- **Keyword ledger, friction:**
  - **Overreaching**
    - trait: Your reach consistently files claims your foundations cannot fund. The bigger title, the second loan, the bet sized for the person you plan to become: each grab lands just past stable, and the wobble afterward is now a recognizable season of your life.
    - scene: The renovation budget was set, then exceeded by the better tiles, then by the wall that became optional, then structural, then gone. The house is beautiful and the debt has a view. You have started describing year five of the two-year plan as phase two.
    - outside: Lenders, partners, and family have all developed the same small pause before your proposals. They have watched the pattern: brilliant start, stretched middle, scramble. They still say yes, usually at reduced exposure, and keep a quiet reserve for the scramble.
  - **Turf-guarding**
    - trait: Your patch gets defended with energy the patch itself never asked for. The account, the role, the recipe, the driving route: colleagues, siblings, and once a wedding DJ have all met the fence unexpectedly. Sharing feels like shrinking. So the fence grows instead.
    - scene: The new colleague suggested a small improvement to your process, and your reply, though polite, contained a full title deed. The improvement was good. It surfaced eight months later from someone else and you fought it again, on principle, before quietly adopting it.
    - outside: People pitch changes to your areas through intermediaries now, or wrapped as your own idea returned. It works, which is its own commentary. The domain stays yours and stays smaller than it would be, and everyone but you has done that math.
  - **Impulsive**
    - trait: Your body signs before your mind reads. The quit, the purchase, the lane change, the reply-all: executed at growth speed, reviewed at leisure. Some of your best outcomes started this way, which is the problem, because so did all of your worst ones.
    - scene: You resigned on a Tuesday over a scheduling slight, without a plan, with a mortgage. It worked out, eventually, which is the version the story leads with. The four months in the middle, the ones your partner remembers differently, get summarized as a transition.
    - outside: Your circle has a protocol for your announcements: wait forty-eight hours before reacting, because half of them reverse. The other half were already executed. People love the aliveness and have learned to keep helmets nearby. Somebody usually rides along, bracing.

---

### 木_正印 · Wood × 正印

- **Structural interaction:** Wood generating Fire cross-polarity — reach nourishing warmth and opening direction
- **Overview (k2_overview):** Your Wood moves as the Sage: living shelter, the teaching tree. Care in you grows canopies, patience wide enough for slow learners, roots that hold ground for whole families. What you know, you plant in people. It is the gentlest power in the system. Just keep one sunny patch that grows things purely for you.
- **Functional line (k2_functional):** You think in growth arcs: what this person could become with the right seasons.
- **Adjective chips:** catalyst Nurturing · Evergreen · Shade-giving | friction Smothering · Clingy · Dormant
- **Ruling domain · Knowledge:** Your knowledge is arboreal: living, branching, taught best by walking someone through the grove. You learn to pass on. Teaching is how your roots drink.
- **Ruling domain · Shelter:** Your shelter is canopy: people rest under your patience and grow in your shade. The forest never asks who waters the oldest tree. Arrange your own rain.
- **Ruling domain · Mother:** The mother-thread is orchard-deep: a nurturing figure who planted daily, or soil you had to enrich alone. Either way you became the gardener. Tend your own roots with the same hands.
- **Keyword ledger, catalyst:**
  - **Nurturing**
    - trait: Growing people is your mind’s favorite work. You see the seed version of someone, water it with patience nobody else budgets, and stand back when it takes. Half your pride lives in other people’s accomplishments, planted years earlier, never invoiced.
    - scene: The struggling student you tutored on Tuesdays for two unglamorous years just sent a photo of a diploma. Your reply took a while to type, for reasons the keyboard could not fix. You have four such photos now. Each one waters something in you back.
    - outside: People trace their turning points to you with an accuracy that would embarrass you if collected in one place, so it never is. The teacher, the aunt, the manager who believed early. Different names for the same climate. Things grow where you are, reliably.
  - **Evergreen**
    - trait: Your mind keeps its leaves through every season. The curiosity other people lose to adulthood is intact in you, still learning, still asking, still green in the middle of professional winters. People with half your years age faster than you do, and notice.
    - scene: You started the language course at fifty-five, unbothered by the teenagers in the app rankings, and held a halting first conversation on holiday two years later. The waiter complimented your verbs. You have retold that compliment more often than any career achievement.
    - outside: Younger colleagues keep forgetting your age and older ones keep asking your secret. It is not genetic and it is not the diet. It is that you never signed the retirement papers for your curiosity, and around you, other people quietly un-sign theirs.
  - **Shade-giving**
    - trait: Your presence casts usable shade: people rest in it, think in it, recover in it. You hold opinions without weaponizing them and knowledge without billing for it. Being near you lowers the temperature of a problem by several degrees, which is why problems keep visiting.
    - scene: The new parent next door sat in your kitchen for one hour weekly through an entire hard winter, mostly saying the same things. You mostly listened and refilled the pot. By spring they were fine. They credit the tea. It was never the tea.
    - outside: People plan hard conversations for when you will be present, the way picnics get planned around trees. Your effect is easiest to see in your absences: the family gathering that runs scratchier without you, the meeting that overheats. Comfort has a source. You are one.
- **Keyword ledger, friction:**
  - **Smothering**
    - trait: Your care comes in coverage so complete it blocks the light. The help arrives before the struggle finishes forming, the advice before the question. People you love grow pale under the protection, and their weakness then proves to you they needed it.
    - scene: Your son’s first apartment came pre-stocked by you down to the spice rack, his job application quietly proofread, his landlord researched. He thanked you with something missing from his voice. At thirty he still calls before minor decisions, which you count as closeness.
    - outside: The people in your shade have private conversations about sunlight. They rehearse independence speeches they never quite give, because the care is real and the debt it creates is real too. Someone will eventually transplant themselves abruptly. It will be called ungrateful. It will be survival.
  - **Clingy**
    - trait: Letting go is a season your mind refuses to enter. The grown child, the finished era, the friend who moved: you hold on with tendrils dressed as check-ins, traditions, and gentle guilt. The grip feels like love from inside. From outside it has a weight.
    - scene: The weekly call with your daughter has an agenda now, hers, called boundaries. You negotiated it down from daily with visible effort. Afterward you reorganized her old bedroom again, which is its own kind of phone call, one she has stopped answering.
    - outside: People manage their exits from your orbit in stages, like leaving a warm bath slowly. Nobody tells you directly that the holding hurts, because you hold on sweetly. So they drift by inches and you tighten by inches, and both sides call it fine.
  - **Dormant**
    - trait: Your own growth went to sleep somewhere while you tended everyone else’s. The plans wait like bulbs under a lawn you keep mowing for other people. You call it a phase, and phases end. This one has voted itself several extensions.
    - scene: The application for your own course sat behind the fridge magnets all autumn while you drove other people to theirs. The deadline passed in November, quietly. Next year, you said, watering someone else’s success. You have said next year in four different Novembers now.
    - outside: The people you have grown keep looking back, puzzled, waiting for you to start your own season. They offer to return the favor and find no project to help with. Your soil is famously fertile. Everyone wonders, some out loud now, why nothing of yours is planted in it.

---

### 木_正官 · Wood × 正官

- **Structural interaction:** Wood setting standard for Earth cross-polarity — movement asking whether stability is living
- **Overview (k2_overview):** Your Wood moves as the Magistrate: living order that grows. You build careers and codes like trellises, principled frames that help everything on them climb. Authority suits you when it nurtures. People accept your rules because your rules have leaves. Prune the dead ones each season and the frame stays believed in.
- **Functional line (k2_functional):** Order is your native climate: you grow straight inside good structure and warp without it.
- **Adjective chips:** catalyst Straight-growing · Honorable · Leads by example | friction Stiff · Overformal · Change-proof
- **Ruling domain · Career:** Your career grows like a managed forest: steady rings, widening responsibility, roots deepening in one good house. Choose organizations you would plant a decade in. Transplanting yearly wastes your kind of compounding.
- **Ruling domain · Status:** Your standing grows organically: respect accruing ring by ring until you are somehow the oak everyone consults. Let it. Just keep lower branches reachable.
- **Ruling domain · Order:** Your order is cultivated: rules as trellises rather than cages, standards that make growing easier. Systems you design get adopted willingly. Revisit them each season so the living thing never outgrows the frame.
- **Keyword ledger, catalyst:**
  - **Straight-growing**
    - trait: You grow toward the light in a straight line: education, career, family, each stage built plumb on the last. Shortcuts bend other people’s trunks. Yours rises clean, and decades later the straightness is visible from a distance, holding up more than itself.
    - scene: The five-year plan you wrote at twenty-four has checkmarks on it, most of them dated within a season of the target. It is framed nowhere and referenced constantly. People ask how you knew what you wanted. You mostly knew how you wanted to grow.
    - outside: Younger relatives get pointed at your life the way apprentices get pointed at level foundations. It creates a pressure you never asked for and quietly enjoy. The nickname behind your back is some version of the reliable one. Worse names exist.
  - **Honorable**
    - trait: Your word is structural. What you promise happens, what you sign binds you, and what you would not want printed does not get done. In a market of loopholes you deal in load-bearing sentences, and people build on them without inspection.
    - scene: The handshake deal from 2015 cost you money to honor when prices moved, and you honored it without renegotiating. The other party tells that story at dinners. Their referrals arrive pre-sold, doing your marketing in a currency that cannot be purchased.
    - outside: Your name gets invoked to settle arguments you are not present for, as in, would that person do this. Being a unit of measurement is unpaid work with excellent hours. People behave slightly better around you, and mostly cannot say why.
  - **Leads by example**
    - trait: Being the example is a role your conduct keeps applying for. You do the boring right thing repeatedly, visibly, without being asked, and standards form around you the way paths form where someone walks daily. Rules look livable in your vicinity, which is why they hold.
    - scene: You returned the extra change, filed the honest expense report, and took the parking ticket without contesting the unfair half. Small, dull, witnessed. Two years later a junior colleague, caught in a real dilemma, did the right thing and cited you. You had said nothing.
    - outside: Parents point at you, managers reference you, and the group’s behavior improves measurably when you enter. It is a strange power, being calibration. The cost is that your rare bad day gets discussed like an earthquake. The benefit is everything that quietly never goes wrong.
- **Keyword ledger, friction:**
  - **Stiff**
    - trait: Bending is not in your repertoire. The joke lands on you and stops, the change of plans arrives and finds you already braced, the hug gets received like an audit. Your uprightness holds structures up and keeps warmth at handshake distance.
    - scene: The surprise party genuinely surprised you, and your first act was to check whether the kitchen had been left tidy. It had. You relaxed by degrees over ninety minutes, arriving at almost festive just as guests were leaving. They still describe you as having attended.
    - outside: People warm up their news before bringing it to you, knowing spontaneity bounces off your posture. Children in the family treat you with formal fondness, like a beloved building. The loosening everyone hopes for appears only on rare evenings, and gets discussed for years.
  - **Overformal**
    - trait: Procedure is your native tongue, spoken even at picnics. The email where a text would do, the agenda for the family meeting, the correct channels pursued at incorrect moments. Form was meant to carry respect. Somewhere along the way it started replacing contact.
    - scene: Your birthday message to your oldest friend arrived typed, punctuated, and signed with your full name, as it has for thirty years. They read it aloud to their spouse in a formal voice, laughed, and then, quietly, kept it. Both reactions were about the same thing.
    - outside: People adjust their register around you like visitors at a consulate, and the real conversation happens after you leave the group. You are respected in full and confided in rarely. The distance between those two facts is where your friendships wait.
  - **Change-proof**
    - trait: New ways bounce off your bark. The updated system, the different route, the revised recipe: each gets a trial with a predetermined result. What worked keeps working, in your telling, and the world’s job is to stop moving while you finish being right.
    - scene: The team migrated tools in March, and you are still exporting everything to the old format, nightly, in a private folder labeled in case. The folder has never once been needed. Its maintenance now takes longer than learning the new tool would have.
    - outside: Rollouts route around you by design now, with your section handled last and by specific patient people. You experience this as respect for your seniority. It is partly that, and partly the org chart drawing a fence around the place where change goes to stall.

---

### 木_正财 · Wood × 正财

- **Structural interaction:** Metal directing Wood cross-polarity — precision shaping reach toward structured outcomes
- **Overview (k2_overview):** Your Wood moves as the Steward: growth banked in rings. You build worth the way orchards do, planted early, tended patiently, harvested honestly, replanted always. Assets in your care grow. So do people. Your fortune is cumulative and alive, and it rewards the seasons you refuse to rush.
- **Functional line (k2_functional):** You build annually: steady deposits of effort that quietly become an estate.
- **Adjective chips:** catalyst Cultivating · Compounding · Deep-rooted | friction Stuck · Plays it safe · Inflexible
- **Ruling domain · Wealth:** Your wealth is orchard-shaped: productive assets, patient growth, income in seasons. Buy things that grow, land, skills, dividends, and let time do the heaviest lifting. It intends to.
- **Ruling domain · Savings:** You save like a granary: harvests stored against winters. Rotate the stock, reinvest the surplus, and remember granaries exist so that planting can be brave.
- **Ruling domain · Steady love:** You love agriculturally: devotion planted deep, tended daily, expected to fruit for decades. Choose a fellow gardener. Then keep courting through every season, even the mud ones.
- **Keyword ledger, catalyst:**
  - **Cultivating**
    - trait: Improving what you already own comes easier to you than chasing what you don’t, and it shows everywhere you’ve settled. Care, in your hands, behaves like an investment: whatever you maintain appreciates, and whatever needs chasing, you mostly no longer bother to chase.
    - scene: The bike you have oiled every spring for six years is one example, and the client you have kept for ten is the other. Neither looked like ambition at any point, and both are now worth double what they were. That is more growth than most of the chasing around you produced.
    - outside: Restless people find your patience confusing, and then they find it enviable. While they traded up and started over, you stayed and improved what was already yours, and the value quietly crossed over theirs somewhere around year five. Nobody saw the overtaking happen. It was too slow to watch.
  - **Compounding**
    - trait: Small and repeated is your natural size of effort, and it is a better engine than it looks. You distrust bursts and believe in schedules, and the believing has paid: your results arrive the way interest arrives, invisibly for years, then suddenly.
    - scene: Fifty a month since college. A page a day, a call every Friday, and at no point did any of it look impressive, which is exactly why it worked. Your natural size of effort is small enough to repeat forever, and repetition is where your money and your skill actually come from.
    - outside: Watching you work is boring, and your results embarrass people who sprint. The deposits were too small to notice and too regular to stop, and somewhere along the way they became terrain. Friends who mocked the fifty a month now ask, carefully, how it got to this.
  - **Deep-rooted**
    - trait: Committing to one craft and one ground, and then actually staying, is the move you keep making. Depth beats breadth in every ledger you run, and the staying pays in ways the movers around you never collect. It looked stubborn for a while. Now it looks like strategy.
    - scene: Year nine of the same work, same town, same name on the door. Around year four it felt like being left behind, because everyone else was rebranding and relocating. Then the people who kept moving started sending work to the one person who could still be found.
    - outside: People who track one goal at a time find your calendar easy to read and your patience hard to copy. You are where you said you would be, doing what you said you would do, nine years in. Roots this deep never look like much from above. They hold anyway.
- **Keyword ledger, friction:**
  - **Stuck**
    - trait: Outgrowing a place and staying anyway is a pattern of yours, and calling it loyalty stopped being accurate a while ago. The ground you hold has long since stopped feeding you. Holding it anyway is the habit, and the habit never checks the yield.
    - scene: The plant on your desk has been repotted twice in five years. The desk itself, the rate, and the commute have not moved once in the same stretch. You keep telling people you are settled, and some of them have started gently asking settled into what.
    - outside: Recruiters gave up on you years ago, which you took as proof of loyalty. Meanwhile the colleagues who left keep getting bigger, and visiting their new offices leaves a taste you have stopped examining. Staying was right once. Nobody has re-run the numbers since.
  - **Plays it safe**
    - trait: Weighing a risk is your reflex, and almost no risk survives the weighing. The analysis is always excellent and always lands on later, because the math was never the real obstacle. The deciding was, and the deciding still is.
    - scene: Three spreadsheets compared the two jobs down to the commute minutes, and the reply that finally went out was thanks, but not this year. The analysis took six weeks. The no took one sentence, and it was written somewhere in you before the spreadsheets ever opened.
    - outside: People bring you opportunities the way they feed a cautious animal, slowly and with both hands visible. They already know the odds. Whatever it is, however good it is, the first answer will be some polite version of later, and later has its own way of becoming never.
  - **Inflexible**
    - trait: Once your way of doing things works, it hardens into the only way you will do them. Working once, for you, is proof of permanent correctness, and every update gets treated as an accusation. Your way still works. That was never the question people were raising.
    - scene: The new tool has been sitting unopened for a year, and the old one still technically works, which settles the argument every time it comes up. The argument keeps coming up. You have noticed that, and decided it means everyone else is wrong twice.
    - outside: Working around you has become a small skill people teach each other. They know which suggestions to skip, which routines are load-bearing, and which sentence beginning with we have always means the conversation is over. Your way still works. It is just no longer the only thing being maintained.

---

### 木_比肩 · Wood × 比肩

- **Structural interaction:** Reach amplifying reach — developmental instinct without definition or counterforce
- **Overview (k2_overview):** Your Wood moves as the Twin: growth that stands beside others without leaning on them. You rise the way two trees share a hillside, close enough to shelter each other, rooted enough to stand alone. Ambition, for you, is upward and personal. You measure yourself against your own last season, and quietly against the tree beside you.
- **Functional line (k2_functional):** Your stamina is vegetal: quiet, continuous, renewed by daylight and outdoor air.
- **Adjective chips:** catalyst Self-rooted · Upright · Persevering | friction Standoffish · Stubborn · Slow to change
- **Ruling domain · Peers:** Your peers are the grove: people growing the same direction at their own speeds. Comparison is your fertilizer and your poison, so use the grove for shade and shelter, and race only your own rings.
- **Ruling domain · Independence:** Wood independence is having your own soil: your plot, your craft, your income no one else waters. Secure it early. You bend badly when planted in someone else’s garden.
- **Ruling domain · Self-reliance:** You hold yourself up through storms that flatten louder people, and you rarely mention the wind afterward. Let someone stake you when you are newly transplanted. It is not dependence. It is horticulture.
- **Keyword ledger, catalyst:**
  - **Self-rooted**
    - trait: Your footing is your own, grown from your own choices and watered on your own schedule. Approval is pleasant weather rather than required rainfall. People with shallower systems topple in seasons you barely notice, and they notice you not noticing.
    - scene: When the industry rumor cycle hit, half your peers rewrote their profiles within a week. You changed nothing, on the grounds that nothing about you had changed. The cycle passed. Your unchanged profile now reads as the confident one, which it always was.
    - outside: People ask your opinion specifically because it was not assembled from the group’s. Your yes means yes and arrives unsponsored. In shifting alliances you are the fixed survey point, and both sides check their positions against yours without telling each other.
  - **Upright**
    - trait: You stand on your own structure, without leaning on charm, on apology, or on anyone’s shoulder. What holds you up is internal, built, and paid for, which is why pressure does not change your shape. People can push. Nothing in you is borrowed enough to come loose.
    - scene: When the funding fell through, three co-founders started calling advisors, mentors, parents. You recalculated your own runway at the kitchen table and adjusted your own plan by morning. Help was offered twice. You took the version that let you stay vertical: information, without the arm.
    - outside: Nobody manages you, worries about you, or checks your footing, and after a while they stop trying to. You lean on no one so consistently that leaning on you feels safe. Half the group’s stability, on inspection, is people steadying themselves against your unborrowed posture.
  - **Persevering**
    - trait: Continuing is your quiet superpower. Where motivation fails, you simply proceed: the run in the rain, the chapter after a rejection, year six of the practice everyone else left in year one. Time works for you because you never fire it.
    - scene: The Tuesday run has survived four winters, two jobs, and one broken toe, adjusted but never skipped. This morning it was raining sideways and you went anyway, same route, same distance. Nothing about it is impressive on any single day. The years are the unit.
    - outside: Your persistence reads as unremarkable up close, day by day, and staggering in summary. People introduce you with numbers: fifteen years running, four hundred consecutive weeks. The numbers embarrass you slightly. They are also, everyone agrees, the whole explanation.
- **Keyword ledger, friction:**
  - **Standoffish**
    - trait: Your default distance reads as a fence with no gate signage. You join late, leave early, and hold conversations at arm’s length even when your arm wanted otherwise. People conclude you prefer it this way. Some days they are wrong, and the fence cannot say so.
    - scene: At the reunion you spent forty minutes near the drinks table in a pleasant holding pattern, waiting to be approached, while three people across the lawn did the same thing, waiting for you. Everyone drove home slightly lonely. The photos look fine.
    - outside: New people get warned that you take a while, delivered as advice, functioning as a moat. By the time anyone crosses it, they find someone warmer than advertised and mildly puzzled about the moat’s reputation. You built it in increments. It reads as architecture now.
  - **Stubborn**
    - trait: Once planted, your position holds against reason, weather, and personal cost. Being wrong is survivable. Admitting it feels like being uprooted, so the argument continues past its own death, and you keep watering a stump on principle.
    - scene: The thermostat war of last winter was never about degrees. Concessions were available cheaply in week one. By week six, both sides were cold and dug in, and you specifically were wearing two sweaters indoors as a form of speech.
    - outside: People pick which hills to offer you carefully, knowing you will die on any of them, including the decorative ones. Negotiations with you get shorter as everyone learns the shape: agreement, or geology. Your wins are real. So is the tally of what they cost.
  - **Slow to change**
    - trait: You do change, eventually, at a pace that tests everyone’s faith in the concept. New evidence gets a probation period measured in seasons. By the time you adopt the improvement, its inventor has moved on, and you present it with the calm of original ownership.
    - scene: You resisted the phone upgrade for three years, listing principled objections, and then loved it within a week of surrendering. The pattern has repeated with the car, the software, and one entire relationship. The objections were never about the thing. They were about being moved.
    - outside: People learn to plant ideas near you and walk away, returning months later to find them adopted and slightly renamed. Pushing speeds nothing and delays plenty. Your eventual yes is solid, everyone agrees, and everyone budgets a fiscal year for it.

---

### 木_食神 · Wood × 食神

- **Structural interaction:** Water generating Wood same-polarity — depth as natural source of effortless reach
- **Overview (k2_overview):** Your Wood moves as the Artisan: growth that fruits. Everything you tend produces, gardens, projects, people, and the producing feels less like work than like season. You nourish by cultivating: patient feeding, honest pruning, harvests shared at the fence. Your gift ripens on its own schedule. Respect the schedule.
- **Functional line (k2_functional):** Your words grow on people slowly and stay. You persuade the way spring does.
- **Adjective chips:** catalyst Fruitful · Mellow · Tending | friction Overripe · Lax · Overbooked
- **Ruling domain · Expression:** Your expression bears fruit: gardens, meals, projects that people can taste and hold. Make output a rhythm rather than an event. An orchard produces because producing is simply what it does.
- **Ruling domain · Enjoyment:** You enjoy abundance in its natural forms: tables full, gardens loud, seasons honored with their own pleasures. Guard the fallow time too. Delight, like soil, needs its resting years.
- **Ruling domain · Children:** Children and students flourish around you like well-watered rows: fed patiently, staked when young, given sun and left to grow. Your line, biological or chosen, tends to be fruitful and fond of you.
- **Keyword ledger, catalyst:**
  - **Fruitful**
    - trait: Your output ripens naturally and keeps coming. The dinners, the small gifts, the finished little projects: none announced, all delivered, season after season. Where others sprint and stall, you simply bear, and the people around you have quietly reorganized their lives around the harvest.
    - scene: The sourdough starter you keep has fed four households and outlived two of their marriages. Every week, loaves leave your kitchen without ceremony. Somebody once totaled a year of your giving on a napkin and stopped counting at a number that embarrassed everyone present.
    - outside: People inventory what you produce only when you are sick for a month and the flow stops: the meals, the favors, the small repairs, the cards that arrive on time. The gap teaches them the size of the tree. You recover, and it resumes, unremarked.
  - **Mellow**
    - trait: Your temperament arrived pre-softened. Provocations land in you like stones in deep grass, absorbed without ceremony. People bring you their sharp edges and leave with them slightly rounded, and nobody, including you, can point to the moment the rounding happened.
    - scene: The road-rage incident happened entirely in the other car. You waved, genuinely unbothered, and finished the podcast. Your passenger spent ten minutes processing the injustice. You offered them a mint. By the destination they were laughing, and could not reconstruct why they had cared.
    - outside: Tense situations get scheduled around your availability, informally, because things just go softer with you in the region. Nobody calls it a skill, which suits you. The mediator titles go to louder people. The actual mediating, most weeks, happens near the mint supply.
  - **Tending**
    - trait: You express care by making things comfortable around people. The blanket appears before anyone said cold, the kettle is on before the knock, the leftovers go home in containers with the right lids. Nobody calls it expression. It is your entire vocabulary.
    - scene: While house-sitting, you left the place cozier than you found it: the reading lamp moved to where the light actually falls, the good mugs brought forward, soup in the freezer with a dated label. The owners noticed for three weeks, one small comfort at a time.
    - outside: People relax in spaces you have touched and cannot say why. The guest who slept over once still mentions the bedside water. Comfort follows you into other people’s houses and stays after you leave, which is a strange, real talent, and completely unlisted.
- **Keyword ledger, friction:**
  - **Overripe**
    - trait: Your gifts sat on the branch past their moment. The talent is real and increasingly historical: the almost-finished album, the recipe book everyone requested a decade ago, the sweetness starting to ferment into stories about what nearly happened. The season did not end. It just stopped being picked.
    - scene: You played the old demo for the young cousin, who was impressed and then asked, without cruelty, when it was recorded. The date was fourteen years ago. There is a newer song, technically. It has been almost done since the phone that recorded it was new.
    - outside: People still introduce you by your potential, and the introduction has begun to age in the middle. Everyone remembers the brilliance and awaits the shipment. The awaiting has developed rituals, gentler each year, the way families adjust their questions around a harvest that keeps being next season.
  - **Lax**
    - trait: Standards around you loosen like old elastic. The deadline drifts, the quality bar lowers itself politely, the follow-up follows nothing. Ease was the gift. Unattended, it composted into a comfortable rot that everyone enjoys and nobody thanks later.
    - scene: The client got the draft nine days late with a breezy apology, which worked, as it usually works, until the quarter it stopped working. The lost contract funded someone else’s diligence. You called it their luck. The invoice history calls it something plainer.
    - outside: People adore working with you and quietly duplicate your responsibilities, building small safety nets under everything you carry. The nets catch things weekly. You have never noticed, which is partly the charm and mostly the problem. The adoration is real, and so are the nets.
  - **Overbooked**
    - trait: Saying no feels like unkindness to you, so you mostly do not. The favor, the shift swap, the third brunch: each yes is warm and small, and together they have booked your life solid. Everyone gets a slice of you. The slices stopped adding up to a person.
    - scene: Saturday holds pottery, the volunteer shift, two standing brunches, and a league you joined to be nice in 2022. You enjoy each one, tiredly. The afternoon you actually wanted, the empty one, has not appeared on the calendar since spring.
    - outside: People know you will say yes, and the knowing shows up in their asks. You are the default babysitter, the fallback host, the covering shift. Nobody means harm. But generosity with no gate gets scheduled by other people, and yours has been for years.

---

### 火_七杀 · Fire × 七杀

- **Structural interaction:** Fire pressing Metal same-polarity — the forge that doesn't moderate itself
- **Overview (k2_overview):** Your Fire moves as the General: heat weaponized into will. You command like a charge, blazing conviction that armies of ordinary people find themselves following. Crisis makes you luminous. Peacetime makes you dangerous to furniture. Aim the cannon, always. Unaimed, this much fire tests every relationship it warms.
- **Functional line (k2_functional):** Your order is fire discipline: absolute at the front, enforced on yourself before anyone else feels it.
- **Adjective chips:** catalyst Decisive · Daring · Crisis-ready | friction Too intense · Bossy · Burned-out
- **Ruling domain · Pressure:** Pressure ignites you: stakes convert your heat into focus. Without real battles you invent them, so keep a worthy campaign running at all times, professional or physical.
- **Ruling domain · Command:** You command by fire: vision hot enough to melt objections. Troops follow the light. Mind the scorch radius, and let cooler officers handle the discipline your heat would burn.
- **Ruling domain · Crisis:** Crisis is your parade ground: you charge while others count. Victory loves you. Afterward, check who got trampled in the charge, including you.
- **Keyword ledger, catalyst:**
  - **Decisive**
    - trait: Deciding fast is native wiring for you, and it reads as relief to everyone stuck deliberating. Options do not improve with age, in your experience, and your experience keeps proving it. The choice gets made while others are still framing the question. Then everyone breathes.
    - scene: Twenty minutes into the dinner debate, you name the restaurant and stand up. Chairs scrape, coats go on, and the relief around the table is almost audible. Nobody remembers the other options by the sidewalk. Deciding was the meal everyone was actually hungry for.
    - outside: People who deliberate for a living find your speed alarming until they work with it once. Then they start routing choices your way, quietly, the ones that have been circling for weeks. You settle them before lunch and nobody ever asks to reopen one.
  - **Daring**
    - trait: Moving toward what others edge away from is wiring, and it spares you the weeks other people lose to dread. The feared thing shrinks on contact, every single time, and you have known that longer than most people have been avoiding their own versions of it.
    - scene: The call everyone dreaded sat on your list for exactly one day. You made it standing up, between two other tasks, and it went the way these things usually go with you, which is fine. Three weeks of collective dread died in four unremarkable minutes.
    - outside: Teams keep a mental list of things nobody wants to do, and your name has drifted next to most of them. Colleagues call it bravery to your face and something more useful behind your back: proof that the scary version of a task rarely survives contact with someone unafraid of it.
  - **Crisis-ready**
    - trait: Emergencies make you calmer, which is rare enough that people remember it. Your talent switches on precisely when plans switch off: full clarity, short sentences, zero panic. Peace leaves you slightly restless, honestly. Collapse, oddly, brings out your very best manners.
    - scene: The venue flooded at noon and the speaker cancelled at one. By ten past, you had a new hall, a new order of events, and a tone in your voice that made panic seem like a strange hobby other people had. The event ran. Nobody remembers how close it came.
    - outside: There is a particular quiet that falls when things break and you are present, because everyone knows where the decisions will come from. It looks like glamour from a distance and it is really planning under pressure, done fast, and it has saved more days than anyone has counted.
- **Keyword ledger, friction:**
  - **Too intense**
    - trait: Your intensity marks people whether you mean it or not, and you usually do not. The heat that cuts through problems does not distinguish problems from bystanders, and the bystanders remember longer. You forget the flare by lunch. Nobody standing near it ever does.
    - scene: It was one word, sloppy, said at speed on a Tuesday and forgotten by lunch. A year later the person who caught it can still play it back with your exact inflection. You were putting out a fire. They were standing closer to it than you noticed.
    - outside: New people get warned about you, gently, in hallways: brilliant, worth it, wear gloves. The warnings are affectionate and they are also warnings. Half the silence you read as respect is actually flinch, and the difference matters more every year you climb.
  - **Bossy**
    - trait: Taking charge is your reflex even where nobody asked, and mostly nobody asked. Any gathering without a commander strikes you as an emergency, and you fix it by quietly assuming the post. Order arrives on schedule. Volunteering, around you, just as quietly dies.
    - scene: The vacation had a schedule by the first morning and a debrief by the last night, and somewhere in between, the group chat went quiet. One-word replies, thumbs up, fine. You ran a beautiful operation. The others were on holiday, or trying to be.
    - outside: People under your command perform agreement long before they feel it, because pushing back costs more energy than most afternoons contain. Decisions that were never yours keep ending up yours. It feels like leadership from where you stand. From two steps away it looks like weather everyone dresses for.
  - **Burned-out**
    - trait: Running at full flame until the fuel simply ends is a cycle for you, and calling it bad luck stopped working several cycles ago. The crash sits on the schedule now, as regular as the campaigns themselves. You just decline to read that far down.
    - scene: The three months of heroics ended the way they always end, with two weeks where getting up felt like a rumor. From the couch you drafted apologies and, in the same hour, the next campaign. The pattern is so regular a friend once predicted your crash to within four days.
    - outside: Everyone around you can see the crash coming except you, and they have learned not to say so out loud. They plan for your two dark weeks the way coastal towns plan for storm season, quietly moving what matters to higher ground. The storm never once takes the hint.

---

### 火_伤官 · Fire × 伤官

- **Structural interaction:** Wood generating Fire cross-polarity — reach producing warmth that challenges frameworks
- **Overview (k2_overview):** Your Fire moves as the Virtuoso: light that must be seen. You are the flare, the show, the opinion that ignites the whole street, talent with a spotlight built in. Attention comes to you like oxygen and behaves like it too. Managed, you illuminate everything. Unmanaged, you are magnificent arson.
- **Functional line (k2_functional):** You express in fireworks: dazzling, loud, unforgettable, occasionally singeing the front seats.
- **Adjective chips:** catalyst Dazzling · Quick-witted · White-hot | friction Provocative · Scene-stealing · Combustible
- **Ruling domain · Talent:** Your talent is incandescent and public: performing, persuading, lighting ideas so others finally see them. It needs an audience the way flame needs air. Book the stage instead of apologizing for wanting one.
- **Ruling domain · Performance:** Performance is your natural habitat: the pitch, the stage, the moment all eyes turn. Rehearse enough to deserve the attention you attract. Brilliance plus preparation reads as destiny.
- **Ruling domain · Defiance:** Your defiance burns visibly: the public no, the bridge lit for warmth. Some bridges deserve it. Count to ten anyway, and keep a fireproof list of the ones that lead home.
- **Keyword ledger, catalyst:**
  - **Dazzling**
    - trait: When you switch on, everyone else becomes background lighting. The presentation, the toast, the argument you decide to win in style: your output has wattage that cannot be taught, and attention finds you the way moths find porch lights, reliably and a little helplessly.
    - scene: You took the graveyard slot at the conference, the one after lunch on the last day, and by minute six people were texting colleagues to come in. The recording circulated for months. The organizers moved you to the keynote the following year, apologizing for the delay.
    - outside: People plan events partly around whether you will be on form, because your form changes the evening’s category. The risk is known and priced in: you might outshine the occasion itself. Twice now, the couple’s wedding is mostly remembered for your toast. They quote it fondly, mostly.
  - **Quick-witted**
    - trait: Your mind moves at spark speed. The comeback arrives while the setup is still landing, the solution mid-question, the joke exactly on the beat. In fast company you are the fastest thing present, and slow company speeds up around you out of self-respect.
    - scene: The client’s curveball question, the one designed to embarrass, got an answer so fast and clean that the questioner laughed and wrote it down. Your team debriefed the moment for a week. You could not remember composing the reply. It had simply been lit and ready.
    - outside: People stop mid-story around you to say do not steal this, knowing your version will be funnier by dinner. Writers in your circle keep notes on things you said in passing. At least one printed mug exists. You signed it, obviously, since the line was yours.
  - **White-hot**
    - trait: At full intensity you do in hours what committees do in quarters. The deadline crunch, the final rehearsal, the last mile: your heat concentrates into something close to alarming, and the output comes back changed from the inside out. Nobody asks what it costs. It visibly costs.
    - scene: The pitch was due at nine and dead at midnight, so you burned from midnight to six and delivered something that made the original plan look like a rough draft of your rough draft. The client signed by lunch. You slept through the celebration, honorably.
    - outside: Colleagues describe your peak state with fire-safety vocabulary, half joking. When you lock in, people clear the area and route materials toward you, knowing the window is real and finite. What comes out of those windows has won accounts, contests, and one national award. Handle accordingly.
- **Keyword ledger, friction:**
  - **Provocative**
    - trait: You poke things to watch them jump. The needling question at the calm dinner, the opinion calibrated to singe, the topic everyone buried, exhumed by you at speed. Reaction is your proof of life, and peace, in your hands, keeps getting tested for flammability.
    - scene: The family lunch was going suspiciously smoothly, so you asked your uncle about the election, twice, with eye contact. The predictable fire arrived on schedule. You watched it burn with the satisfaction of an arsonist reviewing his work, and left before the cleanup, as usual.
    - outside: Hosts seat you the way fire marshals plan exits: deliberately and with backup plans. Your provocations are often genuinely interesting, which is the defense you always offer. But friends have started previewing guest lists with you, and the previews have the tone of safety briefings.
  - **Scene-stealing**
    - trait: Attention is oxygen, and you take yours from whoever currently holds it. The birthday girl, the grieving widow, the colleague mid-triumph: within minutes the light has somehow bent toward you, and you honestly did not plan it. The reflex plans it. You just execute.
    - scene: At the retirement party, the guest of honor spoke for eight minutes, and your follow-up story, told from the floor, ran eleven and got bigger laughs. People checked the retiree’s face without meaning to. You were magnificent. It was, everyone agreed later, exactly the problem.
    - outside: Friends love you and have learned to schedule you: the big news gets announced before you arrive or after you leave. Nobody has ever said this to your face, and the calendar work involved is considerable. You would be devastated to see it. It is very carefully hidden.
  - **Combustible**
    - trait: Your anger exits through your mouth, fully phrased. Where others slam doors, you produce sentences, sharp, quotable, and aimed, and the fire is out of you before you can review the wording. The words were burning. Everyone burned by them remembers the phrasing exactly.
    - scene: The reply-all was composed in ninety seconds at full heat, and it was, everyone privately agreed, magnificently written. It named names. You cooled by lunch and spent a quarter repairing what one paragraph had done, comma by comma.
    - outside: People screenshot your outbursts, which is the problem: they are eloquent enough to travel. The apology never catches up to the original, because the original was better written. Colleagues admire the craft, fear the heat, and quietly keep the receipts.

---

### 火_偏印 · Fire × 偏印

- **Structural interaction:** Fire generating Earth same-polarity — warmth as activation source for stability
- **Overview (k2_overview):** Your Fire moves as the Alchemist: illumination in a closed vessel. Your insight comes in flashes, sudden clarity that lights a whole cavern, then dims while you sketch what you saw. You understand things sideways, by vision rather than proof. Keep notebooks. The flashes are real, and unrecorded lightning teaches no one.
- **Functional line (k2_functional):** You think in flashes: whole answers arriving lit, proofs assembled after.
- **Adjective chips:** catalyst Visionary · Night-bright · Uncanny | friction Obsessive · Erratic · Distant
- **Ruling domain · Learning:** You learn by ignition: nothing for weeks, then a spark takes and you consume a field in days. Honor the cycle. Keep fuel stacked for when the flash comes.
- **Ruling domain · Intuition:** Your intuition arrives as vision: sudden, whole, and correct more often than you can justify. Note it immediately. The flash fades faster than the truth it showed.
- **Ruling domain · Solitude:** Your solitude is the dark that makes flashes visible: crowds wash out your signal. Reserve real darkness, evenings unplugged, questions held alone. Then carry the light out.
- **Keyword ledger, catalyst:**
  - **Visionary**
    - trait: You see finished things where others see empty air. The business before the market exists, the picture before the first stroke, the version of a person they have not met yet. The visions arrive lit from inside, complete, and your job is mostly transcription.
    - scene: You described the neighborhood’s future to a skeptical friend in 2019, cafe by cafe, almost address by address. You were renting there anyway when the wave arrived. The friend brings up that walk every time property prices come up, in the tone people use for eclipses.
    - outside: People dismiss your predictions at intake and quote them at parties three years later. The pattern has repeated enough that a few colleagues now write down your stray remarks, timestamped, as a hobby. Their notebook, they say, outperforms their financial advisor. They are not entirely joking.
  - **Night-bright**
    - trait: Your mind switches on when the world switches off. After eleven, the connections arrive: the insight, the fix, the strange idea with the workable center. Daylight-you executes what midnight-you discovers, a two-shift operation everyone mistakes for one ordinary person.
    - scene: The solution to the storage problem arrived at 1:40am, complete, while the house slept, and you built the prototype by breakfast using a lamp and a towel to muffle the drill. The team spent Tuesday marveling. You spent Tuesday napping, having already been to Wednesday.
    - outside: People learn to check their messages in the morning for your timestamps: 12:51, 2:14, 3:03, each carrying something the daylight meetings could not produce. Employers have stopped policing your hours. Whatever happens in your small hours arrives at standup already glowing, and nobody audits a lighthouse.
  - **Uncanny**
    - trait: Your knowing arrives without visible sources. The diagnosis before the tests, the reading of a stranger at a glance, the sense that this flight, this deal, this person is wrong. Asked to explain, you produce nothing auditable. Asked to be right, you mostly are.
    - scene: You told your friend not to take the apartment, unable to name a single concrete reason beyond the light felt wrong. She took it. The mold survey, the neighbor situation, and the landlord’s lawsuit all surfaced within the year, in roughly the order your discomfort had.
    - outside: People consult you off the record, slightly embarrassed, the way executives consult weather folklore before big launches. Your hit rate embarrasses them further. Nobody builds a slide around your feelings, and increasingly nobody signs anything big without, casually, asking what your gut says first.
- **Keyword ledger, friction:**
  - **Obsessive**
    - trait: One idea takes the whole house. The new interest arrives like ignition: gear bought, sleep skipped, meals forgotten, conversation rerouted through the topic for weeks. The heat is genuine and total, and everything else in your life stands in its light, waiting, unwatered.
    - scene: The chess phase lasted seven weeks and consumed roughly two hundred hours, four apps, one physical clock, and every anecdote you told. Then, on an unremarkable Thursday, it simply stopped burning. The board is under the bed now, with the telescope, the loom, and the kanji cards.
    - outside: Your people track your obsessions like weather systems: naming them, estimating duration, planning around the blast radius. They have learned not to invest in the current one and not to mention the last one. What they miss, quietly, is the version of you between fires. He rarely visits.
  - **Erratic**
    - trait: Your energy arrives on a schedule no one, including you, can publish. Tuesday-you rewires the kitchen at midnight and Thursday-you cannot answer a text. Plans made in a bright phase get inherited by a dim one, and both phases sign your name with equal authority.
    - scene: You committed to the weekend workshop during Monday’s blaze, prepaid and enthusiastic, and arrived at Saturday as a different person, one who sat in the parking lot for forty minutes and drove home. The refund window had closed. The pattern, your partner noted, has a subscription.
    - outside: People quote two versions of you and specify which one they mean: bright-you and gone-you. Invitations come with soft confirmations layered in, checked twice, once at acceptance and once the night before. Nobody calls it unreliability to your face. The scheduling apparatus around you says it hourly.
  - **Distant**
    - trait: Your inner world drifted from the shared one by degrees. The interests nobody around you shares, the hours nobody keeps, the references that land on silence: each pulled you a little further offshore. People love you from the mainland. The commute between you has gotten long.
    - scene: At the reunion you spent the evening at the edge of three conversations, fluent in none of them, holding your drink like a permission slip. The people were kind and the kindness had distance in it. You left early, relieved, and the relief troubled you the whole drive home.
    - outside: Old friends describe you now with the phrase in their own world, said warmly and with a small shrug. Invitations still come, at holidays, in the plural, addressed to a version of you they remember. The estrangement was nobody’s decision. It accumulated, like heat leaving a house.

---

### 火_偏财 · Fire × 偏财

- **Structural interaction:** Water directing Fire broadly — depth ranging across warmth as distributed material
- **Overview (k2_overview):** Your Fire moves as the Horizon: light that spends itself gladly. Opportunity finds you at gatherings, luck likes your laugh, and money arrives in blazes and leaves by the same door. You are fortune’s favorite dinner guest. Learn to pocket the bread, and the feast never really ends.
- **Functional line (k2_functional):** You seize chances at speed, brilliant in windows, bored in pipelines.
- **Adjective chips:** catalyst Spark-spotting · Charismatic · Fast-moving | friction Flash-chasing · Big spender · Flighty
- **Ruling domain · Opportunity:** Chances come to you socially: the tip at the table, the partner met at the party. Keep circulating, it is genuinely your economy. Just write things down before the candles burn out.
- **Ruling domain · Ventures:** Your ventures shine at launch: openings, campaigns, anything with a lit fuse and a crowd. Pair every firework with a caretaker who loves the quiet part. That partnership is your fortune.
- **Ruling domain · Father:** The father-thread flickers warm and irregular: a paternal figure of charisma, generosity, or absence in flares. You inherited the shine and the volatility. Spend the first, insure against the second.
- **Keyword ledger, catalyst:**
  - **Spark-spotting**
    - trait: You see the catch of an opportunity before there is visible flame. The undervalued block, the platform before the crowd, the person about to become somebody: your eye finds the ember while everyone else needs the bonfire. Being early is your entire portfolio, and it keeps paying.
    - scene: You bought the ugly little stand at the market’s dead corner because the foot traffic map in your head disagreed with the rent. Two seasons later the corner was the market, and the rent conversation went differently, in your favor, with you on the landlord side.
    - outside: Friends have learned to note what you mention twice, since your casual enthusiasms have a habit of becoming everyone’s expensive enthusiasms two years later. A few of them now just ask directly, at dinner, in January: what are you seeing lately. The answers have funded renovations.
  - **Charismatic**
    - trait: People warm to you before you finish your first sentence, and doors follow. The upgrade appears, the stranger extends the invitation, the gatekeeper finds an exception with your name on it. Charm this natural is not performed. It is a temperature, and everyone drifts toward it.
    - scene: You walked into the fully booked restaurant behind two parties who had been turned away, and left with a corner table, the chef’s recommendation, and a standing invitation. Your dinner companion timed the whole ascent: four minutes. She has retold that timing at every gathering since.
    - outside: Gatherings rearrange around your arrival, which you notice less than everyone else does. Hosts introduce you first, strangers remember your name, and follow-ups appear in your inbox from conversations you barely registered. The network effect is compounding. Other people network. You just show up warm.
  - **Fast-moving**
    - trait: Your speed between spark and action embarrasses whole planning departments. The idea from breakfast has a domain name by lunch and revenue by the quarter’s end. Momentum is your natural state, and hesitation, wherever you encounter it, reads to you as a foreign language.
    - scene: The pop-up went from group-chat joke to opening night in nineteen days, permits included. People asked how long you had been planning it. The honest answer, since the joke, confused them into laughter. The line outside, though, was fluent in results.
    - outside: Partners either learn your tempo or watch from the platform. By the time competitors finish their market analysis, you are iterating on version two with actual customer complaints, which you consider the only research with calories in it. The analysts eventually cite you. As data.
- **Keyword ledger, friction:**
  - **Flash-chasing**
    - trait: Every new shine gets your full sprint. The trend, the token, the just-opened thing: you arrive first, burn bright, and are gone before the substance question comes up. Chasing light is genuinely fun. A portfolio of chases, though, is mostly a photo album of exits.
    - scene: You were early to the app everyone joined and earlier out, early to the seltzer brand, the course platform, the resale game. Each sprint made money for three months and stories forever. The friend who boringly stayed in one lane just bought a house. You have anecdotes.
    - outside: People invite your read on what is next and quietly discount your staying power, a distinction that took you years to notice. The introductions still come. What stopped coming are the long-term seats, the ones reserved for people who will still be there when the shine dulls.
  - **Big spender**
    - trait: Money exits you at the speed of delight. The round for the table, the gadget of the month, the upgrade that felt like destiny at checkout: each purchase is warm and defensible, and together they are a bonfire with a loyalty card. Earning was never your problem. Keeping never got hired.
    - scene: The bonus landed on the fourth and was structurally gone by the nineteenth: the trip booked, the jacket, the speakers, the generous gesture at dinner that felt so right. Nothing was wasted, exactly. Nothing was kept, either. The statement reads like a wonderful month someone else paid for.
    - outside: Friends love going out with you and wince at your math. The generosity is legendary and the reserves are rumor. People close to you have started celebrating your windfalls nervously, knowing the celebration itself will consume a measurable percentage. Somebody gifted you a budgeting app once. You upgraded it to premium.
  - **Flighty**
    - trait: Your commitments have the lifespan of sparks. The plan ignites, glows, and is ash by the follow-through date, replaced by a newer, brighter plan in the same weekend. People stopped writing your intentions in ink around the time you did, which was never.
    - scene: The Portugal trip was real for eleven days: researched, group-chatted, half-booked. Then the sailing course appeared, then the food truck idea, and by month’s end Portugal was a tab among tabs. Your browser history is an atlas of abandoned futures, each one sincerely meant for a week.
    - outside: People triangulate your actual plans by waiting a month and checking what survived. Employers, partners, and one long-suffering travel agent have all developed the same policy: nothing books until you mention it a third time. You find the policy insulting. It has never once been wrong.

---

### 火_劫财 · Fire × 劫财

- **Structural interaction:** Warmth meeting warmth cross-polarity — presence competing with presence
- **Overview (k2_overview):** Your Fire moves as the Rival: flame that leaps between torches. You catch ambition from the people around you and pass yours back doubled, the most contagious energy in any gathering. Stakes make you luminous. The same draft that spreads your fire can spread it thin, so choose which blazes are actually yours.
- **Functional line (k2_functional):** Your energy flares with company and stakes, then needs true dark to recover.
- **Adjective chips:** catalyst Spark-chasing · Fearless · Electrifying | friction Hot-headed · Resentful · Explosive
- **Ruling domain · Rivalry:** Your rivals are accelerants: nothing focuses your flame like a nearby blaze. Keep rivalry ritual, races and games and friendly scoreboards, so the heat builds camaraderie instead of ash.
- **Ruling domain · Shared stakes:** You fund and join easily, splitting bills and risks in the same warm gesture. Enthusiasm signs faster than judgment reads. Let every shared blaze get one cold morning review before you pour fuel.
- **Ruling domain · Boldness:** Your boldness ignites others, which multiplies its consequences. Lead the charges worth leading. A spark that picks its tinder builds bonfires. One that does not builds regrets.
- **Keyword ledger, catalyst:**
  - **Spark-chasing**
    - trait: You run toward whatever is catching fire, and the running is the point. The contested deal, the live crisis, the dare with witnesses: your blood answers heat the way others answer comfort. In a world of careful people, you are the one already moving, already lit.
    - scene: When the flagship store’s launch collapsed at noon, you drove there without being asked, arriving mid-panic with energy the situation had run out of. By close, the day was saved and slightly legendary. Your boss asked who sent you. Nobody had. The smoke had.
    - outside: Teams keep you near the volatile accounts the way stations keep engines running. When something flares, you are moving before the call finishes, and colleagues have learned to just hand you the keys. The calm assignments bore you visibly. Nobody wastes you on them anymore.
  - **Fearless**
    - trait: Your asks have no ceiling. The cold call to the CEO, the bid above your class, the public promise that forces the miracle: you say the enormous thing out loud, and enough of it lands to fund the reputation. Fortune does seem to favor you. You invoice it accordingly.
    - scene: You pitched the biggest client in the region from the lobby, uninvited, with a deck finished that morning in the car. Security was called and, in the end, so was the account manager. The contract took eight months. The story reached your industry in eight days.
    - outside: People preface their descriptions of you with you will not believe, and the stories hold up under checking. Some rivals call the boldness reckless from a safe distance. Your collaborators call it Tuesday, and have learned to draft the press release before you finish the sentence.
  - **Electrifying**
    - trait: Your energy transfers on contact. The flat team meeting catches current when you enter, the tired project finds voltage, the gathering’s pulse syncs upward to yours. People leave your orbit doing things they had filed under someday. The battery, mysteriously, never bills anyone.
    - scene: The fundraiser was dying at forty percent with a week left, and your two-day blitz of calls, stunts, and shameless enthusiasm dragged it to one-forty. Volunteers who had gone quiet came back loud. The organizer’s thank-you note said simply: you plugged us back in.
    - outside: People describe meetings before and after your arrival as different weather. Managers deploy you into stalled teams the way medics deploy adrenaline, and the effect is roughly as fast. The crash that sometimes follows is also documented. Everyone considers it worth it, and schedules for it.
- **Keyword ledger, friction:**
  - **Hot-headed**
    - trait: The fuse is short, dry, and pre-lit. The wrong word, the cut-off in traffic, the tone in an email: ignition beats deliberation to the scene every time. Afterward you cool fast and repair sincerely. The people nearby, though, have all learned the smell of smoke.
    - scene: The referee’s call was wrong, and your response, at a children’s game, entered neighborhood folklore within the hour. You apologized to everyone by sundown, sincerely, including the referee. Your daughter accepted the apology and, the following week, asked you to wait in the car.
    - outside: People manage your temperature the way sound engineers manage feedback, adjusting topics before the squeal. Certain news gets delivered to you in public places, on purpose. You noticed the pattern once and got angry about it, which, everyone agreed silently, rather settled the question.
  - **Resentful**
    - trait: Other people’s wins sit on your skin like sunburn. The peer’s promotion, the friend’s effortless luck, the rival’s applause: each one stings out of proportion, and the sting talks. It comes out as jokes with edges and praise with subtitles. Everyone reads the subtitles.
    - scene: At the launch party for your friend’s startup, funded on the first try, your toast included the phrase must be nice twice, laughed off both times, remembered anyway. The friendship survived. Its temperature dropped four degrees that night and never fully came back to season.
    - outside: Your congratulations arrive with a delay everyone has learned to expect, like sound after lightning. People soft-launch their successes around you, understating, apologizing for luck. They do it out of care, which would wound you worst of all, so it stays carefully unmentioned.
  - **Explosive**
    - trait: Pressure in you does not vent. It stores, silently, behind a warm exterior, until the container fails all at once. The blowups arrive without visible warning, sized for the backlog rather than the trigger, and the cleanup involves people who never saw the gauge climbing.
    - scene: The garage door sticking was the trigger, but the detonation covered March through August: the job, the loan, the unsaid things, all of it airborne in one four-minute burst. Your family stood very still. The door, notably, still sticks. Nobody mentions it now.
    - outside: People close to you have become seismologists, reading your quiet for pressure signs and mostly getting it wrong, because the gauge is internal and you politely deny it exists. The denials are calm right up until they are not. Afterward everyone, including you, surveys the range.

---

### 火_正印 · Fire × 正印

- **Structural interaction:** Fire generating Earth cross-polarity — warmth nourishing stability and opening movement
- **Overview (k2_overview):** Your Fire moves as the Sage: hearth-wisdom, knowledge kept warm for others. You learned at somebody’s fireside, or built the fireside you never had, and now people gather at yours, fed soup and stories and courage. Your teaching glows rather than lectures. Keep logs aside for your own cold nights too.
- **Functional line (k2_functional):** You think in warm stories: knowledge kept as tales that teach without lecturing.
- **Adjective chips:** catalyst Warm-hearted · Encouraging · Healing | friction Babying · Dependent · Drowsy
- **Ruling domain · Knowledge:** Your knowledge lives as story: wisdom kept warm and passed mouth to mouth. You remember what mattered, not what was footnoted. Tell it often. Stories die refrigerated.
- **Ruling domain · Shelter:** Your shelter is firelight: people arrive cold and leave believing in themselves. That rekindling is rare medicine. Notice who only visits to warm their hands, and bank accordingly.
- **Ruling domain · Mother:** The mother-thread glows in you: a warming figure whose kitchen was church, or a cold hearth you swore to answer. Your tending is the answer. Let someone tend the tender.
- **Keyword ledger, catalyst:**
  - **Warm-hearted**
    - trait: Your presence is the warm center other lives arrange themselves around. People come in from their cold weeks and hold their hands out to you, mostly without noticing the gesture. The warmth is steady, unconditional, and quietly expensive to maintain. Nobody sees the fuel line. You are the fuel line.
    - scene: Sunday afternoons at yours have become load-bearing for at least five people, including one who mostly sits near the conversation without joining it. Nothing is organized. Soup happens, light happens, and everyone leaves warmer than they arrived. The tradition has no name and perfect attendance.
    - outside: People describe your home with their shoulders, dropping them. New partners get brought to you early, unofficially, for climate testing. The warmth you offer asks no questions, and it has become the family’s reference temperature. Holidays anywhere else get compared to it, quietly, in the car home.
  - **Encouraging**
    - trait: You warm other people’s small flames on principle. The shaky first attempt, the half-announced dream, the try that failed: each gets your specific heat, aimed at the part that was brave. People attempt things in your presence they would not risk elsewhere. That is the whole climate you run.
    - scene: Your niece showed you eleven seconds of a song she was too shy to finish, and your response, proportionate and warm and precise, is why there is now an EP. She thanked you in the liner notes for hearing it before it existed. You framed nothing. You remembered everything.
    - outside: People rehearse their announcements on you first, using your reaction as the prototype for braver telling. The pattern is invisible until you map it: half the leaps in your circle checked their footing against your encouragement first. You are the base camp several summits never mention.
  - **Healing**
    - trait: Time near you repairs people. The burned-out friend, the post-hospital parent, the teenager mid-storm: they sit in your warmth doing apparently nothing, and leave with something reattached. You never announce a treatment. You just keep the light on and the questions gentle, and mending happens.
    - scene: Your brother spent three weekends on your couch after the divorce, barely speaking, watching cooking shows. You fed him, asked nothing, and let the couch work. On the fourth weekend he fixed your cabinet hinge, unprompted, whistling. You both understood the hinge was a discharge summary.
    - outside: There is a folding of people into your care that everyone recognizes and nobody has named: after the bad news, so-and-so should probably go to yours. It is spoken like protocol. Your spare bed has hosted more recoveries than some clinics, at a fraction of the paperwork.
- **Keyword ledger, friction:**
  - **Babying**
    - trait: Your warmth removes obstacles that were doing important work. The struggle gets pre-solved, the consequence intercepted, the difficulty warmed away before it could teach anything. The people you love stay comfortable and stay soft, and the softness eventually presents its own bill, addressed to them.
    - scene: Your son’s overdue essay got rescued by your midnight edit, again, the fourth rescue this term. His grades are excellent and weightless. The teacher suspects, the boy knows, and some part of him has begun to calculate, correctly, that finishing things is optional in a heated house.
    - outside: Other adults watch you absorb consequences meant for people you love, and bite their tongues at various speeds. The kids are lovely and unweathered. Where resilience should be forming, there is instead a well-tended warmth, and everyone except you can see the forecast it cannot survive.
  - **Dependent**
    - trait: Being needed became your fuel, and the tank runs low without it. The empty nest, the recovered friend, the crisis that resolves: each healthy ending registers somewhere in you as a small layoff. You keep people slightly cold, unconsciously, to stay employed as their warmth.
    - scene: When your daughter said the therapy was working and she felt genuinely okay, your joy arrived with a strange undertow you inspected later, alone. That week you called her twice with concerns she did not have. She noticed. The okay-ness held anyway, which helped and hurt.
    - outside: People manage their independence around your feelings, staging their strength gently, keeping small needs alive for you like pilot lights. It is tender and slightly backwards, everyone caring for the caregiver by performing need. The healthiest thing anyone could give you is nothing to fix. Nobody dares yet.
  - **Drowsy**
    - trait: Comfort has lowered your flame to standby. The naps lengthen, the plans soften, the day organizes itself around warmth and ease, and ambition visits like a former colleague, fondly and briefly. Nothing hurts. Nothing much happens either, and the two facts are holding hands.
    - scene: The afternoon disappeared again into the warm chair, the blanket, the something on in the background. The course tab is still open from Tuesday, bookmarked under a nap. At six you surfaced, cozy and faintly disappointed, and made tea, which resolved the disappointment into evening.
    - outside: Your people have stopped scheduling you before noon or after eight, fitting themselves into your waking window with practiced ease. Plans involving you acquire cushions automatically. The affection is intact, and the shared unspoken knowledge too: the fire is banked so low now, it mostly keeps itself warm.

---

### 火_正官 · Fire × 正官

- **Structural interaction:** Fire setting standard for Metal cross-polarity — the forge that refines and grants recognition
- **Overview (k2_overview):** Your Fire moves as the Magistrate: civic light, authority that illuminates. You carry rules the way lighthouses carry flame, visibly, warmly, for everyone’s navigation. People follow your lead because it brightens rather than binds. Office becomes you. Keep the light public and tended, and rank will keep arriving on its own.
- **Functional line (k2_functional):** You carry order like a lantern: visible standards others steer by, kept lit at personal cost.
- **Adjective chips:** catalyst Upstanding · Squeaky-clean · Inspiring | friction Stern · Appearance-bound · Overextended
- **Ruling domain · Career:** Your career runs on visible service: roles where leading and lighting are the same act. Teaching, governance, the public face of good systems. Seek podiums attached to substance.
- **Ruling domain · Status:** Your standing is luminous and watched: warmth draws the credit and the scrutiny together. Live as if lit, because you are. The honest glow survives every inspection.
- **Ruling domain · Order:** Your order is inspirational: people comply because you made the rule glow with purpose. That is rare governance. Write things down too. Light needs a lamp when you leave.
- **Keyword ledger, catalyst:**
  - **Upstanding**
    - trait: You conduct yourself like someone permanently on camera, and the footage would hold up. The taxes are clean, the promises kept, the small ethics observed when nobody is checking. In a dim market, your reputation shines at a distance, and it was polished entirely by boring choices.
    - scene: The wallet you found held four hundred in cash and no witnesses, and its owner got a call within the hour, everything intact. He offered a reward. You declined it with a strange embarrassment, as if thanked for breathing. He tells the story more than you do.
    - outside: People invoke you when arguing about what is possible: some folks manage it, look at them. Your existence is quietly load-bearing for other people’s standards. The compliment you hear most often, from strangers and auditors alike, is some version of: everything checks out.
  - **Squeaky-clean**
    - trait: Your integrity gives off actual light. People behave better in your radius without being asked, the meeting sits straighter when you join, and the shady proposal dies unspoken because you happened to be at the table. You illuminate by standing there. It is a strange, real power.
    - scene: The vendor arrived with the usual flexible arrangement and, twelve minutes into your company, quietly stopped offering it. Nothing was said. Your presence had simply lit the transaction, and things done in the dark declined to attend. Your boss now brings you to certain meetings as equipment.
    - outside: People confess to you unprompted, at parties, in elevators: small frauds, old guilt, the thing they never told anyone. You never solicit it. Light draws what needs light. Half your acquaintances have a cleaner conscience because you exist, and none of them can explain the mechanism politely.
  - **Inspiring**
    - trait: Your example ignites effort in other people. The way you carry duty makes duty look survivable, even attractive, and quiet copies of your habits keep appearing around you: the early start, the kept word, the straight answer. You lead mostly by being watchable while doing it right.
    - scene: A junior colleague told you, three years later, that they had almost quit the field until they watched you handle the audit season with visible integrity and no visible martyrdom. They stayed, and now run their own team on what they call, without irony, the standard.
    - outside: Teams perform above their history when you lead them, and the mechanism is embarrassingly simple: people rise to being trusted the way you trust them, publicly and on the record. Departments compete for you. What they are actually bidding on is the version of themselves you produce.
- **Keyword ledger, friction:**
  - **Stern**
    - trait: Your standards arrive with heat behind them. The correction lands harder than intended, the disappointment radiates, and small failures around you acquire courtroom acoustics. People perform for your approval and flinch at your review. The excellence is real. So is the tension holding it up.
    - scene: Your son practiced parallel parking with you twice and with his aunt eleven times, a statistic you learned by accident and have thought about since. The aunt is a worse driver and a warmer climate. He passed the test and called her first, from the car, laughing.
    - outside: People escalate to you last, after exhausting every softer authority, and enter your presence pre-apologized. The respect is genuine and shaded with weather-checking. What nobody tells you, because telling you would take courage they save for emergencies, is how much easier they breathe when your calendar says traveling.
  - **Appearance-bound**
    - trait: The image runs the household. How it looks decides over how it feels: the presentable marriage, the impressive title, the holiday card version of events, maintained at rising cost. Somewhere behind the facade, the actual life waits for its schedule to open, and the facade keeps overrunning.
    - scene: The dinner party was flawless, the couple hosting it had not spoken privately in six days, and both facts were executed with equal discipline. Guests praised the roast and the marriage in the same breath, on the doorstep, in the dark. The car ride home was silent, again.
    - outside: People sense the curation and adjust their honesty downward around you, matching your polish with their own, so that the friendship proceeds between two brochures. The real versions occasionally wave to each other, late at night, in slips neither side follows up on. The brochures lunch monthly.
  - **Overextended**
    - trait: Obligation keeps hiring you and you keep accepting. The committee, the second committee, the covering-for-a-colleague that became permanent: each obligation was honorable, and their sum is a schedule with no oxygen in it. Your word is your bond, which is precisely how the bonds keep accumulating.
    - scene: The month contained thirty-one days and thirty-four commitments, and the mathematics resolved the way it always does: your own checkup postponed, twice, in favor of things you had promised to people who would have understood. The doctor’s office has a word for you. It is February.
    - outside: People bring you obligations the way undertows bring swimmers, confident of your yes, and your yes has not disappointed anyone in a decade except the person issuing it. The burnout is scheduled the way everything about you is scheduled: penciled in, deferred, and utterly reliable.

---

### 火_正财 · Fire × 正财

- **Structural interaction:** Water directing Fire cross-polarity — depth shaping illumination into structured purpose
- **Overview (k2_overview):** Your Fire moves as the Steward: a hearth, not a bonfire. You keep warmth the way households keep flame, fed regularly, banked at night, never wasted on show. Your providing glows: steady income, warm table, festivals on schedule. It is the rarest fire, the kind that lasts.
- **Functional line (k2_functional):** You work in sustainable heat: consistent output that never needs rescue.
- **Adjective chips:** catalyst Warm-handed · Hardworking · Bankable | friction Tight-fisted · Anxious · Overcareful
- **Ruling domain · Wealth:** Your wealth is hearth-warm: earned brightly, spent on the household’s glow, kept steady over spectacular. Fund the gatherings and the securities both. A warm home is your portfolio’s purpose.
- **Ruling domain · Savings:** You save for warmth: reserves that keep winters kind. Automate them so celebration cannot raid the woodpile. A banked fire relights fast. An empty grate does not.
- **Ruling domain · Steady love:** You love like kept flame: daily warmth, faithful attention, romance on the calendar and off it. Your constancy is the gift. Add sparks deliberately so the hearth never assumes.
- **Keyword ledger, catalyst:**
  - **Warm-handed**
    - trait: Money leaves your hands warm. The fair wage rounded up, the invoice paid the day it arrives, the tip that acknowledges the human: your dealings carry heat without waste, and people remember transacting with you the way they remember good meals, specifically and fondly.
    - scene: You paid the young decorator his full quote the same evening, plus the amount his underquoting had cost him, with a note about knowing his worth. He kept the note. Three years and one thriving business later, he still bumps your jobs to the front of his book.
    - outside: Tradespeople answer your calls first, sellers hold things for you unasked, and your name in a transaction thaws the terms. The premium you occasionally pay for decency keeps returning as priority, honesty, and first refusal. Your money makes friends everywhere it goes, and they all remember your address.
  - **Hardworking**
    - trait: Your effort burns steady, on schedule, without applause requirements. The daily block, the maintained log, the follow-through that arrives exactly when promised: the work gets done at a sustainable temperature, every day, and the years quietly assemble the results into something substantial.
    - scene: The certification took eighteen months of Tuesday and Thursday evenings, logged without drama while louder colleagues announced bootcamps they never finished. When the title bump came, people called it sudden. The logbook, four notebooks thick by then, had a different word for it.
    - outside: Managers hand you the long-burn projects, the ones that die in flashier hands, because your fire does not need feeding by an audience. What you tend, finishes. The portfolio of finished things has become your entire argument, and it wins every review without your voice rising once.
  - **Bankable**
    - trait: Your word converts to certainty at full rate. The quote holds, the date holds, the handshake survives price movements: people budget on your commitments the way they budget on math. Being counted on is your asset class, and its yield compounds in reputation.
    - scene: The contractor overran and your quote did not, absorbing the difference exactly as promised, exactly once. The client noticed both halves: the cost you ate and the silence you ate it with. Their next three projects arrived un-tendered, with a note: your number is the number.
    - outside: Around you, people stop building backup plans. The backup plans for your deliverables have quietly disappeared from other people’s spreadsheets, which is the highest compliment operations can pay. New partners get told simply: whatever that one says will happen, price it as done.
- **Keyword ledger, friction:**
  - **Tight-fisted**
    - trait: The flame gets rationed like the last match. The heating negotiated by degrees, the gift budgeted to the occasion’s minimum, the generosity metered through a nozzle: nothing is ever quite wasted, and nothing is ever quite warm. The savings are real. So is the temperature.
    - scene: The birthday gift was practical, correctly sized, and returned the following week for something the recipient actually wanted, an exchange conducted politely and remembered longer than the birthday. You noticed the return in the account. You did not mention it. Neither did they, at length.
    - outside: People have quietly re-sorted you from ask to do not bother, and the re-sorting saved you money that cost you invitations. The rounds you never bought, the collections you queried, the split hairs at every bill: each small defense held. The territory it defended has emptied.
  - **Anxious**
    - trait: Money worry runs in you like a pilot light, never quite off. The balance gets checked at midnight, the small expense triggers the big spiral, and windfalls arrive pre-ruined by the question of losing them. The accounts are healthy. The relationship with them is not.
    - scene: The unexpected dental bill was covered by any of four accounts, and still cost you a weekend of recalculating retirement projections at the kitchen table, again, with the door closed. Your partner watched the light under the door. The numbers were fine. The light stayed on till two.
    - outside: People around you have learned that financial topics change your breathing, and they steer accordingly: trips proposed with cost worked out in advance, gifts disguised as luck. The care is loving and constant and slightly exhausting, and everyone maintains it because the alternative is watching you calculate.
  - **Overcareful**
    - trait: Every risk gets triple-checked until it leaves. The opportunity waits while you verify, the verified thing waits while you re-verify, and the moment, which had a temperature, cools to safe and worthless. Nothing bad gets past you. The cost is everything that needed slight courage.
    - scene: The franchise opportunity cleared your first review, your second, and your accountant’s, and died awaiting your third, taken instead by a former colleague with worse analysis and a signature. Their opening party invitation sat on your counter for a month. You checked their numbers annually, after.
    - outside: People pitch you first for rigor and elsewhere for money, a routing everyone understands and nobody explains to you. Your due diligence is borrowed by half your circle, applied to deals you declined. The finder’s fees that never existed would, by now, have funded the caution.

---

### 火_比肩 · Fire × 比肩

- **Structural interaction:** Warmth amplifying warmth — illumination running without containment
- **Overview (k2_overview):** Your Fire moves as the Twin: a flame that burns on its own fuel and stands level with every other light. You warm a gathering without needing to lead it, and you bristle when anyone tries to carry you. Two torches burn brighter side by side. That is your theory of company, and mostly it works.
- **Functional line (k2_functional):** Your energy burns bright and social: fed by activity, drained by standing in another’s shadow.
- **Adjective chips:** catalyst Self-lit · Vivid · Undimmed | friction Too proud · Touchy · Unapproachable
- **Ruling domain · Peers:** Your peers are fellow fires: vivid friends, loud tables, mutual sparks. The heat of comparison can flare into rivalry fast, so choose companions who celebrate blaze rather than compete for oxygen.
- **Ruling domain · Independence:** Fire independence is your own hearth: warmth that no one can dim by leaving. Build a life that stays lit in an empty house, and company becomes a pleasure instead of a fuel line.
- **Ruling domain · Self-reliance:** You reignite yourself after setbacks that extinguish others, usually overnight. The skill to learn is banking coals: resting without calling it defeat, so the relight costs less each time.
- **Keyword ledger, catalyst:**
  - **Self-lit**
    - trait: Your fire needs no external ignition. Motivation, celebration, recovery: all generated onboard, on your schedule, from your own fuel. Gray seasons that dim everyone else find your output unchanged, and people eventually ask where the switch is. There is no switch. There is just you, on.
    - scene: The whole team went flat after the funding fell through, and you came in Monday running on the same setting as always, working the plan, playing your music. By Wednesday two others had re-lit off your example. Nobody discussed it. Flame transfers that way, wordlessly.
    - outside: People keep expecting your energy to trace back to something: the routine, the diet, the secret. They audit your habits and find nothing transferable. The light is simply factory-installed, and the people who winter near you have learned to stop explaining it and start standing closer.
  - **Vivid**
    - trait: You are unmistakably yourself at all times, and it costs you nothing. The opinions, the laugh, the orange shirt: none of it adjusts to the audience, because none of it was built for an audience. People meet one version of you. There is only one.
    - scene: At the new job you dressed, joked, and disagreed exactly as you had at the old one, from day one. No feeling-out period, no beige phase. Within a month the team could imitate you affectionately, which is what happens to people who are only themselves.
    - outside: Nobody has ever described you as an acquired taste, because there is nothing gradual about you. People place you instantly and permanently. Years later, strangers from one meeting recall you in detail, while the adaptable people around you have blurred together in everyone’s memory.
  - **Undimmed**
    - trait: Setbacks that lower other people’s flames leave your wattage stubbornly constant. The rejection, the rough year, the public stumble: each arrives expecting to find a dimmer switch and finds instead a person already back at brightness, slightly annoyed at the interruption.
    - scene: The restaurant failed in March, publicly, expensively, and by June you were catering weddings out of a rented kitchen with the same menu and better margins. People kept waiting for the humbled chapter. You skipped it, apparently unaware it was scheduled, and the food got better.
    - outside: People measure resilience against you and quietly retire the word for themselves. Your relights after failure have become local legend: same heat, new venue, no visible scar tissue. Investors who lost money on your last thing keep asking about your next one. Light like yours audits well.
- **Keyword ledger, friction:**
  - **Too proud**
    - trait: Your flame refuses to be seen flickering. The struggle stays private, the help gets declined at the door, the apology exits in a dialect nobody recognizes as one. Being impressive is mandatory, being witnessed mid-failure is not survivable, and the policy costs you exactly what it protects.
    - scene: The business wobbled for five months before anyone knew, because the version of you at dinners kept performing success on schedule. When the closure finally announced itself, friends were hurt in an unexpected direction: you had let them toast a ghost. The pride had spent their trust.
    - outside: People edit their offers of help into compliments before approaching you, a translation service everyone runs and nobody acknowledges. Your worst seasons are visible only in hindsight, dated by gaps in the photo record. The support you never requested was available the whole time, warming nobody.
  - **Touchy**
    - trait: Being treated as less than an equal lights you up faster than any insult. The talked-over sentence, the credit handed elsewhere, the tone that files you under junior: your heat answers before your judgment gets a vote. The issue is never the thing. It is the standing.
    - scene: The contractor explained your own trade to you, slowly, and the meeting changed temperature. You corrected him once, precisely, at volume. He was right about one small detail and never got to say it, which cost you a week and won you nothing.
    - outside: People around you learn the one rule quickly: never talk down to you, even by accident. Introductions get made carefully, titles included. The respect this enforces is real, and so is the caution, and the two arrive together, holding hands.
  - **Unapproachable**
    - trait: Your brightness reads as a closed door. The confidence, the speed, the shine: together they build a glare people squint at from a distance, assuming you need nothing and no one. Invitations to depth stopped arriving years ago. Everyone assumed someone else was providing it.
    - scene: At your lowest week in years, the phone stayed silent, and you realized the silence was your own engineering: a decade of seeming complete had trained everyone out of checking. The one friend who did call apologized twice for intruding. You were, you said brightly, fine.
    - outside: New people orbit you at a fixed radius, warmed but not close, sensing no docking port in all that light. The intimates you do have all report the same onboarding: years of proximity before the first real conversation. Most people, understandably, settle for the glow and drift.

---

### 火_食神 · Fire × 食神

- **Structural interaction:** Wood generating Fire same-polarity — reach as natural source of warmth and expression
- **Overview (k2_overview):** Your Fire moves as the Artisan: warmth that cooks instead of burns. You turn heat into hospitality, talent into entertainment, an ordinary evening into something people retell for years. Pleasure is your medium and generosity your technique. The feast only fails when the cook forgets to eat.
- **Functional line (k2_functional):** You express in performances of warmth: stories, meals, toasts that leave everyone lit.
- **Adjective chips:** catalyst Radiant · Festive · Heartwarming | friction Comfort-chasing · Over the top · Slack
- **Ruling domain · Expression:** Your expression is the lit table: cooking, performing, hosting, celebrating. It is real art, so treat it as one. The gatherings you make are the memories a whole circle keeps.
- **Ruling domain · Enjoyment:** You enjoy loudly and generously, and your appetite blesses whatever it touches. The discipline is savoring over consuming: fewer, better feasts. The flame tastes more when it eats slower.
- **Ruling domain · Children:** With the young you are the warm hearth: fun, feeding, festival. They will remember your kitchen as childhood itself. Add one steady ritual to the sparkle, so the warmth has a schedule they can lean on.
- **Keyword ledger, catalyst:**
  - **Radiant**
    - trait: Your enjoyment broadcasts. The good meal, the small win, the Tuesday sunset: whatever you savor gets amplified through you and lands on everyone nearby, brightening the whole table by contact. Joy in your hands is not private property. It is a utility, and you run the grid.
    - scene: You liked the street musician, so the whole group stopped, and because the group stopped, a crowd formed, and because you clapped like that, others did, and the musician had her best hour of the year. She thanked you specifically. You had simply enjoyed her loudly.
    - outside: Event planners and grandmothers agree on you: seat that one centrally. Your delight is the yeast of gatherings, invisible in the recipe and responsible for the rise. Parties you miss get described afterward with a slight shrug: it was nice. Nice is the word for your absence.
  - **Festive**
    - trait: You find the celebration inside ordinary days and switch it on. The exam passed becomes a dinner, the Friday becomes an occasion, the occasion gets candles. Ritual joy is your craft: you know that marking a moment is what makes it a moment, and you mark relentlessly.
    - scene: The divorce papers were finalized on a Thursday, and by Saturday you had organized, of all things, a party, the exactly right kind, for your friend who needed her new chapter to begin with cake instead of silence. She keeps the photo from that night on her fridge.
    - outside: Your calendar quietly anchors the year for a surprising number of people: the solstice dinner, the first-snow cocoa, the anniversary of nothing in particular. Traditions you invented as jokes now have attendance records. People plan around them, and around you, the way towns plan around festivals.
  - **Heartwarming**
    - trait: What you express goes straight to the chest. The toast that gets the region misty, the text that arrives on the exactly wrong day and makes it right, the compliment specific enough to keep: your warmth has aim. People store what you say to them, sometimes for decades.
    - scene: At the funeral, your two minutes about the deceased’s terrible parking and enormous heart did what the eulogy could not: the family laughed, then wept, then thanked you at the door, gripping your hand a beat long. The widow quotes your lines now as her own memory.
    - outside: People hand you the emotional assignments nobody else can carry: the toast, the goodbye card everyone signs after you set the tone, the call to the friend in the hospital. Your words reliably reach the part of people that formal language misses. It is a talent disguised as niceness.
- **Keyword ledger, friction:**
  - **Comfort-chasing**
    - trait: Pleasure sets your compass, quietly, in every decision. The easier option, the tastier plan, the warmer route: each choice defensible, and the sum a life that curves reliably away from anything difficult. Comfort was supposed to be the reward. Somewhere it filed for full custody.
    - scene: The gym membership entered its third unvisited year the same month the dessert subscription renewed automatically, a coincidence the credit card statement laid out with unkind clarity. You laughed about it at brunch, which was, itself, the fourth brunch of the week. Everyone laughed. Nothing changed.
    - outside: People stopped inviting you to anything with friction in it, the hike, the volunteer shift, the hard honest talk, and the invitations that remain are upholstered. Your life from outside looks enviably pleasant. The people who love you longest look twice, and worry on the second look.
  - **Over the top**
    - trait: Your celebrations outspend their occasions. The birthday needs the venue, the dinner needs the good bottle, the ordinary weekend needs upgrading on principle. Delight justifies every line item at the moment of purchase, and the statements afterward read like reviews of a life slightly larger than the income.
    - scene: The birthday needed a venue, the venue needed a theme, and the theme needed the good caterer, for eleven guests. It was a wonderful night, everyone says so. The next gathering anyone else hosts will be at a kitchen table, apologizing for it.
    - outside: Friends love your occasions and cannot match them, so slowly they stop trying. Invitations to yours climb, invitations back shrink, smaller and slightly ashamed. Celebration was supposed to bring the table together. Sized this big, it mostly makes everyone else’s table feel poor.
  - **Slack**
    - trait: Your follow-through melts in warm weather, and the weather around you is always warm. The promised call slides, the project rests, the deadline softens into a suggestion. Nothing is refused and little is finished: pleasure keeps writing checks that discipline was supposed to cash.
    - scene: The photo book from the big trip, promised to everyone in the group chat, is eleven months in progress. The photos are selected. The captions are half-written. Every few weeks someone asks warmly, and you answer warmly, and the warmth is where the project actually lives now.
    - outside: People have stopped attaching outcomes to your enthusiasm, enjoying the sparkle and quietly sourcing delivery elsewhere. It happened gradually and completely: you are cherished at kickoffs and absent from credits. The gap between how much you are loved and how much you are counted on has become the fact of you.

---

### 土_七杀 · Earth × 七杀

- **Structural interaction:** Earth pressing Water same-polarity — the dam blocking depth without permission
- **Overview (k2_overview):** Your Earth moves as the General: mass mobilized. Your authority is siege-grade, patient, inevitable, built of logistics and will. You do not charge. You surround, supply, and wait, and what you press eventually yields. People obey your stillness more than others’ shouting. Use that gravity on real fortresses.
- **Functional line (k2_functional):** Your order is a fortress code: few gates, hard walls, and zero exceptions after dark.
- **Adjective chips:** catalyst Fortress-calm · Commanding · Siege-proof | friction Walled-up · Heavy-handed · Grinding
- **Ruling domain · Pressure:** You metabolize pressure into foundation: loads that flatten others become your footing. The watch-point is accumulation. Mountains crack invisibly first, so audit the strain you call normal.
- **Ruling domain · Command:** You command through immovability: the standard that does not shift, the decision that stays decided. It builds empires of order. Leave one gate for appeals, or the fortress becomes a wall.
- **Ruling domain · Crisis:** In crisis you are the ground itself: unshaken, absorbing, the place others stand. Afterward the ground deserves surveying too. Even bedrock records every earthquake somewhere.
- **Keyword ledger, catalyst:**
  - **Fortress-calm**
    - trait: Staying calm under pressure is load-bearing structure for you, and everyone leaning on it can tell. Deadlines collapse, clients raise their voices, and yours holds the level it keeps on an easy Tuesday. People bring you their panic the way they bring valuables to a vault.
    - scene: The launch broke at nine and the group chat caught fire. Your first message, posted at 9:04, was a numbered list. By the third number the chat had gone quiet and gone to work, and the fire was just weather again.
    - outside: New teammates think you are unbothered, and older ones know better. The calm is built, wall by wall, and it holds because you decided long ago that panicking is a second emergency. Nobody has seen the construction. They just live inside it.
  - **Commanding**
    - trait: Taking charge comes to you the way gravity comes to heavy things, without asking. In any group without a plan, the plan starts collecting around you. You rarely raise your voice. The instructions simply sound like the ground everyone was waiting to stand on.
    - scene: The building alarm went off mid-meeting, and within a minute the whole floor was following your voice to the stairwell. Nobody elected you. By the time everyone stood outside counting heads, it seemed obvious that they always would have.
    - outside: People obey your stillness more than they obey other people’s shouting. Committees route hard calls to you without formally deciding to, and visitors assume you hold a title two levels above the one on your door. The assumption does your paperwork for you.
  - **Siege-proof**
    - trait: Outlasting is your actual weapon, and you know exactly how long you can hold. Pressure campaigns, difficult vendors, slow disputes: your position is stocked for winters other people never planned for. You do not need to win quickly. You need to still be there.
    - scene: The negotiation dragged into its fourth month, and the other side started making mistakes born of impatience. You had scheduled your patience in advance, supplies and all. The terms you signed in month five were the ones you wrote in week one.
    - outside: Rivals who try to rattle you end their campaigns tired and on schedule. Colleagues have watched vendors, auditors, and one memorable landlord take a run at your position and slide off it. Waiting you out has been tried many times. It has not once worked.
- **Keyword ledger, friction:**
  - **Walled-up**
    - trait: Defenses are your first architecture, and by now they go up before anything has attacked. New ideas, new people, new plans all get met at the gate and asked for papers. The walls keep trouble out. They keep a good deal else out with it.
    - scene: The proposal died in your inbox behind three clarifying questions and a request for precedent. It was a good proposal. The author knew better than to push, which is exactly how the last four good proposals ended, quietly, at the wall.
    - outside: People pitch to you the way they approach a fortified city, with supplies, patience, and low expectations. Half of them no longer bother. What feels like standards from inside the walls looks, from the road, like a gate that stopped opening years ago.
  - **Heavy-handed**
    - trait: Force is your default tool, even for jobs that needed a lighter one. The email that required one sentence got a policy. The teenager who needed a talk got a lockdown. Every response lands heavier than the problem, and the problem learns to hide instead of heal.
    - scene: Someone missed one deadline, and by Friday there was a tracking sheet, a check-in meeting, and a new rule with their situation’s shape pressed into it. The sheet outlived the problem by a year. Everyone still fills it in, quietly resenting its birthday.
    - outside: People stopped bringing you small problems, because your solutions never come in small. They handle things quietly and tell you afterward, or never. It reads to you as being kept out of the loop. It reads to them as keeping the peace affordable.
  - **Grinding**
    - trait: Pressing on is your answer to almost everything, including the things that needed releasing instead. The project grinds, the argument grinds, the schedule grinds, and your grip never loosens on its own. Endurance this strong has forgotten that stopping is also a decision.
    - scene: Year three of the side business that broke even in year one and never grew. Every Sunday night, the same four hours go in. You have stopped asking whether it works. The work itself became the answer, and the question quietly left.
    - outside: People admire your persistence first, then worry about it. From nearby, the grind stopped looking like ambition somewhere along the way and started looking like a stone you cannot put down. Friends have begun asking, gently, what would happen if you just set it there.

---

### 土_伤官 · Earth × 伤官

- **Structural interaction:** Fire generating Earth cross-polarity — warmth building structure beyond expectation
- **Overview (k2_overview):** Your Earth moves as the Virtuoso: ground that refuses to stay flat. You produce solid, startling things, the building nobody zoned, the old order reimagined from bedrock. Your rebellion wears work boots. It shows up early, builds the alternative, and lets the results argue. Slow genius, permanent output.
- **Functional line (k2_functional):** You express in built things: the model, the prototype, the standing proof.
- **Adjective chips:** catalyst Ground-breaking · Deadpan · Unconventional | friction Contrarian · Eye-rolling · Quake-prone
- **Ruling domain · Talent:** Your talent is constructive genius: making real what others only pitch. It compounds with patience, so pick projects worth years. Your monuments will outlast every clever thing said about them.
- **Ruling domain · Performance:** You perform through results: the opening day, the finished span, the harvest weighed. Let there be openings, invite people to what you built. Even mountains benefit from an unveiling.
- **Ruling domain · Defiance:** Your defiance is seismic: rare, slow, landscape-changing. When you finally move against a structure, you replace it. Use that power on things that matter, not on every irritating fence.
- **Keyword ledger, catalyst:**
  - **Ground-breaking**
    - trait: Breaking new ground is how your expression works: the flat, settled, everyone-agrees surface is exactly where you start digging. Your best ideas arrive as polite earthquakes, reorganizing a topic people thought was finished. The field is never as settled as it looks, and you prove it.
    - scene: The process had been the process for nine years, until your two-slide deck at the retreat. There was a silence, then laughter, then a whiteboard. By spring the old process was a story people told, and you were somehow not officially credited.
    - outside: Managers learn to seat you carefully, because whatever the group has quietly agreed not to question is the first thing you will question. Half the time it is uncomfortable. The other half, the thing you dug up was the exact rock the plan was about to hit.
  - **Deadpan**
    - trait: Dry is your native register. The joke arrives flat, two beats late, and lands harder for it, usually while everyone else is still being earnest. Humor is how your truth gets past security. People laugh first and only later notice what you actually said.
    - scene: In the middle of the budget meeting’s third lap around the same point, you said one quiet sentence and the table broke. The meeting ended four minutes later with a decision. Your sentence had the decision folded inside the joke, which everyone realized on the stairs.
    - outside: People quote you at dinners you were not invited to. The deadpan reads as harmless right up until someone writes it down, and there, in plain text, is a fairly serious critique of how things are run. You have been warned about this. The warnings were also quoted.
  - **Unconventional**
    - trait: Doing it the standard way physically bothers you, the way a crooked picture frame bothers other people. Your methods look wrong until the results arrive. The spreadsheet is shaped strangely, the pitch skips the template, and both work for reasons the template never considered.
    - scene: You taught the training session backward, results first, theory never. The feedback forms split perfectly: half the class wanted the old slides back, half said it was the first training they had ever stayed awake for. You kept the backward version and the split.
    - outside: Coworkers describe your methods with a hand gesture, because words take too long. Nobody fully approves and nobody interferes, since the last person who standardized your workflow watched output drop by half. You are the licensed exception, and the license renews on results.
- **Keyword ledger, friction:**
  - **Contrarian**
    - trait: Disagreeing arrives before your reasons do, and sometimes instead of them. Whatever the group settles on, something in you stands up to unsettle it. Being the counterweight was useful so often that it became a reflex, and now it fires even when the scale was balanced.
    - scene: The team finally aligned after three weeks, and your hand went up with a fresh objection you half believed. The alignment wobbled, the meeting ran long, and afterward you privately admitted the plan had been fine. The objection just refused to stay seated.
    - outside: People have started pre-gaming your objections, guessing them in advance and drafting answers before you speak. It works as a system. It also means your yes has quietly lost its market value, because everyone prices in a no from you regardless of the question.
  - **Eye-rolling**
    - trait: Contempt leaks out of you through the smallest muscles, and everyone catches it. The sigh, the half-second stare at the ceiling, the pen set down slowly. You never said the meeting was stupid. Your face published a full review before your mouth said anything.
    - scene: Someone junior presented an idea you had watched fail in 2019, and your eyebrow filed its report before slide two. They finished shakily and never pitched again in your presence. You remember the flaw in the idea. They remember the eyebrow.
    - outside: People rehearse before telling you things, and the rehearsal is about your face. What feels to you like honest quality control lands as a toll on everyone bringing you anything unfinished. The unfinished things have started routing around you, which is how you lose first drafts forever.
  - **Quake-prone**
    - trait: Long stillness, then the crack: your frustration stores itself quietly and spends itself all at once. Months of fine, fine, fine, and then one Tuesday the ground moves and everyone nearby learns what was actually underneath. The eruption feels sudden to them. It was years old to you.
    - scene: It was the dishwasher being loaded wrong that finally did it, which everyone understood was never really about the dishwasher. Eight months of swallowed remarks arrived in four unscheduled minutes. The kitchen went very quiet. The actual issue, named at last, turned out to be workable.
    - outside: People near you learn to read the ground: the shorter answers, the tidier desk, the way your jokes stop. They start walking softly weeks before you blow, which means the whole household holds its breath on a schedule you set and cannot see.

---

### 土_偏印 · Earth × 偏印

- **Structural interaction:** Earth generating Metal same-polarity — stability as quiet source of precision
- **Overview (k2_overview):** Your Earth carries the Alchemist’s current: nourishment that arrives as understanding rather than comfort. This is ground that reads before it feeds, soil that turns experience over slowly until it becomes insight. It shelters you the way a library shelters, quiet, stocked, slightly apart, and it asks one rent: time alone to do the turning.
- **Functional line (k2_functional):** Thinking runs deep and sideways. You digest slowly, connect strangely, and surface with conclusions no straight line could have reached.
- **Adjective chips:** catalyst Deep-reading · Unhurried · Inventive | friction Withdrawn · Brooding · Overprepared
- **Ruling domain · Learning:** Learning is where this Earth feeds you best. Not the classroom kind so much as the deep private kind: the obsession studied at midnight, the field entered through the side door. Give it one strange subject at a time and it will quietly out-earn every credential in the house.
- **Ruling domain · Intuition:** The hunch arrives before the reason does, and for you it is usually load-bearing. Treat the sudden knowing as a first draft: trust it enough to write it down, doubt it enough to check the math by morning.
- **Ruling domain · Solitude:** Time alone is this energy’s rent, and it collects whether you schedule it or not. Taken on purpose, solitude turns into your best material. Taken by accident, it curdles into distance from the people who were waiting outside the study.
- **Keyword ledger, catalyst:**
  - **Deep-reading**
    - trait: Taking things in whole is how your mind works, even when the world calls it slowness. You do not sample, you absorb, and what you absorb becomes permanent equipment. Understanding, for you, is not a pass through the material. It is ownership.
    - scene: One book, read twice, with notes in the margins the second time through. That is your whole method, and it quietly beats the forty skimmed summaries everyone else is stacking. Ask you about it in a year and it is still there, organized and ready.
    - outside: People mistake your pace for being behind, right up until they need someone who actually understood the material. Then they come to you. What reads as slow from the outside is your mind refusing to accept anything it has not fully chewed.
  - **Unhurried**
    - trait: Waiting before you speak is a habit you built on purpose, and it earns its keep. Your thinking has one speed, thorough, and pressure has never successfully changed the setting. What comes out late comes out finished, and people have learned the trade is worth it.
    - scene: The meeting moves fast, everyone answers inside five seconds, and you say nothing for a while. Then your answer arrives, last and unhurried, and it is the one that ends up in the notes. It took you longer because you were finishing the thought.
    - outside: Faster colleagues sometimes read your silence as having nothing to say. The ones who stay long enough learn the pattern: pressure speeds everyone else up and leaves your pace exactly where it was. What you lose in quickness you keep collecting back in accuracy.
  - **Inventive**
    - trait: Your best ideas come in from odd corners, and trusting them is a skill worth building. Your mind connects things underground, without appointments, and hands the results up when they are ready. The sources look random to everyone else. The record says otherwise.
    - scene: The answer to a work problem shows up while you are reading a cookbook, or on a bus, or inside an uncle’s offhand story. It happens too often to be luck. Your mind connects things underground, in the dark, and hands you the result later like it was easy.
    - outside: Nobody watching you would call it research. A cookbook here, a detour there, an afternoon lost to something unrelated, and then you surface with an idea no straight line could have reached. The people who work in straight lines have learned to stop asking how.
- **Keyword ledger, friction:**
  - **Withdrawn**
    - trait: Pulling back is where you rest, long before it is any kind of reaction. Company drains a battery in you that solitude recharges, and the door drifts toward closed on its own schedule. Nothing has to go wrong first. The pulling back is the baseline.
    - scene: Three drafts of a two-line reply sit on your phone, and the phone sits face-down through dinner. Nothing about the message is hard. The withdrawing happens earlier than that, somewhere between thinking a thing and letting anyone watch you think it.
    - outside: People stop hearing from you and assume something happened. Usually nothing did, and that is the part worth noticing: the quiet was never a response to anything. Given no reason at all, your door still drifts toward closed, and someone else always has to knock first.
  - **Brooding**
    - trait: Holding a thought long after it stops being useful is your mind’s oldest habit. What enters you does not leave on time: it settles, replays, and files itself under unfinished, permanently. All that replaying feels like processing. Mostly it is wear.
    - scene: It is Thursday night and Tuesday’s conversation is still running, paused at the one sentence you would take back. You have replayed it enough times to know it will not change, and you replay it anyway, because putting a thought down was never something anyone taught you.
    - outside: From the outside you just seem quiet. Inside, a committee has been in session since Tuesday, reviewing one sentence from a conversation everyone else forgot. What people read as calm is often storage, thoughts settling in layers and staying down longer than they ever needed to.
  - **Overprepared**
    - trait: Getting ready is where you hide, and it photographs as diligence from every angle. As long as you are still preparing, nobody can grade the real attempt, and part of you has arranged your studying life around that protection. Somewhere the preparing stopped serving the step and started replacing it.
    - scene: Seventeen browser tabs, two saved courses, a notebook full of plans. The project they all point at has not moved in a month, but the researching of it has never gone better. One more book, you tell yourself, and the telling sounds exactly like last time.
    - outside: To everyone watching, you are the responsible one, always studying, always ready. Only you know the math underneath: as long as you are still getting ready, nobody can say you failed. It is a clever shelter, and it keeps out progress as reliably as it keeps out judgment.

---

### 土_偏财 · Earth × 偏财

- **Structural interaction:** Wood directing Earth broadly — reach ranging across stable material
- **Overview (k2_overview):** Your Earth moves as the Horizon: ground that acquires. You accumulate opportunity the way land accumulates value, steadily, tangibly, with paperwork. Your ventures have foundations, your windfalls become holdings, and your generosity comes deeded. Fortune trusts you because you give it somewhere to live.
- **Functional line (k2_functional):** You acquire deliberately: surveyed chances, patient closings, ownership that sticks.
- **Adjective chips:** catalyst Shrewd · Well-traveled · Overflowing | friction Land-hungry · Never-settled · Spread-thin
- **Ruling domain · Opportunity:** Your opportunities are tangible: property, inventory, businesses with floors and keys. You distrust vapor correctly. Walk the ground before buying it, and buy ground more often than promises.
- **Ruling domain · Ventures:** Your ventures should hold weight: real assets, real product, margins you can stack. Compound patiently. In your hands, boring holdings quietly outperform everyone’s exciting stories.
- **Ruling domain · Father:** The father-thread is foundational: a paternal figure tied to property, provision, or their weighty absence. What he built or failed to build shaped your acquiring. Build yours on your own survey.
- **Keyword ledger, catalyst:**
  - **Shrewd**
    - trait: Reading the real value of things is your standing talent, and it works on houses, people, and offers alike. You see the water damage behind the fresh paint and the good bones behind the ugly listing. Bad deals rarely survive your first slow walk around them.
    - scene: Everyone else toured the staged interior. You spent nine minutes in the basement with a flashlight and offered twelve percent under asking, with reasons attached. The sellers argued, then folded. Two years later the neighbors are still asking how you got that price.
    - outside: Friends bring you their contracts the way people bring jewelry to an appraiser. You flip straight to the page where deals go wrong, and you are rarely wrong about which page that is. Your fee is a coffee, and the savings have bought several people cars.
  - **Well-traveled**
    - trait: Ground you have personally covered is your actual education. Markets, cities, kitchens, border towns: you learn places by standing in them, and every trip quietly becomes inventory. When a decision needs context, you usually have some, bought at the price of having been there.
    - scene: The supplier problem stumped the office for a week, and you solved it with one call to a man you met at a trade fair in 2021, in a city nobody else could place. The office called it luck. Your contact list calls it coverage.
    - outside: People assume your stories are exaggerated until they travel with you once and watch three strangers in two cities greet you by name. The network was not built at desks. It was built at long tables, and it keeps paying for itself in favors.
  - **Overflowing**
    - trait: Plenty follows you around, and you spread it without doing the math. The garden overproduces, the table seats extras, the referral goes out before being asked for. Abundance is your operating assumption, and somehow the assumption keeps proving itself right.
    - scene: You came back from the weekend market with too much of everything, again, and by Sunday night four households had bags on their porches. Nobody keeps score, least of all you. Somehow your own porch is never empty either, which you have stopped calling coincidence.
    - outside: Around you, people relax about money in a way they cannot explain. There is always somehow enough, and some extra, and a plan for the extra. Scarcity thinking finds no soil at your table, and guests leave having borrowed a little of your assumption.
- **Keyword ledger, friction:**
  - **Land-hungry**
    - trait: Wanting more ground is a hunger that eating does not fix. The bigger house asked for a better car, which asked for the second property, which asks nightly for a third. Each acquisition was supposed to be the last one. The hunger signs nothing and remembers nothing.
    - scene: You opened the property app at eleven again, two years after buying the place that was supposed to end the searching. Saved listings: forty-one. The current house, by any honest measure, is enough. Enough has somehow never once felt like the finish line it promised to be.
    - outside: Friends hear about each new purchase with congratulations that have grown slightly careful. They can see the pattern you narrate as progress: the goalposts move the week you reach them. Somebody once asked what amount would finally be enough. The pause afterward answered better than you did.
  - **Never-settled**
    - trait: Staying put itches. Six months into any arrangement, your eyes drift to the exits: the next city, the next market, the next better setup. The moving was exciting the first several times. Somewhere along the way it stopped being motion toward anything and became the motion itself.
    - scene: The boxes from the last move were still flat-packed in the closet when you started browsing rentals in a city you visited once. Your lease has eight months left. Your address book has three crossed-out entries per person, and your friends now write yours in pencil.
    - outside: People love you from a slight distance, because the distance keeps changing. Invitations come with a built-in question mark, since nobody is sure which city you answer from this season. The freedom is real, and so is the pencil everyone writes your address in.
  - **Spread-thin**
    - trait: Your holdings outgrew your hands a while ago. The properties, the side hustles, the commitments across three time zones all technically function, and all of them get a thinner slice of you each season. Everything is covered. Nothing is tended. The difference is starting to show.
    - scene: Sunday was for the rental’s leaky tap, the market stall’s inventory, the cousin’s business plan, and the neglected tax folder. Each got forty minutes and none got finished. You fell asleep mid-list. The tap is still dripping into a bucket that has its own schedule now.
    - outside: From outside, your empire looks impressive, and up close it looks tired. Tenants wait longer, partners chase you for answers, and the best opportunity of last year slipped past while you were patching the worst one. Everyone can see the stretching except the person stretched.

---

### 土_劫财 · Earth × 劫财

- **Structural interaction:** Stability meeting stability cross-polarity — ground competing with ground
- **Overview (k2_overview):** Your Earth moves as the Rival: ground that expands by wager. You bet acreage where others bet coins, patient about the campaign, bold about the claim. Shared land, family stakes, and joint holdings follow you through life. You win them by daring and keep them by the paperwork you almost skipped.
- **Functional line (k2_functional):** Your energy is heavy machinery: slow to start, formidable engaged, needing scheduled idle.
- **Adjective chips:** catalyst Ground-taking · Tenacious · Unbroken | friction Territorial · Holds grudges · Bulldozing
- **Ruling domain · Rivalry:** Your rivalries are territorial and patient: the competing shop, the sibling’s acreage, the slow contest of estates. Compete by building better rather than holding harder. Ground won by improvement stays won.
- **Ruling domain · Shared stakes:** Everything significant you own will at some point be co-owned: family land, joint ventures, marriages of assets. Survey early, deed clearly, and revisit the map annually. Your fortune lives in shared soil.
- **Ruling domain · Boldness:** Your daring moves mountains occasionally: the land bought unseen, the advantage taken calmly. Because your bets are heavy, space them. Earth recovers slowly from the ones that slide.
- **Keyword ledger, catalyst:**
  - **Ground-taking**
    - trait: Advancing is how your body answers the world: a foot in the door, a stake in the ground, a seat claimed at tables you were not quite invited to. You expand quietly and hold what you take. By the time anyone objects, you are already infrastructure.
    - scene: The abandoned corner of the office became your project station one shelf at a time, over six unremarkable weeks. Nobody approved it and nobody could unwind it, since by then the whole team used it. Management eventually labeled it, which is how conquest gets certified.
    - outside: People discover your influence the way surveyors discover fences: already installed, weathered in, slightly past the property line. Nobody remembers granting the territory, and everybody relies on how well you run it. Complaints tend to die out on the walk over.
  - **Tenacious**
    - trait: Letting go is simply not in your body’s vocabulary. The application gets resubmitted, the door gets knocked on again, the no gets treated as a scheduling issue. What you grip, you keep gripping, well past the point where everyone else’s hands opened.
    - scene: The permit was denied twice, and the third application had photographs, precedents, and a cover letter that quoted the inspector back to himself. It passed. The clerk who stamped it said, with respect, that they hoped never to see your name again.
    - outside: Opponents budget extra rounds for you, because your first defeat is just your intake meeting. People who watched you lose in March have learned not to celebrate, since your Aprils have a reputation. Eventually the resistance factors you in like weather and yields early.
  - **Unbroken**
    - trait: Pressure that bends other people mostly just settles your stance. Criticism, setbacks, the year everything went wrong: your posture after each one is level ground. You take the hit, absorb it, and stand where you stood, which is its own kind of answer.
    - scene: The venture failed publicly, and you showed up Monday at the usual hour with an ordinary face and a revised plan. The people waiting to see you diminished waited all week. By Friday they were reading the plan, mostly to learn what standing back up looks like.
    - outside: People stop testing you after the first time they watch a real blow land and change nothing. The steadiness reads as almost unfair. Behind your back, the description is always some version of the same sentence: whatever happens, that one stays standing.
- **Keyword ledger, friction:**
  - **Territorial**
    - trait: Yours is a word your body enforces before your mind gets consulted. The parking spot, the project, the Sunday routine: incursions get met with a speed that surprises even you. Most of the invasions were imaginary. The defense spending has been extremely real.
    - scene: A new hire touched your client file with good intentions, and the temperature of your reply preserved itself in the team’s memory for a year. They were trying to help. The help never came back, and now the workload is defended and entirely yours.
    - outside: Colleagues navigate your territory with a map they keep updated among themselves: what not to touch, which chair is yours, when to ask versus announce. Cooperation with you has border-crossing paperwork. Some people just trade elsewhere, and you file that as respect.
  - **Holds grudges**
    - trait: You keep score with geological patience. The slight from 2019 is filed, cross-referenced, and quietly load-bearing in how you treat its author. Forgiveness feels like surrendering land. So the ledger grows, and you pay its storage costs nightly without auditing what the grudges rent.
    - scene: You attended the wedding and were pleasant all evening to the cousin, who never knew that the seating, the small talk, and the early exit were all footnotes to a loan unreturned in 2017. It was sixty dollars. The interest is now a relationship.
    - outside: People sense the ledger without seeing it. There is a slight tax in how you greet certain names, a coolness with fifteen-year-old foundations. Newcomers get warned in shorthand: do not end up in the book. Nobody can say exactly how one gets out of it.
  - **Bulldozing**
    - trait: When you want something, obstacles register as terrain rather than as people. The plan rolls forward, objections get graded flat, and you genuinely do not hear the crunch. Afterward the path is open and efficient, and someone behind you is holding pieces of their fence.
    - scene: The family holiday got decided in one message, yours, sent before the poll you had proposed finished collecting votes. Three people had conflicts. The trip was excellent and efficiently run, and two of the three still bring up the poll, humorously, in a specific tone.
    - outside: People agree with you in meetings and then meet again, smaller, without you. It is not sabotage. It is the only lane where their input survives contact. You keep winning the official votes and losing informal ones you never find out happened.

---

### 土_正印 · Earth × 正印

- **Structural interaction:** Earth generating Metal cross-polarity — stability nourishing precision and opening direction
- **Overview (k2_overview):** Your Earth moves as the Sage: mother ground, nurture in its home element, doubled. You hold people the way land holds houses, unconditionally, for generations, without once mentioning the load. Wisdom settles in you and stays. The whole village builds on your patience. Somewhere in the acreage, keep a field that feeds only you.
- **Functional line (k2_functional):** You think in generational wisdom: what held the family, what will hold it next.
- **Adjective chips:** catalyst Grounding · Enduring · Sustaining | friction Closed-off · Buried · Unmoving
- **Ruling domain · Knowledge:** Your knowledge is settled sediment: practical wisdom layered by years, the kind villages consult. You know what actually works. Write the almanac down. Ground should not be the only copy.
- **Ruling domain · Shelter:** Your shelter is the family land itself: people return to you between every attempt at the world. Being home is holy work with no clock. Post seasons. Even land lies fallow.
- **Ruling domain · Mother:** The mother-thread is bedrock here: nurture received deep or a hollow you filled by becoming the ground yourself. Either origin made you everyone’s home. Claim one plot back.
- **Keyword ledger, catalyst:**
  - **Grounding**
    - trait: Steadying other minds is something your presence does before you say anything. Panicked friends arrive spinning and leave walking. You ask the slow questions, name the one thing that is actually true, and the drama finds it has nowhere to plug in.
    - scene: Your sister called at midnight in full spiral about the diagnosis, the job, the everything. Forty minutes later she was laughing at something small and making a list for Monday. You mostly said mm, and what do we actually know. The list worked.
    - outside: You are the call people make after the panicked calls. Friends describe visiting you in weather terms, saying the pressure drops at your kitchen table. Nobody can quote what you said that fixed things, because it was never the words. It was the ground under them.
  - **Enduring**
    - trait: Your mind holds its positions across years the way soil holds fence posts. What you learned stays learned, what you believe survives fashion, and the people you decided to love are loved on a standing basis. Time passes through you without washing much away.
    - scene: You still send the birthday message to your third-grade teacher, thirty years on, and still make the soup from the recipe card whose handwriting has almost faded. Fads have come through the house and left again. The card stays taped inside the cupboard door.
    - outside: People park their trust with you long-term, the way families keep valuables at one grandmother’s house. Friends who drift for five years return to find their spot kept, their story remembered, their coffee order intact. Around you, time behaves less like loss.
  - **Sustaining**
    - trait: Feeding minds is your quiet occupation. The right book arrives from you at the right month, the question that untangles a stuck decision arrives on the right walk, the belief in someone mid-doubt gets held steady. You resource people the way rain resources fields, regularly and without ceremony.
    - scene: You mailed your nephew a used paperback with one sentence underlined, and eight years later he mentioned it in his graduation speech. You had forgotten the book entirely. He had built a career on the underline, which is roughly how your influence usually surfaces.
    - outside: Half the steady people in your circle turn out, on inspection, to be running on something you supply: the monthly call, the standing dinner, the belief held on their behalf during a bad season. Nobody calls it mentoring. Everybody knows where the well is.
- **Keyword ledger, friction:**
  - **Closed-off**
    - trait: Your mind trusts its home ground and quietly stopped traveling. The same three sources, the same trusted voices, the same conclusions wearing deeper into the same paths. New input has to marry into the family to be heard. The walls were comfort once. Now they are also the view.
    - scene: The article that challenged your position went unread for a month, then unread permanently. At dinner you summarized its argument anyway, slightly wrong, to nods from the same four people who always nod. The dinner was warm. It is always warm, and always the same temperature.
    - outside: People outside your circle have learned that new ideas do not take root at your table without a local sponsor. Your world runs on trusted soil, which makes it stable, and which means the news reaches you late, softened, and pre-agreed-with.
  - **Buried**
    - trait: Your real thoughts live at depths where nobody digs, including you. Feelings get filed under fine, wants get deferred until the ground is somehow ready, and decades pass with the important things interred and load-bearing. The surface stays tidy. The weight underneath is measurable.
    - scene: Cleaning the study, you found the application you never sent, the one from eleven years ago. You read it standing up, put it back in the drawer, and reorganized the shelf above it instead. The drawer closed with the sound drawers make. Dinner was on time.
    - outside: Even people who love you navigate by echo, guessing at what moves beneath the calm. Big life news arrives from you pre-processed, months late, announced like weather that already passed. They have stopped asking how you feel and started asking what you have decided.
  - **Unmoving**
    - trait: Staying put has become your mind’s answer to open questions. The decision waits, the plan rests, the possibility sits in its chair until it stops asking. Nothing is refused outright. Things are simply outlasted, and the stillness does the declining on your behalf.
    - scene: The evening-course brochure has been on the counter since March, under the fruit bowl, slightly stained now. You are not against it. You are not anything about it, which the brochure has slowly learned. In June someone will move it to the drawer.
    - outside: People pitch things to you once, watch the idea sink into the calm and not come back up, and quietly withdraw it. Your no is never spoken. It is just that yes would require motion, and around you, motion has learned not to volunteer.

---

### 土_正官 · Earth × 正官

- **Structural interaction:** Earth setting standard for Water cross-polarity — containment asking whether depth has form
- **Overview (k2_overview):** Your Earth moves as the Magistrate: bedrock law, order with geological patience. You hold standards the way mountains hold borders, unmoved, unhurried, outlasting every argument. Institutions rest on people like you. The honor is real and so is the load. Survey what you carry, and set down the duties that were never yours.
- **Functional line (k2_functional):** You are the standing wall others build against: order is less your duty than your substance.
- **Adjective chips:** catalyst Rock-steady · Fair · Load-bearing | friction Slow-moving · Rule-bound · Set-in-stone
- **Ruling domain · Career:** Your career is foundation work: operations, governance, the roles that hold everything up. Advancement comes as accumulated trust. Claim the title when it is due. Bedrock underasks.
- **Ruling domain · Status:** Your standing is landmark-grade: slow to build, nearly impossible to erode. People locate themselves by you. Accept the monument quietly and stay reachable at ground level.
- **Ruling domain · Order:** Your order is settled ground: rules that feel less like commands than terrain. Things stay where you put them. Walk the fences yearly. Even terrain shifts, and you shift last.
- **Keyword ledger, catalyst:**
  - **Rock-steady**
    - trait: Reliability is your signature act, performed so long it stopped being a performance. You are where you said, when you said, doing what you agreed. Whole systems, families, and rosters get planned around the fact of you holding, and you simply keep holding.
    - scene: In eleven years you have missed the Thursday pickup twice, both hospital-grade reasons, both with a backup already arranged. The coach plans the schedule around your name first. Somewhere a whole carpool’s architecture rests on a person who just does not cancel.
    - outside: People stop confirming with you after the first year, which is its own trophy. Plans that touch you are considered anchored. When someone flakes, the group’s sentence is always the same: at least we know so-and-so is coming. You are the so-and-so.
  - **Fair**
    - trait: Fairness runs your decisions even when favoritism would be cheaper. The rules apply to your favorite and your rival at the same rate, and to you first of all. People may dislike your ruling. They have stopped questioning how you reached it.
    - scene: You gave your closest friend the same late penalty you gave the stranger, and paid your own penalty the month your half of the paperwork slipped. The friend sulked for a week. The system survived, and it survives specifically because everyone watched you charge yourself.
    - outside: Disputes come to you pre-softened, because both sides expect straight scales and dress accordingly. Your judgment gets borrowed by people who cannot agree on anything else. Being trusted like that is quiet, unpaid work. You do it anyway, and the peace holds.
  - **Load-bearing**
    - trait: Heavy things migrate to you because you keep accepting them, and structures form on top. The team’s hardest account, the family’s paperwork, the club’s finances: whatever must not fail gets filed under your name. You carry it evenly and rarely mention the tonnage.
    - scene: When the audit came, three departments discovered that their processes all ran through one spreadsheet you maintain at seven each Monday. Nobody had documented this. The auditor asked what happens if you go on holiday. The silence answered thoroughly, and the holiday remains imaginary.
    - outside: People sleep better because certain things are yours, and most could not list what those things are. The load only becomes visible when you are sick for a week and four small systems wobble. Everyone notices then. Everyone forgets again by the next quarter.
- **Keyword ledger, friction:**
  - **Slow-moving**
    - trait: Your pace has one setting, geological, and urgency does not shift it. The decision will be right and it will be late, in that order. Opportunities with expiry dates keep expiring in your in-tray while the due diligence achieves its usual thoroughness.
    - scene: The apartment was perfect, and your offer went in nine days later, complete, signed and stamped, and third in line. The winning bid was written on a kitchen counter the first evening. You reviewed your process afterward, carefully, over several weeks.
    - outside: People bring you decisions early, padding for your timeline the way airlines pad schedules. Fast-moving partners have learned to route the urgent things around you and apologize later. Your thoroughness is real, and it keeps buying quality with time that some things did not have.
  - **Rule-bound**
    - trait: The rule outranks the situation for you, even when the situation is standing right there. Exceptions feel like structural damage, so the form gets filled, the channel gets followed, the spirit occasionally suffocates inside the letter. Order is kept. What order was for gets misplaced.
    - scene: The refund was obviously deserved, and you declined it because the receipt was two days outside the window. The customer left angry and told the story often. Head office would have approved the exception. The window had not, and you answer to windows.
    - outside: People experience you as a well-run tollbooth: fair, predictable, and immovable at exactly the moments that needed a human. Colleagues save their workarounds for your days off. The rules you enforce so faithfully were written by people who assumed more discretion than you spend.
  - **Set-in-stone**
    - trait: Once your position sets, it sets. New evidence arrives and finds the concrete already cured. You call it consistency, and it often is, and sometimes it is just the memory of a decision outliving every reason that made it.
    - scene: You still refuse that vendor over an incident from 2016 whose participants have all left both companies. The current rep is excellent, and their quote came in lowest. The stone does not read quotes. The stone remembers 2016, and the contract went elsewhere, again.
    - outside: People have stopped bringing you second chances, for vendors or for people, because the outcome is pre-decided. Your world is firm, and its firmness is finished. In the archive of closed cases sit a few that deserved reopening, and everyone knows which ones except you.

---

### 土_正财 · Earth × 正财

- **Structural interaction:** Wood directing Earth cross-polarity — reach shaping stability into structured cultivation
- **Overview (k2_overview):** Your Earth moves as the Steward: ground that keeps. This is stewardship in its home element, doubled: holdings maintained, households provisioned, value settled into soil. What enters your care appreciates. The risk is weight for its own sake. Keep the estate serving the family, not the family serving the estate.
- **Functional line (k2_functional):** You maintain relentlessly: the fixed fence, the paid tax, the kept schedule.
- **Adjective chips:** catalyst Thrifty · Steady · Well-stocked | friction Hoarding · Immobile · Cheap
- **Ruling domain · Wealth:** Your wealth is literal ground: property, durables, enterprises with deeds. In your element, holdings hold. Diversify just enough that one bad season cannot take the whole farm.
- **Ruling domain · Savings:** You save geologically: layers on layers, bedrock reserves. The craft is knowing enough. Set the number, then let the surplus fund life above ground.
- **Ruling domain · Steady love:** You love in permanence: home built, name shared, decades assumed. It is the marrying ground itself. Bring the assumption out loud sometimes. Even bedrock likes being chosen again.
- **Keyword ledger, catalyst:**
  - **Thrifty**
    - trait: Getting full value out of things is a craft you practice daily and almost invisibly. The repaired instead of replaced, the bought-once-properly, the leftovers built into a second dinner. Waste offends you mildly and constantly, and your accounts show what mild constant offense saves.
    - scene: The winter coat is on its ninth season, re-zipped twice by the tailor whose name you know. Colleagues in this year’s jackets tease you about it. The retirement account you never mention could quietly buy everyone at the table a coat store.
    - outside: Nobody watched you be careful, and everyone sees what the care built. The coat is nine seasons old and the house is paid for, a math the flashy spenders around you have slowly started doing out loud. You never once explained it. The results explain it, late and completely.
  - **Steady**
    - trait: Holding course is your competitive advantage in a distractible world. The plan from January is still the plan in September, adjusted, funded, on schedule. Shiny alternatives pitch themselves at you weekly and bounce off politely. What you committed to, you finish.
    - scene: While the group chat cycled through four investment fads in a year, your boring monthly transfer went through forty-eight times, unphotographed. Two of the fads ended badly for people you love. Your account did the thing accounts are supposed to do, quietly, again.
    - outside: People set their watches by your consistency and occasionally roll their eyes at it, until their own zigzags total up. Then they come asking about the boring transfer. You show them the math, kindly, without once saying the sentence you have earned.
  - **Well-stocked**
    - trait: Reserves are your love language and your strategy. The pantry, the savings, the spare parts drawer, the contact who owes you one: whatever the situation needs, some corner of your life already holds it. Emergencies visit you and find the door already answered.
    - scene: During the outage, your house was the one with candles, a charged power bank, cash, and cocoa. Three neighbors ended up in your kitchen playing cards by lamplight. It was, one of them said, the nicest blackout of their life. You had planned for worse.
    - outside: People tease you about the stockpiles until the day they call you from a breakdown lane, a storm, or a sudden expense. You always have the thing. Around you, disasters get downgraded to inconveniences, and nobody fully registers who did the downgrading.
- **Keyword ledger, friction:**
  - **Hoarding**
    - trait: Keeping has stopped being a strategy and become a compulsion with a filing system. Money is stored rather than used, and might-need has annexed the garage. Security was the goal once. Now the piles themselves ask for protection, and you provide it nightly.
    - scene: The garage has not held a car since 2019. It holds four labeled bins of cables for devices you no longer own, kept because throwing them out feels like bleeding. You bought a fifth bin last month. The car sits outside in the weather, losing value.
    - outside: Family negotiates with you before every clear-out, and loses. Guests notice the house has started belonging to its contents. The savings, which are genuinely impressive, work the same way: admired, counted, and never allowed out to actually do anything.
  - **Immobile**
    - trait: Your money and your life share one posture: seated. The cash waits in the account earning almost nothing, the career waits in the safe role, the plans wait for a certainty that never files its paperwork. Waiting feels responsible. Compounded, it has cost more than any risk would have.
    - scene: The savings sat through two boom years at a fraction of a percent while you researched, thoroughly, the accounts you never opened. The research folder is excellent. The difference between it and action, calculated once by your brother-in-law, funded his kitchen renovation.
    - outside: Advisors, friends, and one very patient cousin have all presented you the same numbers and watched them lose to inertia. Nobody doubts your discipline. They doubt the strategy of a fortress that never opens its gates, even to let its own supplies grow.
  - **Cheap**
    - trait: Spending hurts you in a place logic cannot reach, and the people around you absorb the difference. The heating waits until the frost, the tip gets calculated to the coin, the gift arrives practical and slightly under the occasion. The books balance. Warmth pays the levy.
    - scene: At the anniversary dinner you queried one item on the bill, correctly, for four dollars. The table went quiet in a way the four dollars did not buy back. Your partner said nothing then and remembered it at strange moments for a year.
    - outside: People plan around your tightness with small workarounds: they book the restaurant, buy the better wine themselves, stop suggesting trips. You read it as everyone overspending. They read the flinch that crosses your face at every bill, and they have stopped bringing you their celebrations.

---

### 土_比肩 · Earth × 比肩

- **Structural interaction:** Stability amplifying stability — holding force deepening without movement
- **Overview (k2_overview):** Your Earth moves as the Twin: ground that holds its own plot beside everyone else’s. You are the neighbor with the straight fence, generous across it, immovable about where it runs. Belonging matters to you, but merger does not. You stand with people the way hills stand in a range: together, and entirely yourselves.
- **Functional line (k2_functional):** Your energy is bedrock steady: unhurried, unshakable through long loads, renewed by routine.
- **Adjective chips:** catalyst Self-grounded · Solid · Dependable | friction Dug in · Hard-headed · Set-apart
- **Ruling domain · Peers:** Your peers are landholders like you: solid people with their own ground and no designs on yours. Trade help across fences freely. The neighbors you respect at seventy are the wealth this position promises.
- **Ruling domain · Independence:** Earth independence is owned ground: a home, a trade, a name that stands without cosigners. You will have it, because you refuse alternatives. Just leave a gate in the fence.
- **Ruling domain · Self-reliance:** You carry your own weather and everyone else’s overflow without filing complaints. Twice a year, let someone shovel your side. The ground stays firmer when it is not also the whole world’s floor.
- **Keyword ledger, catalyst:**
  - **Self-grounded**
    - trait: Your footing comes from inside your own boundaries, and it shows in how little you sway. Trends pass, opinions swirl, someone is always panicking about something, and your center of gravity stays home. People push against you mostly to find out where solid feels like.
    - scene: The whole friend group pivoted careers, diets, and philosophies twice in three years. You kept the trade, the routine, and the Sunday walk, cheerfully unmoved. Two of the pivots have since called you asking, sincerely, how a person just stays put and stays fine.
    - outside: In any shaken group, eyes drift to you the way feet find level ground. You rarely offer opinions on the storm of the week. Your steadiness is the opinion, and several people have privately rebuilt their footing using yours as the reference.
  - **Solid**
    - trait: What you build, physically or otherwise, holds weight without creaking. The shelf, the budget, the promise: over-engineered slightly, tested honestly, then trusted completely. Flash was never the point. Your work is the kind people lean on without checking first.
    - scene: The deck you built a decade ago has hosted every family summer since, thirty people at its worst, without one loose board. The neighbor’s newer deck is on its second rebuild. He asked what you did differently. You said screws, and time, and meant both.
    - outside: People assign you the load-bearing jobs without discussion, the way nobody discusses which wall holds the roof. Your name on a task closes the worry about it. It is a quiet reputation, never announced, visible mainly in what people no longer double-check.
  - **Dependable**
    - trait: Showing up is your entire philosophy, executed daily. No dramatic rescues, just presence with a pattern: the shift covered, the call returned, the same seat at the same table when it matters. People build lives partly out of the certainty you supply.
    - scene: When the funeral was announced, three people separately texted to ask if you were going, and all three booked their travel only after you said yes. You had not organized anything. Your attendance was the organization, the fixed point the plans grew around.
    - outside: Your reliability has become infrastructure other people budget on. Bosses give you the accounts that cannot wobble, friends give you the spare keys, family gives you the passwords. Nobody remembers deciding this. Trust just pooled where the ground never shifted.
- **Keyword ledger, friction:**
  - **Dug in**
    - trait: Your positions come with earthworks. The opinion dug in years ago has supply lines, sandbags, and a flag, and updating it now feels like losing a war rather than learning a fact. You defend ground long after anyone remembers what battle claimed it.
    - scene: The debate about the route to the lake house is in its ninth year. There is a faster way, proven twice by phone timers. You drive your way, narrating its virtues, adding twenty minutes. The family has stopped arguing and started packing snacks for the difference.
    - outside: People know which of your topics are trenches and step around them in socks. The map of what cannot be discussed with you grows a little each year. You experience this as peace finally achieved. It is actually conversation rerouted around a fortified position.
  - **Hard-headed**
    - trait: Being told things is not how you learn. The lesson has to bruise you personally before it counts, and even then you sometimes get a second opinion from another bruise. Advice slides off the same skull the wall keeps failing to teach.
    - scene: Three people told you the ladder was set wrong, and you climbed it anyway, and the emergency department nurse asked what happened in the tone of someone who already knew the genre. You retold it later as a story about the ladder. It is not about the ladder.
    - outside: Warning you has become a formality people perform for their own consciences. They say the thing, you do yours, the consequences arrive on schedule, and everyone pretends surprise. What they have actually stopped expecting is the middle step where the warning changes anything.
  - **Set-apart**
    - trait: Standing slightly outside the group is your resting position. Neither hostile nor shy, just fenced: you attend, contribute, and remain somehow adjacent, a property with clear boundaries and one gate. People sense the line without seeing it, and mostly nobody tests the latch.
    - scene: At every gathering there is a point where the group photo assembles and someone has to call your name twice, because you were at the fence, at the grill, at the edge of frame. The album shows a decade of you half-turned, arriving into pictures.
    - outside: People describe knowing you in approximations, even the ones who have known you twenty years. Beloved, reliable, and somehow unvisited. The distance never insults anyone, and never closes either. Eventually friends stop reaching across it and just wave, warmly, from their side.

---

### 土_食神 · Earth × 食神

- **Structural interaction:** Fire generating Earth same-polarity — warmth as natural source of stable deposits
- **Overview (k2_overview):** Your Earth moves as the Artisan: ground that sets a table. Nourishment is your native act, the meal made, the household provisioned, the comfort arranged before anyone asked. You produce abundance the way fields do, reliably and without spectacle. People leave your care fed in ways they cannot fully name.
- **Functional line (k2_functional):** You express through provision more than proclamation. The full pantry is your love letter.
- **Adjective chips:** catalyst Hearty · Settled · Providing | friction Coasting · Sluggish · Pampered
- **Ruling domain · Expression:** Your expression is the kept table: cooking, homemaking, the craft of comfort itself. It looks humble and it is foundational. Whole families run on exactly what you make daily.
- **Ruling domain · Enjoyment:** You enjoy the settled pleasures: harvest meals, familiar comforts, the deep satisfaction of enough. Let abundance be enjoyed, not only stored. A pantry is for feasts as well as winters.
- **Ruling domain · Children:** Children grow sturdy in your keeping: fed on time, held warmly, raised on rhythm. Yours is the house they bring their own children back to. Build it knowing that.
- **Keyword ledger, catalyst:**
  - **Hearty**
    - trait: Your warmth arrives in generous portions, seconds included. The laugh is real and audible from the driveway, the welcome fills doorways, the food comes in servings that assume everyone is recovering from something. People leave your presence heavier and lighter at the same time.
    - scene: You hugged the departing intern on their last day and they cried, then laughed, then took the container of food you had somehow prepared. It was a Tuesday. Nobody else had planned anything. Your goodbyes just come catered, and people remember them for years.
    - outside: Invitations to yours get accepted at a suspiciously high rate, and everyone brings appetites they deny elsewhere. Around your table, people eat like their grandmother is watching and talk like nobody is. The recipe everyone asks for is not really the food.
  - **Settled**
    - trait: Contentment came to you early and never left. The house is enough, the work is enough, tonight’s dinner is a small event worth savoring out loud. Peace like yours reads as quietly radical among people who are permanently mid-upgrade.
    - scene: Friends came over agitated about the market, the election, the everything, and left three hours later having discussed tomatoes, an old trip, and a plan for soup. Nothing was solved. Everything was better. Your kitchen table does this reliably, and nobody can explain the mechanism.
    - outside: People visit you the way city dwellers visit the countryside, to remember a pace exists. Your unhurried answers slow their breathing within the hour. More than one friend has admitted planning a hard week around a stop at your place, medicinal and unofficial.
  - **Providing**
    - trait: Feeding people, literally and otherwise, is your default expression of everything. Congratulations come as dinner, condolences as casserole, apology as pie. Words were never quite your instrument. The stocked plate says what you mean with better grammar than you ever found.
    - scene: When the neighbors’ kitchen flooded, dinner appeared on their porch for six consecutive nights, different each night, unsigned after the second. They knew. Everyone always knows. The seventh night they came to your door with the empty dishes and stayed three hours.
    - outside: There is a shelf of your containers in half the kitchens on the street, waiting to be returned, in no hurry. People measure crises partly by whether your food showed up. It always has, which is why nobody around you fully believes in worst cases.
- **Keyword ledger, friction:**
  - **Coasting**
    - trait: Good enough arrived years ago and you parked there. The skills plateaued where the applause got comfortable, the menu settled into rotation, the questions you ask the world got smaller. Nothing is wrong. That is the anesthetic, and it is working.
    - scene: The restaurant changed its menu and you grieved for a week, which was the biggest event of your quarter. The novel sits half-read since spring. Asked what is new, you laughed and said nothing, thank goodness. Part of you checked whether that was still funny.
    - outside: People stopped inviting you to the ambitious things, the course, the climb, the startup, because your no had become furniture. They meet you where you are, fondly, forever. Somewhere in the fondness is a question nobody asks out loud anymore: what would it take.
  - **Sluggish**
    - trait: Your engine idles low, and everything discretionary waits behind it. The reply sits, the errand rolls to next week, the project gathers a soft dust. It is never refusal, just a body that treats urgency as a rumor and momentum as an occasional guest.
    - scene: The two-minute form took eleven days, which even you found funny once it was done. In between, the reminder emails arrived, were read from bed, and joined the queue. Nothing bad happened. Nothing bad ever quite happens, which keeps the idle running.
    - outside: People pad every request to you with a week, automatically, the way builders pad quotes. The padding works, mostly, and its existence never gets mentioned to your face. Deadlines that genuinely matter get routed to faster hands, along with, quietly, the credit.
  - **Pampered**
    - trait: Comfort is your climate, and discomfort gets treated as a system error. The thermostat, the cushions, the snacks within reach of the good chair: your setup absorbs effort before effort forms. Convenience was the reward once. Somewhere along the way it became the requirement.
    - scene: The camping trip died in the planning stage, again, on the pillow question. There is a version of you that would have loved the campfire. He was outvoted by the version who knows the good chair, the near snacks, and exactly how far the blanket reaches.
    - outside: Loved ones arrange the world around your comforts with amused precision, the right chair saved, the schedule bent around your naps. It is done with love and a faint tiredness. Adventures get planned in sizes that fit inside your comfort, which is to say, small.

---

### 金_七杀 · Metal × 七杀

- **Structural interaction:** Metal pressing Wood same-polarity — the cutting force that doesn't grant permission
- **Overview (k2_overview):** Your Metal moves as the General: edge given rank. Pressure organizes you, crisis promotes you, and your will cuts through what committees cannot. This is the sword in its born office, decisive, disciplined, feared a little and needed often. Command the campaigns worth blood. Sheathe everywhere else.
- **Functional line (k2_functional):** Your rules are field orders: few, absolute, and enforced first on your own conduct.
- **Adjective chips:** catalyst Battle-ready · Disciplined · Surgical | friction Punishing · Ruthless · Blunted
- **Ruling domain · Pressure:** Pressure is your forge: you harden correctly under loads that crack others. Seek arenas with real stakes. Comfort dulls you faster than any enemy could.
- **Ruling domain · Command:** Command fits you like a sword fits its grip: natural, tested, dangerous if idle. Take charge where the mission deserves it, and practice the harder art, releasing command without losing edge.
- **Ruling domain · Crisis:** In crisis you become simple and effective: triage, decision, stroke. People will remember your calm longer than the emergency. Keep one habit for after: cleaning the blade, debriefing the heart.
- **Keyword ledger, catalyst:**
  - **Battle-ready**
    - trait: Readiness is your resting state. The plan B exists before plan A launches, the difficult conversation is pre-rehearsed, the go-bag, literal or mental, stays packed. When trouble finally arrives it finds you already dressed, and the calm of the prepared is your signature entrance.
    - scene: The client called at seven with the emergency everyone else needed a day to process, and you opened the folder you had built for exactly this scenario three months earlier, unasked. The call lasted eleven minutes. The folder had been waiting longer than the emergency had existed.
    - outside: People check your reaction before deciding how scared to be, and your reaction is usually to start executing. Teams describe going into hard weeks behind you the way soldiers describe good sergeants: nobody promises it will be pleasant, everybody knows the plan will hold.
  - **Disciplined**
    - trait: Your discipline is structural steel, not decoration. The habit holds on the bad days, which is the only measurement that counts: the routine survives travel, illness, and success, each of which kills most people’s systems. What you commit to becomes load-bearing, permanently.
    - scene: Two hundred consecutive weeks of the same training schedule, through two job changes and one broken hand, adjusted around the cast rather than paused for it. The physical therapist asked to see the log, then photographed it for her office wall, as evidence of a species.
    - outside: Your consistency reads as almost mechanical until people need to borrow it. Then they discover the practical magic: things placed in your keeping happen, on schedule, indefinitely. Whole projects get architected around your reliability the way bridges get designed around their strongest member.
  - **Surgical**
    - trait: Your interventions are exact. Where others swing wide, you find the one line to cut, the one word to change, the one person to call, and the problem separates cleanly from the situation. Minimal force, placed precisely: it looks effortless and is actually aim.
    - scene: The failing project had eleven proposed fixes on the whiteboard, and you crossed out ten, changed one contract clause, and the entire dispute dissolved by Friday. The team spent the sprint braced for surgery. What happened was closer to acupuncture, and nobody bled.
    - outside: People bring you tangles the way patients bring specialists their worst scans, hoping for precision instead of sympathy, and receiving exactly that. Your fixes rarely need revisiting. The scar tissue around problems you have handled is famously minimal, which is why the referrals never stop.
- **Keyword ledger, friction:**
  - **Punishing**
    - trait: Your corrections carry more force than the error weighed. The missed detail gets a review nobody forgets, the small failure gets a consequence with edges, and people leave your feedback sessions altered. Standards were the point once. The punishment developed its own appetite.
    - scene: The report had one wrong figure in forty pages, and your response, delivered in front of the team, traced everywhere the mistake had come from, for six minutes. The analyst fixed it in one. The other thirty-nine pages were excellent, a fact that attended the meeting silently.
    - outside: People submit work to you the way defendants approach sentencing, hoping for mercy rates you have never once published. The quality around you is genuinely high, and it is maintained the way ports maintain sea walls: through repeated, memorable demonstrations of what happens without them.
  - **Ruthless**
    - trait: When the goal requires it, feelings become line items. The loyal supplier gets cut for two percent, the friendship pauses during the competition, the underperformer is gone before their chair cools. Efficiency this clean wins consistently, and keeps winning things that turn out to have been load-bearing.
    - scene: You replaced the vendor who had carried you through the lean years the same quarter their prices drifted, with a form letter. The numbers improved four percent. At the trade show, their booth and yours no longer greet each other, and people from both companies notice.
    - outside: Partners respect your decisions and pre-negotiate their own exits, having watched how cleanly you cut. Everything about working with you is excellent except the specific temperature of knowing where you stand: valued, always, and always one spreadsheet away from a form letter.
  - **Blunted**
    - trait: Your edge dulled from overuse. The intensity that once cut through anything now grinds through everything: the same force applied to birthday plans and board fights, the same siege posture at breakfast. Constant hardness is not sharpness. Somewhere in the years of pressing, the actual edge left.
    - scene: The vacation had a briefing document. The barbecue had backup plans. When your daughter asked if you could just come to the beach without a plan, the question sat in you strangely for days, because the honest answer was that you no longer remembered how that worked.
    - outside: People stopped bringing you the soft problems, the ones needing a light touch, and the routing decision was mutual and unspoken. What remains in your queue is armor-plated: disputes, deadlines, campaigns. You are excellent at all of it, and the calendar reads like a war ledger.

---

### 金_伤官 · Metal × 伤官

- **Structural interaction:** Earth generating Metal cross-polarity — precision that structurally exceeds its container
- **Overview (k2_overview):** Your Metal moves as the Virtuoso: an edge that performs. You cut with style, argue like a fencing match, and produce work so sharp it draws blood and applause in the same stroke. Standards bore you unless you set them. Authority irritates you unless it earned itself. The world calls it attitude. It is precision refusing dullness.
- **Functional line (k2_functional):** Your wit cuts clean and quotable. People fear your reviews and collect them.
- **Adjective chips:** catalyst Razor-witted · Piercing · Masterful | friction Cutting · Merciless · Judgy
- **Ruling domain · Talent:** Your talent is the brilliant edge: work with finish other people cannot reach. Sign it, show it, price it properly. Metal brilliance that stays sheathed reads as arrogance without the receipts.
- **Ruling domain · Performance:** You perform with precision: the flawless delivery, the duel won in public. Choose stages where exactness shines, competitions, critiques, crafts. Applause for sharpness is the kind you can actually live on.
- **Ruling domain · Defiance:** Your defiance is the refusal to dull: standards no supervisor can lower, corners you will not round. Aim it at shoddiness rather than at every hand holding a clipboard. Rebellion with a portfolio wins.
- **Keyword ledger, catalyst:**
  - **Razor-witted**
    - trait: Your intelligence has an edge you can hear. The observation lands exactly where it aims, the flaw in the argument gets opened in one line, and conversations sharpen when you join them, the way knives sharpen near a good stone. People think faster around you, in self-defense.
    - scene: The consultant’s deck was forty slides of expensive fog, and your one question, asked politely at slide nine, ended the engagement by Friday. The question fit in a text message. The savings fit in a house. Your boss now brings you specifically to be asked things.
    - outside: People quote your one-liners for years, slightly nervously, because the wit that delights them has clearly conducted assessments of them too. Being liked by you reads as certification. Dinner invitations follow you around, and so does a certain care in how people finish their sentences.
  - **Piercing**
    - trait: You say the thing everyone else is carefully not seeing. The flaw in the plan, the motive under the pitch, the number that does not add up: you name it out loud, early, in the meeting, while it can still be fixed. Comfort has never once outranked accuracy for you.
    - scene: Ten minutes into the interview you had located what the polished resume was arranged to hide, and asked about it kindly, and the candidate, after a pause, gave the first honest answer of the morning. You hired her. She later said that question changed how she interviews.
    - outside: People feel read by you and check their own behavior retroactively after conversations. The perceptiveness is unsettling in exactly one direction: nothing performed survives it. Around you, colleagues have learned to bring the real version early, since the other kind just costs an extra meeting.
  - **Masterful**
    - trait: Your skill is built to be witnessed. The presentation, the performance, the flawless run under pressure: you polish until the work holds up in front of anyone, and then you put it in front of everyone. Private excellence never interested you. Excellence, for you, is a public act.
    - scene: Your presentation files get passed around after you leave companies, studied like museum pieces: the pacing, the slides, the answers that seemed pre-loaded for every question. A former colleague admitted keeping a folder named after you, opened before her own big meetings, for calibration.
    - outside: In your field, your name has become an adjective among people who have never met you. New hires get shown your work as the ceiling, which creates two camps: the inspired and the discouraged. Both camps, notably, cite the same files. Neither has matched them yet.
- **Keyword ledger, friction:**
  - **Cutting**
    - trait: Your words leave edges in people. The observation was accurate, the phrasing was clean, and the person carrying it home was bleeding in a way neither of you acknowledged at the time. Accuracy is your alibi. It has covered a remarkable amount of damage.
    - scene: You described your friend’s new business idea as a lemonade stand with a logo, in front of the group, to real laughter. The line was perfect. The business, which succeeded, launched without your knowledge a year later, and you learned about it from a billboard.
    - outside: People edit themselves entering your company, pre-checking their enthusiasms for exposed surfaces. The conversations stay bright and slightly armored. What you lose is the unguarded material, the tender first drafts of people, which now get shown to blunter audiences first, or only.
  - **Merciless**
    - trait: Weakness activates something in you that forgot to install brakes. The struggling presenter gets the hardest question, the failing argument gets dismantled past its surrender, the flinch invites a second cut. You call it rigor. The people watching call it something they discuss on the way home.
    - scene: The junior analyst’s numbers fell apart under your questioning, which was fair, and then continued falling apart for eleven more minutes, which was not. The team studied their laptops. He recovered professionally, eventually, at another firm, and tells the story as formative, in the surgical sense.
    - outside: Opponents prepare for you like weather events and allies quietly hope you stay aimed elsewhere. The fear is real capital, and you spend it efficiently. What it cannot buy, notably, is the thing adjacent teams have and yours lacks: people willing to be wrong out loud.
  - **Judgy**
    - trait: Most people fail an exam you never announce. The mediocre effort, the fuzzy thinking, the ordinary taste: each gets silently graded and permanently filed, and the grade leaks through your face at doses everyone can read. Respect from you is rare currency. Its scarcity is the design.
    - scene: Your colleague’s proud announcement of a certificate you consider trivial received your congratulations at a temperature slightly below the words themselves. He noticed, as everyone notices, the two-degree gap between what you said and what your eyebrows had already published. The certificate went undisplayed.
    - outside: People compete for your approval years after leaving your orbit, a fact that would please you and should alarm you. The bar you set is real. But teams around you spend measurable energy managing the fear of your disdain, which is energy subtracted, daily, from the actual work.

---

### 金_偏印 · Metal × 偏印

- **Structural interaction:** Metal generating Water same-polarity — precision as the source sustaining depth
- **Overview (k2_overview):** Your Metal moves as the Alchemist: a mind that refines. You take raw knowledge and smelt it, testing claims, discarding slag, keeping only what rings true when struck. Your insight is assay-grade and arrives in solitude. Share the refined ingots. The lonely part of the craft is the furnace, not the life.
- **Functional line (k2_functional):** You think by refinement: melt the claim, pour off error, keep the metal.
- **Adjective chips:** catalyst Fine-tuned · Selective · Ingenious | friction Cryptic · Hair-splitting · Shut-in
- **Ruling domain · Learning:** You learn by testing: every teaching struck against evidence before acceptance. Slow intake, permanent retention. Choose dense material worth the smelting. Shallow content wastes your furnace.
- **Ruling domain · Intuition:** Your intuition is metallurgical: a felt sense for what is alloyed with falsehood. When something rings wrong, it is wrong. Trust the ear and verify the details later.
- **Ruling domain · Solitude:** Solitude is your workshop: insight forms only with the door closed. Guard those hours without apology. Just open the shop some evenings. Refined gold unshared stays ore.
- **Keyword ledger, catalyst:**
  - **Fine-tuned**
    - trait: Your mind runs at tolerances other people cannot perceive. The half-degree shift in a colleague’s tone, the number that is slightly off in a healthy report, the note out of place: your instruments register it all, early, while the dashboard still shows green.
    - scene: You flagged the contract’s odd clause at the first read, one comma-deep in page thirty, and the lawyer’s follow-up confirmed what your calibration had already priced: the clause was the deal. Everyone else had read the same page. Their instruments simply do not go that fine.
    - outside: People run important things past you the way studios run final masters past the golden-eared engineer, for the flaws nobody else can hear. Your catches have saved deals, hires, and one marriage, each time via a detail everyone had seen and only you had registered.
  - **Selective**
    - trait: Your judgment separates finely: the good from the merely polished, the signal from the confident noise, the person worth betting on from the person worth watching. Choices filtered through you come out cleaner, and your shortlists have a strange habit of containing the eventual answer.
    - scene: From forty applications you pulled three names in one evening, and the hire, made from your three, is now running the department. The panel spent two weeks reaching the shortlist you reached before dinner. Nobody can extract your criteria. You suspect they would not transfer.
    - outside: People borrow your taste when their own stakes rise: which offer, which school, which surgeon. You answer with questions first, then a quiet ranking that later proves prophetic at rates that should embarrass the professionals involved. Your recommendations have a resale value. Everyone knows it but you.
  - **Ingenious**
    - trait: Your solutions arrive from angles that were not on the diagram. The mechanism repurposed, the rule read sideways, the tool used against its manual: what you build works for reasons that take other people a whiteboard to reconstruct. Cleverness is common. Yours has machining marks.
    - scene: The workshop door that defeated three contractors got fixed by you in an afternoon with a bicycle part and a magnet, a solution that has now held for four years and been photographed by two of the contractors. One asked permission to use it commercially. You waved it through.
    - outside: Colleagues have stopped saying that will not work before your prototypes finish, having eaten the sentence too often. Your fixes look wrong until they run. The patent attorney who reviewed one, as a favor, sent back a note with a single underlined sentence: file this one.
- **Keyword ledger, friction:**
  - **Cryptic**
    - trait: Your thinking exits in compressed form, when it exits at all. The one-word answer holding a paragraph, the eyebrow holding a memo, the decision announced without its reasoning attached. People decode you like weather instruments, approximately, and the misreadings compound while the originals stay filed inside.
    - scene: Your reply to the six-paragraph proposal was two words: not yet. The team spent a week interpreting them, generating four theories, three of them wrong. The right theory, which you could have typed in a minute, eventually surfaced in a hallway, secondhand, wearing someone else’s name.
    - outside: People spend real energy translating you, and the translation layer has become its own small bureaucracy: colleagues who explain what you meant, partners who interpret your silences for the children. You experience yourself as clear. The evidence experiences you as a cipher with a good heart.
  - **Hair-splitting**
    - trait: Distinctions multiply under your attention until nothing can be simply true. The almost-right word gets corrected mid-thanks, the good plan dies of a thousand refinements, and conversations with you develop footnotes. Precision was the gift. Somewhere it became the tax everyone pays to talk to you.
    - scene: The team agreed in minute five, and the remaining fifty-five minutes were spent on your distinction between broadly aligned and aligned, a distinction with real content and no consequence. The decision shipped identical to draft one. Four people billed the hour. Two of them aged.
    - outside: People pre-concede your corrections now, sprinkling technically into their sentences like offerings. The accuracy you enforce is real, and its price is visible in every meeting you join: the shoulders that drop slightly, the estimates that double quietly, the good-enough that will not survive the hour.
  - **Shut-in**
    - trait: Your workshop became your world. The projects, the reading, the precise private hours: all of it arranged within reachable walls, while the outside gets handled through slots. Visits require recovery, calls require rehearsal, and the door, though never locked, has not been tested in months.
    - scene: The last spontaneous social contact in your records was in the spring, a neighbor at the mailbox, four minutes, pleasant. Everything since has been scheduled, softened, or declined. The workshop light is on every evening. From the street it reads as cozy. From inside it reads as complete.
    - outside: Friends have converted you into a letters-and-links relationship, affection maintained through screens at your evident preference. They speak of you warmly, in the past-adjacent tense reserved for lighthouse keepers and monks. The reunion invitations still arrive. Everyone, including you, knows the RSVP before it opens.

---

### 金_偏财 · Metal × 偏财

- **Structural interaction:** Fire directing Metal broadly — warmth applied to precision as distributed material
- **Overview (k2_overview):** Your Metal moves as the Horizon: an edge pointed outward. You mint opportunity, spotting value with an assayer’s eye and striking while metal is hot. Deals sharpen you, markets read like open books, and money is a tool you handle without trembling. Fortune favors your precision. Fence one treasury it cannot touch.
- **Functional line (k2_functional):** You strike opportunities with timing others envy: measured approach, decisive cut.
- **Adjective chips:** catalyst Quick-eyed · Polished · Adventurous | friction Mercenary · Deal-hungry · Restless
- **Ruling domain · Opportunity:** You see openings as clearly as flaws in ore: the undervalued asset, the mispriced moment. Trust the eye and audit the appetite. Two ventures cut deep beat ten scratched shallow.
- **Ruling domain · Ventures:** Your ventures favor precision plays: quality arbitrage, timing trades, craft turned to commerce. Structure each like a blade, defined edge, clean handle, known length, and your record stays enviable.
- **Ruling domain · Father:** The father-thread in your chart carries metal: a paternal figure of standards, trade, or discipline whose mark shows in how you value things. Settle those accounts. Honor or forgiveness both count as payment.
- **Keyword ledger, catalyst:**
  - **Quick-eyed**
    - trait: Value flashes at you from clutter. The underpriced watch in the junk tray, the mispriced listing at midnight, the talented kid in the noisy audition: your eye sorts faster than markets do, and the gap between seeing and everyone-else-seeing is where your margins live.
    - scene: At the estate sale you walked past forty tables, lifted one ugly lamp, and paid nine dollars for what the auction house later confirmed at twelve hundred. The seller was happy. You were happy. The dealers who arrived an hour earlier still discuss the lamp.
    - outside: Friends send you photos before buying anything used: the car, the sofa, the ring. Your calls come back in seconds, are rarely wrong, and have saved your circle a documented fortune. Somebody proposed paying you a retainer once. You declined and appraised their offer instead, accurately.
  - **Polished**
    - trait: Your presentation is machined smooth. The shoes, the phrasing, the follow-up note: every surface catches light, and doors open on the shine before your substance says a word. People assume expensive training. It is actually maintenance, done privately, to standards nobody imposed but you.
    - scene: You were the least qualified person in the final round and the offer came to you, a fact the recruiter later explained with unusual honesty: everyone answered similarly, and you were the answer they could picture in front of clients tomorrow. The picture closed. It usually does.
    - outside: People upgrade their own presentation after time around you, quietly: the better email sign-off, the pressed shirt, the pause before answering. You set finish standards without announcing any. Rough talent gets sent to you for polishing the way stones get sent to tumblers, and emerges bookable.
  - **Adventurous**
    - trait: New territory pulls you the way bargains pull collectors. The unlisted trail, the menu with no translation, the market nobody in your industry has priced: you go first, pay the entry costs cheerfully, and return with either treasure or material. Both spend well at dinner.
    - scene: The detour that made the whole trip was your call: off the itinerary, down the unmarked coast road, into the town where the festival happened to be. The group still ranks that accidental evening above everything planned. Your navigation method, they note, was curiosity at full speed.
    - outside: People position themselves near your plans the way surfers position near reefs, knowing something will break interestingly. Half your friendships were formed mid-adventure, welded by weather and wrong turns. The stories that open every reunion have one census result: you are in nearly all of them.
- **Keyword ledger, friction:**
  - **Mercenary**
    - trait: Every relationship carries a price tag only you can see. The friendship with useful contacts, the favor with its invoice pre-drafted, the warmth calibrated to net worth: your attention follows value with an honesty that would be refreshing if anyone enjoyed being an asset.
    - scene: Your outreach pattern got noticed by a friend between jobs: three unanswered months, then a same-day reply once his new title went live. He tested it twice more over the years. The correlation held. He keeps you in his phone under a label that is not your name.
    - outside: People experience your interest as a market signal and check what changed in their circumstances when you warm up. The network you built this way is wide, efficient, and thin, and it prices you back: when your own value dipped two years ago, the inbox went quiet, symmetrically.
  - **Deal-hungry**
    - trait: Every deal within reach gets reached for. The marketplace find, the estate sale, the friend selling below value: your hands close on opportunities by reflex, and your storage fills with the proof. Each grab was genuinely smart. The appetite behind them has never once said enough.
    - scene: You came home with three watches from a sale you attended for one, each undervalued, each a story. The drawer of brilliant purchases now holds forty such stories. Half are still in their boxes, appreciating quietly, waiting for a selling day that never quite arrives.
    - outside: Dealers greet you by name in three cities, and your family greets new packages with a specific face. Nobody doubts your eye. What they count, privately, is how much brilliance sits boxed in the garage, bought at the right price for reasons that expired on arrival.
  - **Restless**
    - trait: Stillness costs you more than motion. The good position gets abandoned at its plateau, the profitable arrangement gets renegotiated out of boredom, the sure thing loses to the next thing on novelty alone. Your escape velocity is magnificent. Your orbits never complete.
    - scene: The role was perfect for eighteen months, which your resume confirms is your standard tenure, seven entries deep. The recruiter flagged the pattern gently. You explained each move persuasively, as always. She listened, nodded, and wrote one word on her pad. You have wondered since what it was.
    - outside: People hesitate to build anything long on you, having watched the eighteen-month clock run before. Partnerships offer you sprints, landlords remember you, and your own accountant keeps your files in the active drawer permanently. The freedom is real. The compounding it keeps interrupting is also real.

---

### 金_劫财 · Metal × 劫财

- **Structural interaction:** Metal meeting Metal cross-polarity — similar nature, competitive register
- **Overview (k2_overview):** Your Metal moves as the Rival: an edge that sharpens against other edges. Competition wakes you up, stakes clarify you, and you cut boldest when something real is on the table. Money and metal both change hands fast around you. The trick of your life is dueling without wounding, and betting without handing over the sword.
- **Functional line (k2_functional):** Your energy spikes for contests and crashes after. Build recovery into the schedule like a trainer would.
- **Adjective chips:** catalyst Keen-edged · Competitive · Unfazed | friction Cutthroat · Abrasive · Picks fights
- **Ruling domain · Rivalry:** Rivalry is your whetstone: you improve fastest with a named competitor in view. Choose rivals worth becoming, because you will absorb their shape. And retire each rivalry the day it stops sharpening and starts nicking.
- **Ruling domain · Shared stakes:** You bet alongside people easily: ventures, splits, loans between friends. Metal keeps clean edges, so keep clean papers. The partnerships that survive you are the ones with terms as sharp as the trust.
- **Ruling domain · Boldness:** Your nerve is surgical: boldest when the cut is clear. Practice sizing the wager to the blade. Full force is for openings that deserve it, not for every glinting chance.
- **Keyword ledger, catalyst:**
  - **Keen-edged**
    - trait: Competition hones you visibly. The rival’s number posted on your wall, the timed run against your own record, the deal chased sharper because someone else wants it: pressure grinds you finer instead of down, and your edge is renewed weekly, on purpose, against real resistance.
    - scene: The quarter your division got a genuine competitor was the quarter your numbers, flat for a year, jumped nineteen percent. Nothing else changed. Your manager mentioned this pairing carefully at review, and you agreed with unusual cheerfulness. You had noticed the sharpening yourself, and enjoyed it.
    - outside: People perform better against you and thank you for it later, sometimes years later. Training partners request you specifically, knowing the pace will hurt correctly. Whole teams calibrate their edge on yours, the way shops keep one true reference tool against which everything else gets measured.
  - **Competitive**
    - trait: Everything can be scored, and you are keeping score. The sales board, the board game, the parallel parking: your intensity arrives regardless of stakes, and it lifts the whole field, because coasting near you is simply not available. Games mean more when you are playing. Everyone plays harder.
    - scene: The office steps challenge was meant as a wellness joke until you joined, at which point it developed leagues, trash talk, and a trophy someone welded. Participation tripled. The winner, who was not you that quarter, framed the printout. You demanded a rematch at the ceremony, smiling.
    - outside: People pick you first for anything with a winner, and brace slightly when you join casual things. The intensity is contagious in the useful direction: standards rise wherever you compete. The company records you have broken remain broken by you, a fact you check, occasionally, at lunch.
  - **Unfazed**
    - trait: Odds do not negotiate with you, because you decline the meeting. The favorite you were supposed to lose to, the market you were too small for, the record held too long: your approach is identical regardless of the forecast, and forecasts around you have developed a humility.
    - scene: The tender was between your four-person shop and two multinationals, and your bid went in anyway, priced with nerve, argued in person. You took forty percent of the contract, the part requiring speed. The multinationals now subcontract you, a sentence you never say out loud at meetings.
    - outside: People stopped warning you about long shots after enough of them landed, and started quietly co-investing instead. Your presence in a fight recalibrates everyone’s sense of winnable. The stories are traded at industry dinners, always ending the same way: somebody checked the standings twice.
- **Keyword ledger, friction:**
  - **Cutthroat**
    - trait: Winning has stopped checking its methods with you. The shortcut through a colleague’s territory, the information used a half-step past fair, the alliance dropped at the moment of maximum value: each move defensible in isolation, and together a style that people describe with one hand on their wallet.
    - scene: The lead was technically unassigned when you took it, though everyone knew whose relationship had warmed it for a year. The commission cleared. The colleague said nothing, transferred out in the spring, and now runs the region you cannot get meetings in. Accounts settle slowly, and fully.
    - outside: People collaborate with you in armor now: terms written, credit pre-assigned, nothing left ambiguous. The precautions slow everything and offend you slightly. But the stories that mandated them are specific, dated, and told to every newcomer by their second week, as onboarding.
  - **Abrasive**
    - trait: Contact with you sands people down. The interruption at speed, the correction without cushioning, the volume that arrives when resistance does: none of it is malicious, and all of it accumulates, until working near you requires the kind of gloves people resent needing.
    - scene: The engineer was right about the flaw, and by the end of your six-minute response he had stopped defending the point, then stopped talking entirely, then, that quarter, stopped raising flaws. The next one shipped. It was expensive. The postmortem located the bug and, unofficially, the silence.
    - outside: Teams route their communication with you through the two people who can take the friction, an arrangement everyone denies exists. Your results are respected in full. But the roughness has a documented orbit: talent circles you once, learns the surface, and requests the transfer politely.
  - **Picks fights**
    - trait: Everything becomes a contest, including things that were conversations. The differing opinion escalates to a showdown, the casual game develops stakes, the family dinner acquires a scoreboard nobody else consented to. You win most of them. The wins pile up in a specific corner, alone.
    - scene: The debate about the restaurant bill, seven dollars at issue, ran twenty minutes and ended with your victory and a quieter table. You had been right. The couple across from you split an odd look you decoded weeks later, at another dinner, to which they had invited others.
    - outside: People decline the bait now with practiced smoothness, agreeing early, changing subjects, letting your gauntlets lie where they fall. The duels you still get are with strangers and juniors, everyone else having retired from the circuit. Champions, it turns out, mostly age out undefeated, in emptying halls.

---

### 金_正印 · Metal × 正印

- **Structural interaction:** Metal generating Water cross-polarity — precision nourishing and opening intelligence
- **Overview (k2_overview):** Your Metal moves as the Sage: tempered care, nurture with a fine edge of standards. You were shaped by teachings that held you to something, and you shelter others the same way, protection that also sharpens. Knowledge in your keeping stays true. Let some care through unpolished. Warmth needs no proofing.
- **Functional line (k2_functional):** You think in tested doctrine: knowledge kept because it held under strikes.
- **Adjective chips:** catalyst Discreet · Preserving · Old soul | friction Detached · Formal · Locked-away
- **Ruling domain · Knowledge:** Your knowledge is armory-grade: fewer books, deeply proofed, instantly deployable. You trust what survived testing. Curate hard, and reread the masters yearly. Your edge is depth.
- **Ruling domain · Shelter:** Your shelter is a forge-side bench: people come to you and leave straightened. You protect by tempering. Remember some visitors need only warmth. Not everything cracked wants rework.
- **Ruling domain · Mother:** The mother-thread runs steel-true: a nurturing figure of standards, or the ache where that discipline should have been. Her exactness lives in your caring. Keep the precision, soften the grading.
- **Keyword ledger, catalyst:**
  - **Discreet**
    - trait: What enters your keeping stays kept. The friend’s diagnosis, the colleague’s exit plans, the family matter: all held in a vault whose combination has never leaked once. In an age of broadcast, your silence is heirloom-grade, and people inventory it correctly as treasure.
    - scene: When the merger rumors flew, three separate executives realized mid-panic that you had known for a month, from three separate confidences, and cross-referenced nothing to anyone. The realization traveled. Your calendar for the following quarter filled with meetings that began: this stays with you.
    - outside: People sequence their disclosures by trust, and you are the first tier alone. Secrets travel toward you and stop, a fact widely relied upon and never once tested to failure. At every funeral, someone in the region is calmer because what they told you decades ago stayed told.
  - **Preserving**
    - trait: You maintain what matters against time’s default. The friendship kept in service since school, the grandmother’s recipe made annually to spec, the archive of photos labeled while others let theirs dissolve into camera rolls. Loss takes a percentage from everyone else. You have negotiated a better rate.
    - scene: The recipe was almost lost twice, once at the funeral, once in the flood, and both times your copy, made years earlier in careful ink, restored it to the family. There are now four copies, distributed by you, laminated. The dish appears every winter, tasting like continuity.
    - outside: People discover what you have kept at exactly the moments loss becomes visible: the address that survived in your book, the photo of the shop before the fire, the friendship maintained through everyone’s chaotic decade. You are the family’s off-site backup, and everybody restores from you eventually.
  - **Old soul**
    - trait: Your wisdom skips the podium. The insight arrives in a sentence near the end of the visit, unlabeled, easy to miss, and it reorganizes the listener’s month. You never claim the credit and rarely get it, which suits you. The advice was for using, never for citing.
    - scene: Your niece made the decision everyone praised her for after one walk with you, during which, by her account, you mostly asked what she already thought and mentioned, once, what you had seen happen to hurry. The sentence took four seconds. She built two years on it.
    - outside: People leave your company having reached their own conclusions, unaware of the machining. Years later they quote things you said as things they realized. You watch your sentences circulate under other people’s names, polished by use, and consider the ledger, on balance, exactly right.
- **Keyword ledger, friction:**
  - **Detached**
    - trait: Your care operates at instrument distance. The concern is genuine and arrives as analysis, the love is real and expressed as protocol, and the people receiving it stand slightly cold in the accuracy, holding perfectly correct advice, wishing it had arms.
    - scene: Your son called with news that had tears at its edges, and your response, calibrated and useful, addressed every practical dimension within four minutes. The call ended efficiently. He sat in the car afterward, helped and unheld, and then phoned his aunt to say the same things over.
    - outside: People pre-sort what they bring you: problems yes, feelings elsewhere. The sorting is so old it feels like respect, and it has a cost ledger nobody opens. You are the first call for practical things and the last to hear anything that requires only company. The queue reveals the design.
  - **Formal**
    - trait: Correctness armors every exchange. The thank-you notes are impeccable, the boundaries observed to the millimeter, the affection conducted through channels so proper that its temperature cannot be verified. People know exactly where they stand with you. Nobody knows how it feels there.
    - scene: Your birthday call to your oldest friend ran eleven minutes, covered health, family, and weather in that order, and closed with regards to the household. It has run this way for thirty years. She once tried to break format with something raw. The pause was so perfect she apologized.
    - outside: People mirror your correctness back at you, and the relationship proceeds like diplomacy between friendly nations: warm communiques, scheduled summits, nothing unscripted. The love is real on both sides and fully suited at all times. Everyone involved occasionally wonders what casual would have felt like.
  - **Locked-away**
    - trait: Your inner life is in the vault with everyone else’s secrets. The grief went in decades ago, the hopes followed, and the combination, if you are honest, has drifted from your own memory. What remains public is composed, helpful, and sealed. Even you visit the contents rarely.
    - scene: The night your oldest friend died, you tidied the kitchen, answered the necessary messages with grace, and slept on schedule. The crying happened weeks later, alone, in the car, over a song, for four minutes, and was filed before the engine cooled. Nobody ever knew. That was the design.
    - outside: The people closest to you can list your kindnesses for hours and your feelings for seconds. At gatherings, your composure is the fixed point everyone appreciates and nobody can reach. Someone once asked what you were carrying. You answered with what you were managing. The difference went home unexamined.

---

### 金_正官 · Metal × 正官

- **Structural interaction:** Metal setting standard for Wood cross-polarity — precision that tests and grants recognition
- **Overview (k2_overview):** Your Metal moves as the Magistrate: the law in its own element. Rules read to you like well-machined parts, and you keep them because precision deserves keeping. Rank finds you early, trust follows, and your signature means something. The discipline is real steel. Just check, yearly, that the code you enforce is still one you believe.
- **Functional line (k2_functional):** You are the measure others calibrate to: exact, upright, and honest about your own tolerances.
- **Adjective chips:** catalyst Precise · Incorruptible · Even-handed | friction Demanding · Unbending · By-the-book
- **Ruling domain · Career:** Your career climbs through correctness: credentials, rank, a record without dents. Institutions promote you because you are what their rules dream of. Pick ones whose rules deserve you.
- **Ruling domain · Status:** Your standing is engraved, earned slowly, hard to tarnish. Guard it without worshiping it. A reputation is a tool for doing right at scale, not the point of the work.
- **Ruling domain · Order:** You produce order like a mint produces coin: standardized, trusted, circulating. Systems you touch stay fixed. Leave a tolerance in every spec. Perfect fits crack under weather.
- **Keyword ledger, catalyst:**
  - **Precise**
    - trait: Exactness is your dialect. The estimate lands within percent, the summary contains nothing loose, the drawer holds what its label claims. Around you, vagueness feels briefly embarrassed of itself, and work passing through your hands comes out true to measure, every time it matters.
    - scene: The budget you built in January closed the year eleven dollars off, across forty accounts, a variance your auditor circled with an exclamation mark and showed to colleagues. You considered the eleven dollars a miss. The auditor considered framing it. Both reactions were, in their way, accurate.
    - outside: People stop estimating around you and start measuring, pulled upward by your example. Documents you have touched become the reference copies. When two versions of any number circulate, meetings resolve the dispute with four words, said without irony: check what theirs says.
  - **Incorruptible**
    - trait: Your price does not exist. The convenient blindness, the adjusted figure, the favor with strings: each has approached you dressed in reasonable clothes, and each has left unbought. People stopped offering years ago, which is the cleanest audit result a character can post.
    - scene: The developer’s envelope, offered with practiced lightness at the site meeting, was returned across the table before it finished landing, without commentary, and the inspection proceeded to its correct conclusion. The story circulated in both industries. Your approvals, consequently, are bankable at face value, everywhere.
    - outside: Institutions position you where temptation concentrates, treasurer, examiner, referee, because your presence retires a whole category of risk. The compliment is structural: systems relax around your name. Somewhere in three organizations, rules exist that were written shorter because you would be the one holding them.
  - **Even-handed**
    - trait: Your fairness holds under load. The friend and the stranger get the same terms, the popular opinion and the correct one get separated calmly, and both sides of any dispute leave your table feeling accurately weighed. Balance like yours is engineered. People rest whole arguments on it.
    - scene: The inheritance dispute that was fracturing the family got handed, by unspoken consensus, to you, and your allocation, explained line by line at the kitchen table, was accepted by all four siblings, including the two who arrived with lawyers’ letters. The letters went home unopened.
    - outside: Warring parties agree on you when they can agree on nothing else, which has become its own career. Your rulings hold without enforcement because both sides watched the scales the whole time. The nickname that follows you between organizations translates, roughly, to: the one they both trusted.
- **Keyword ledger, friction:**
  - **Demanding**
    - trait: Your standard admits no rounding. The report is right or it is redone, the table is set correctly or reset, the apology contains the exact words or does not count. Excellence this consistent is genuinely rare, and living beside it is an occupation nobody applied for.
    - scene: The thank-you card your daughter wrote got returned for a second draft, spelling corrected, sentiment intact but re-ordered. She was nine. The card that finally sent was perfect, and she has not voluntarily written one since. The standard held. Something else, harder to name, did not.
    - outside: People proofread their texts to you, twice, and still feel the red pen through the phone. The quality you extract is real and measurable. So is the reluctance that precedes every submission, the small breath people take before showing you anything they made, including, lately, their choices.
  - **Unbending**
    - trait: The rule holds regardless of weather. The exception with merit, the mercy the moment obviously wanted, the technicality that ruins an honest case: your spine does not consult the specifics. Consistency this pure is a kind of integrity and a kind of blindness, wearing the same suit.
    - scene: Your nephew missed the application deadline by one hour, with a hospital receipt explaining it, and your recommendation letter, promised for months, stayed unsent on principle: terms are terms. He got in the following year, elsewhere, and thanks a different uncle in the acknowledgments now.
    - outside: People stopped bringing you their edge cases, the human ones that need judgment rather than enforcement, and the routing happened years ago, quietly. What reaches you now is only what fits the forms. You process it flawlessly, and never learn what the filters caught.
  - **By-the-book**
    - trait: The manual outranks the moment. The procedure gets followed into outcomes the procedure never imagined, the form gets completed while the situation burns politely nearby, and initiative waits outside your job description, permanently, holding its useful ideas. Nothing you do is ever wrong. Much of it is beside the point.
    - scene: The customer’s problem had an obvious two-minute fix and a four-day approved pathway, and you chose the pathway, correctly, while they watched the fix sit there, visible to everyone. They complied, complained, and switched providers. The file shows full compliance. The file is complete and the client is gone.
    - outside: Colleagues invoke your name as a unit of process: run it past the book, they say, meaning you. In audits you are priceless. In fires, people have learned to route around your desk first and apologize to it later, a workflow so established it appears, unofficially, in the onboarding notes.

---

### 金_正财 · Metal × 正财

- **Structural interaction:** Fire directing Metal cross-polarity — focused warmth shaping the edge with discipline
- **Overview (k2_overview):** Your Metal moves as the Steward: an edge in service of what it keeps. You maintain value with a craftsman’s discipline, tools oiled, accounts true, promises weighed before signing. Nothing gaudy, everything durable. What passes through your hands leaves better organized, and what stays becomes quietly excellent.
- **Functional line (k2_functional):** You execute with clean precision: zero waste, nothing reworked, every screw accounted for.
- **Adjective chips:** catalyst Thorough · Trustworthy · Slow and steady | friction No-frills · Greedy · Won’t budge
- **Ruling domain · Wealth:** Your wealth is machined: earned exactly, kept polished, compounded without drama. You will never be flashy and never be broke. Invest in quality that holds its edge, including your own skills.
- **Ruling domain · Savings:** You save like an armorer: reserves as protection, kept bright and counted. The vault serves the life, so define what it defends, and spend without guilt inside those lines.
- **Ruling domain · Steady love:** You love in maintained condition: reliability, kept promises, care with no rust on it. Choose someone who values upkeep, then schedule delight as faithfully as inspections.
- **Keyword ledger, catalyst:**
  - **Thorough**
    - trait: Detail is where your love of quality lives. The receipts reconciled monthly, the maintenance schedule honored, the small print actually read: your life runs on a fineness of attention that prevents disasters so early they never even become anecdotes. Nothing about you is approximately done.
    - scene: The warranty claim that saved you eleven hundred dollars took four minutes, because the receipt, the serial number, and the original packaging were exactly where your system said they would be, three years on. The agent audibly recalibrated. Most claims, she said, die of missing paperwork. Yours arrived immortal.
    - outside: People hand you things that must not be gotten wrong: the visa application, the medication schedule, the wedding planning. Errors approach your work and give up early. The double-checkers who review you have quietly stopped, a professional courtesy extended to perhaps three people they have ever met.
  - **Trustworthy**
    - trait: Your reliability is collateral-grade. People secure real decisions against your word: the deposit sent on your say-so, the key left under your mat, the password shared without ceremony. Trust accumulates around you the way interest accumulates, quietly, on never-broken terms.
    - scene: Four families on your street hold spare keys at your house, a fact none of them coordinated. When the locksmith asked how you became the neighborhood vault, you could not name a starting event. There was no event. There were twenty years of nothing ever going missing.
    - outside: Banks, in-laws, and employers all reach the same conclusion from different evidence: whatever is placed with you comes back intact and on time. References describe you with the specific warmth reserved for people who have held their money. The word they all use is safe, meant as treasure.
  - **Slow and steady**
    - trait: Your wealth grows the way rust never sleeps, in your favor: small, constant, compounding additions that no single day notices. The percent saved, the skill deepened annually, the relationship maintained for decades: everything in your portfolio gains a little every quarter, forever.
    - scene: The account you opened at twenty-two with automatic transfers you never adjusted crossed a threshold this year that startled even you. The statement arrived on an ordinary Tuesday. You had done nothing dramatic in twenty years, which was, the statement made clear, the entire strategy.
    - outside: People ask your secret expecting a trick and receive simple math: start early, add always, subtract rarely. They leave disappointed and return years later, converted, showing you their own compounding curves. Your example has quietly seeded more retirement accounts than any advisor in your zip code.
- **Keyword ledger, friction:**
  - **No-frills**
    - trait: Comfort gets audited out of your life on principle. The heating conservative, the furnishings functional, the pleasures budgeted to their nutritional minimum: discipline built the estate, and somewhere it kept building past the point of purpose, into corners nobody warms.
    - scene: The dinner you hosted was correct: adequate portions, sensible wine, lights at economy. Guests praised the meal and stopped somewhere short of settling in, coats kept near. The evening ended punctually. Your home, one of them said in the car, is the tidiest place she has ever been cold.
    - outside: People describe your life with respect and no envy, a combination that took you years to notice. The discipline is admired at a distance, like a fortress: impressive, orderly, and not somewhere anyone dreams of moving. Invitations to yours get accepted dutifully. Invitations elsewhere get accepted first.
  - **Greedy**
    - trait: What comes near your hands tends to stay in them. The negotiation pushed past won into extractive, the split adjusted a few percent your way, the free thing taken because free: each grasp is small, and the sum has a gravity that people feel and rarely name.
    - scene: The settlement was fair at the first offer, and your counter, and the counter after that, extracted eleven percent more and something else that did not appear on the term sheet. The other side paid in full and briefed their industry. Your next three negotiations opened noticeably colder.
    - outside: People check the terms twice when your name is on them, a due diligence premium that costs you deals you never learn about. What you have gathered is substantial and correctly titled. What it displaced, the easy trust, the rounded-up generosity, appears on no statement, and compounds anyway.
  - **Won’t budge**
    - trait: Your positions are priced once and never repriced. The offer stands as made, the grudge as filed, the opinion as formed in the original year: movement reads to you as loss, so nothing moves, and the world negotiates around you the way rivers negotiate around bedrock.
    - scene: The house sat unsold for fourteen months because your price, set in a different market, declined to acknowledge the new one. The eventual sale, at less than the early offers you refused, closed a chapter your spouse refers to only by its duration. The number had not budged. Everything else had.
    - outside: Negotiators bring you take-it-or-leave-it terms now, having learned that middles do not exist in your geography. Some deals close efficiently this way. The ones needing give simply route elsewhere, and your reputation, hard as bearing steel, attracts exactly the partners who want a wall, and no others.

---

### 金_比肩 · Metal × 比肩

- **Structural interaction:** Metal precision amplifying Metal — same-polarity self-referencing loop
- **Overview (k2_overview):** Your Metal moves as the Twin: a standing force that meets the world edge-first and equal. Nothing about you waits for permission. You hold your line the way a blade holds its shape, and you respect exactly the people who hold theirs. Company, for you, is two swords in one sheath: close, parallel, never fused.
- **Functional line (k2_functional):** Your energy is tempered and even: slow to tire, slow to bend, restored by solitary work.
- **Adjective chips:** catalyst Self-made · Reserved · Unshakeable | friction Sealed-off · Rigid · Solitary
- **Ruling domain · Peers:** Your peers are fellow blades: rivals you respect, colleagues you measure against, friends won through tested mettle. Keep two or three whose standards match yours. Iron sharpens iron is not a proverb to you. It is your social life.
- **Ruling domain · Independence:** Independence, in metal, is structural: you do not perform autonomy, you are made of it. Guard it without sealing it. A blade alone stays sharp but unused, and your edge exists for work that matters.
- **Ruling domain · Self-reliance:** You carry your own weight and everyone can feel it. The practice to add is borrowing well: one tool, one favor, one opinion at a time. Even the finest steel was forged by other hands.
- **Keyword ledger, catalyst:**
  - **Self-made**
    - trait: You built yourself by your own measure, and you know exactly which parts you built. Nobody assigned the morning routine, the savings rule, or the way you train. Ten years on, none of it has slipped, mostly because none of it was ever borrowed.
    - scene: The morning routine started in a bad year, the savings rule after one specific mistake, the training after nobody came to help. Each one was built by hand, for a reason you could name. Ten years later they all still hold, and you still remember the reasons.
    - outside: People assume someone taught you the discipline, a coach, a parent, a book. There wasn’t one. The rules you live by were cut to fit you alone, which is why borrowed programs keep failing the people who ask you for yours.
  - **Reserved**
    - trait: Keeping most of yourself back is a choice you make daily, and it costs you less than people think. At a party you might say forty words. Three people will still leave convinced you were the most solid person in attendance, and none of them could quote you.
    - scene: The party ran four hours and you said maybe forty words. On the drive home nothing about that felt like a failure, because it wasn’t one. What you keep back was never missing. It is in reserve, and everyone present could somehow feel the difference.
    - outside: Loud company reads you slowly. First you are the quiet one, then the solid one, and eventually the one people find at the edge of the gathering when something actually matters. You never move toward the center. The important conversations keep arriving anyway.
  - **Unshakeable**
    - trait: Pressure does not move your line, and that steadiness is a built feature rather than stubbornness. The deadline panic sweeps the office, chairs rolling and voices climbing, and your pace does not change by a keystroke. Panic has simply never once improved your output, so you declined it.
    - scene: The deadline lands and the office turns into weather, chairs rolling, voices up, someone rewriting the plan hourly. Your pace stays exactly where it was on Monday. By Friday the weather has passed, and your part is the one that shipped clean.
    - outside: Colleagues have stopped checking whether you are worried, because the answer never changes anything. In a crisis people orbit you without knowing why. Steadiness this even is rare enough that others borrow against it, and you let them, and it costs you exactly nothing visible.
- **Keyword ledger, friction:**
  - **Sealed-off**
    - trait: Letting people in stopped being something you decline and became something you cannot quite locate. Fine, you say, on the day of the diagnosis, the layoff, the breakup. The word has three hundred uses now, and not one of them means fine.
    - scene: On the day of the diagnosis you said fine. Layoff, fine. Breakup, fine. The word has become a door painted to look like a wall, and the people who love you have quietly stopped testing whether it opens.
    - outside: The people close to you have learned to read your weather at a distance, because asking gets them fine. They compare notes about you. They worry in committee, exactly the way you trained them to, and call it respecting your space.
  - **Rigid**
    - trait: Your rules outlive the reasons for them, and you enforce them anyway. Gym at six, lunch at noon, lights out at eleven, held through a fever and a friend’s one free evening in town. The structure was built to serve you. Somewhere it quietly reversed.
    - scene: A friend was in town for one evening, the first in three years. Lights out at eleven held anyway, the way it held through the fever, the way it holds through everything. You slept on schedule and lay there knowing exactly what the schedule had cost.
    - outside: People plan around your routine the way they plan around weather, and they stopped asking for exceptions years ago. The discipline earns real respect. What nobody mentions is how rarely you appear in the stories they tell about their best nights.
  - **Solitary**
    - trait: Alone is your default answer, and it kept answering long after the question changed. You moved apartments twice with rented dollies and zero phone calls, and both times at least one person would have said yes. Proving you can was settled years ago. You keep proving it.
    - scene: Two apartment moves, two rented dollies, zero phone calls made. Halfway down the stairs with the couch, wedged and sweating, you ran the list of people who would have come, and it was a real list, and you finished the move alone anyway.
    - outside: Friends have stopped offering, which you count as efficiency and they count as defeat. The distance you keep reads as self-sufficiency for the first few years. After that it starts to read as a judgment of them, and they were never the ones being judged.

---

### 金_食神 · Metal × 食神

- **Structural interaction:** Earth generating Metal same-polarity — stability as natural source of precision
- **Overview (k2_overview):** Your Metal moves as the Artisan: an edge that makes beautiful, useful things instead of wounds. Craft flows out of you calmly, finished on the first pass more often than seems fair. You feed people with precision, the perfectly chosen gift, the exact right word, and your pleasure runs quiet and specific.
- **Functional line (k2_functional):** You say precise, kind things that people keep. Your compliments are engraved, not sprayed.
- **Adjective chips:** catalyst Craft-loving · Refined · Savoring | friction Fussy · Self-satisfied · Dulled
- **Ruling domain · Expression:** Your expression is craftsmanship: things made exactly, words placed cleanly, taste visible in every output. You do not need volume. One finished piece says what an hour of talk cannot, so keep finishing pieces.
- **Ruling domain · Enjoyment:** You enjoy like a connoisseur of the specific: the correct knife, the true note, the single well-made thing. Fund those pleasures without guilt. Precision delight is how this energy refuels its edge.
- **Ruling domain · Children:** With children and the people you mentor, you teach by craft: hands shown, tools trusted early, standards kept warm. What they inherit from you is the quiet confidence of making things properly.
- **Keyword ledger, catalyst:**
  - **Craft-loving**
    - trait: The making itself feeds you. The knife kept sharp, the joint fitted flush, the sentence revised until it clicks: process is your pleasure, and it shows in everything that leaves your hands. People sense the extra hour in your work without being able to point at it.
    - scene: The cutting board you made as a housewarming gift took three weekends and outlasted the marriage it was given to. In the settlement, notably, it was contested. You have since made two more on request, each with a waiting period the recipients found completely reasonable.
    - outside: People commission things from you that stores sell cheaper, and know exactly why they are paying more and waiting longer. Objects you have made get pointed out to houseguests, credited by name. Your work carries a small warranty nobody wrote down: it was made by someone who loved making it.
  - **Refined**
    - trait: Your taste has a machinist’s tolerance. The one right glass for the wine, the single adjective where three loitered, the pause placed exactly: refinement is not fussiness in your hands, it is fit, and everything around you sits a little truer for it.
    - scene: You reduced the menu from nine dishes to five, the invitation from a paragraph to a line, and the dinner, guests agreed afterward, was the best of the year, though nobody could name what made it feel that way. You could have named it: subtraction, done lovingly, all afternoon.
    - outside: People borrow your eye before their big occasions: the outfit checked, the speech trimmed, the toast rehearsed. Your edits are small and decisive, and their absence is loud. Events that skip your review acquire, in your circle’s vocabulary, a technical description: slightly too much.
  - **Savoring**
    - trait: You extract full value from good moments. The coffee gets its silence, the win gets its evening, the anniversary gets marked properly instead of glanced at. Pleasure, in your hands, is not consumed. It is machined for maximum yield, and the yields are excellent.
    - scene: The bottle you had saved for eleven years got opened on an ordinary Thursday that you had unilaterally declared worthy, and the resulting three-hour dinner for two is now referenced in your household as the benchmark. Nothing had happened that day. That, you explained, was the occasion.
    - outside: People slow down at your table without noticing the mechanism: courses that arrive unhurried, toasts that actually toast something, phones that migrate to pockets. Afterward they describe the evening as long in the good way. You have quietly taught everyone you host what time tastes like.
- **Keyword ledger, friction:**
  - **Fussy**
    - trait: The right way has become the only way, and the tolerances keep narrowing. The coffee is drinkable at one temperature, the towels fold along one axis, the restaurant loses you at the first wobbling table. Quality was the point once. The specifications have since annexed the pleasure.
    - scene: The vacation rental was lovely and wrong: the pillows, the knife situation, the light in the kitchen at breakfast. You spent the first morning reorganizing and the family spent it on the beach, waving up at the window occasionally. The kitchen, by checkout, was perfect. The tan was theirs.
    - outside: Hosting you has become a certification process your friends prepare for, half joking, checking the coffee equipment against remembered complaints. Invitations still come, with disclaimers attached. The dinner parties proceed slightly braced, and the truly relaxed ones, you have started noticing, happen at addresses you hear about afterward.
  - **Self-satisfied**
    - trait: Your own standards approve of you completely, and the audit ended there years ago. The taste is excellent and certain, the methods proven and closed, the feedback received warmly and filed unread. Contentment this polished repels improvement, and everything ambitious slides off, politely, elsewhere.
    - scene: The critique group admired your chapter and suggested one structural change, and your explanation of why the structure was already correct ran longer than their notes. They agreed pleasantly. The novel, excellent and unchanged, is in its ninth year of being almost ready, admired chiefly by its author.
    - outside: People stopped offering you notes somewhere in the last decade, an editorial silence you experience as arrival. The work remains good, genuinely, and identically good: the growth curve flattened exactly where the confidence plateaued. Younger talents study your early work with reverence, and your recent work not at all.
  - **Dulled**
    - trait: Comfort has rounded your edge. The palate needs stronger seasoning, the wins need bigger stakes, the pleasures that once rang now land muffled under years of easy access. Everything is available and nothing is delicious. The instrument still works. It just cannot hear itself anymore.
    - scene: The tasting menu that would have thrilled you at thirty got a shrug and a comparison at fifty-five, the fourth such shrug that month. On the walk home you passed a food cart with a line of delighted students, and stood there a moment, running numbers you did not finish.
    - outside: People notice that delighting you has become a project with a low hit rate, and the gift-giving around you has turned practical, then perfunctory. The enthusiasms you once broadcast made you magnetic. The connoisseurship that replaced them is accurate, extensive, and, the table has noticed, contagious in the wrong direction.

---

### 水_七杀 · Water × 七杀

- **Structural interaction:** Water pressing Fire same-polarity — the extinguishing force that doesn't moderate itself
- **Overview (k2_overview):** Your Water moves as the General: force that arrives as tide. You command indirectly, positioning, timing, the pressure of inevitability, and opponents find themselves outflanked by someone who never raised a voice. Strategy is your sword arm. The deep game, played patiently, with the current doing the marching.
- **Functional line (k2_functional):** Your discipline moves like a cold current: quiet, total, and felt only when someone crosses it.
- **Adjective chips:** catalyst Cool-headed · Unblinking · Deep-striking | friction Chilling · Relentless · Suffocating
- **Ruling domain · Pressure:** You convert pressure into depth: threats make you quieter and more exact. Beware pressure you keep underwater. Even oceans need to storm occasionally.
- **Ruling domain · Command:** You command by current: framing choices, shaping terrain, letting people arrive at your conclusion. It is masterful and unsettling. Show the hand sometimes. Trust grows where strategy is visible.
- **Ruling domain · Crisis:** In crisis you flow while others freeze: instant rerouting, calm surface, decisive undertow. You will save situations quietly and collect credit never. Log your victories somewhere. Currents deserve historians.
- **Keyword ledger, catalyst:**
  - **Cool-headed**
    - trait: Your temperature drops as situations heat up, which is backwards from most people and priceless in a crisis. The angrier the meeting, the clearer your sentences get. Decisions made in your coolness hold up later, when everyone rereads what the heat almost signed.
    - scene: Both founders were shouting by the time you spoke, and your first sentence was a number. Your second was a date. The shouting had nowhere to attach itself to numbers, and the meeting ended with a plan bearing your fingerprints and their signatures.
    - outside: Opponents find your calm the most alarming thing in the fight. While they heat up, you cool down, and every degree they rise hands you another advantage. Beating you requires making you blink first. The people who have tried compare notes afterward, uselessly.
  - **Unblinking**
    - trait: You look directly at what others manage around. The bad diagnosis, the failing numbers, the conversation everyone keeps rescheduling: your gaze goes straight in, takes the true measure, and does not flinch on contact. Reality respects you for it and returns the favor with early warnings.
    - scene: When the project was dying, you were the one who said dying, out loud, in week two instead of month four. The word landed like cold water. It also saved the quarter, because everything that followed was built on the actual situation instead of the brochure.
    - outside: People borrow your eyes for their hardest looks: the contract they are afraid to reread, the feedback they suspect is true, the mole on the shoulder. You never soften the report and never sharpen it either. Afterward they know, which was the entire point.
  - **Deep-striking**
    - trait: When you move, it lands where it matters, at depth. No warning shots, no surface noise: you wait, read the current, and place one action where the whole structure turns. People rarely see your strike. They see everything afterward arranging itself differently.
    - scene: You said nothing in three consecutive negotiations, then made one call to one person on a Thursday, and the entire deal reorganized around it by Monday. Colleagues spent the week reconstructing what happened. What happened was patience with coordinates.
    - outside: Rivals underestimate you at intake because you make no ripples, and revise their opinion exactly once. The revision is permanent. Around your industry there is a small collection of stories that all end the same way: nobody saw it coming, and it only needed to come once.
- **Keyword ledger, friction:**
  - **Chilling**
    - trait: Your displeasure arrives as temperature. There is never a scene: the warmth simply leaves the water, and everyone in it notices at once. People can handle anger. The cold is harder, because there is nothing to answer and nowhere to warm up.
    - scene: You said nothing wrong at dinner. You said almost nothing at all, and the table spent two hours in a careful climate, passing dishes with light hands. Your partner asked afterward what happened. Nothing happened, you said, at a temperature that confirmed everything.
    - outside: People describe crossing you with weather words: frost, freeze, ice age. The thaw comes eventually, unannounced, and everyone pretends the winter did not happen. But they dress for it now, permanently, and some conversations never come back indoors.
  - **Relentless**
    - trait: Once you commit to pressure, it does not stop. The follow-up, the reminder, the revisited grievance: your current keeps flowing against the same rock long after the point was made, and past where the point began eroding the ground it stood on.
    - scene: The dispute with the contractor was won in March, with a refund and an apology. You were still composing documentation in June. The folder is spotless and the war is over, and only one side has noticed the second fact.
    - outside: People settle with you early because they have seen what the long version costs. Your persistence wins real victories, and it has also outlived several relationships that surrendered years before you stopped. The current cannot tell the difference between resistance and rubble.
  - **Suffocating**
    - trait: Your force pulls downward quietly. Deadlines, standards, and consequences settle over people like water over a diver, heavier with every meter, and nobody can point to the moment breathing got hard. You never raise your voice. The pressure does the talking, at depth.
    - scene: The new hire was excellent for three months, then quieter, then gone, and the exit interview mentioned an atmosphere no single incident could explain. You reread it twice, genuinely puzzled. Each individual expectation had been reasonable. Together they were an ocean on someone’s chest.
    - outside: Teams under you produce and pale at the same time, and the best people leave while thanking you sincerely. From your seat it looks like standards working. From theirs it was the slow discovery of how deep the water had gotten while they were busy swimming.

---

### 水_伤官 · Water × 伤官

- **Structural interaction:** Metal generating Water cross-polarity — precision producing depth that exceeds its container
- **Overview (k2_overview):** Your Water moves as the Virtuoso: a current too clever for its banks. You express in floods of insight, subversive, fluid, impossible to police, the writer between the lines, the wit that erodes pomposity by morning. Nothing contains you long. The art is choosing what your torrent carves next.
- **Functional line (k2_functional):** Your expression flows subversive and quotable, satire and insight braided into one current.
- **Adjective chips:** catalyst Silver-tongued · Inspired · Free-flowing | friction Toxic · Mocking · Uncontainable
- **Ruling domain · Talent:** Your talent is fluid genius: writing, strategy, humor, any craft where thought must flow around form. It resists containers and needs them. Choose loose ones, essays, seasons, series, and pour.
- **Ruling domain · Performance:** You perform by currents: the essay that spreads, the remark that travels. Your stage is wherever words flow. Publish more, polish less. Rivers are judged by movement, not by stillness.
- **Ruling domain · Defiance:** Your defiance dissolves things: authority mocked into smallness, rules outlived rather than fought. It is elegant and it accumulates enemies slowly. Now and then, defend something openly. It sweetens the water.
- **Keyword ledger, catalyst:**
  - **Silver-tongued**
    - trait: Words obey you the way water obeys gravity, finding every gap and pouring through beautifully. You talk people into things, out of things, and around things, and they enjoy the ride even when they can see the technique. Persuasion this smooth stopped being learned long ago. It flows.
    - scene: The refund was against policy, the agent had said no twice, and four minutes into your version of events she was laughing and typing an exception. On the way out you tipped generously, which is your habit after winning. The technique pays its taxes.
    - outside: Friends bring you along to negotiations the way people bring jumper cables, just in case. Sellers quote you one price and agree to another, later, unsure how the distance was crossed. The recordings would show nothing but pleasant conversation. That is the whole trick.
  - **Inspired**
    - trait: Ideas arrive in you like spring water, from somewhere underground and always moving. Mid-shower, mid-sentence, mid-commute: the notion appears whole, strange, and usually good. You have learned to keep something to write with everywhere, including the glovebox and the shower wall.
    - scene: The campaign that carried the year was dictated into your phone at a red light, complete with the tagline, in ninety seconds. The agency had been circling it for a month. You apologized for the audio quality. Nobody heard the apology over the applause.
    - outside: Colleagues have learned to schedule brainstorms around your presence, then pretend they did not. With you in the region, the whiteboard fills differently. Where the ideas come from, nobody knows, including you. That they keep coming is the only data anyone needs.
  - **Free-flowing**
    - trait: Your expression pours, and it comes out with an edge already in it. The take nobody dared say, the phrasing that turns the meeting, the line too good to keep: it all flows at speed, brilliant first, considerate later, if later gets a turn.
    - scene: The hot take you typed in one pass, no drafts, went further than anything the team spent weeks polishing. Half the industry loved it, a client quoted it back, and legal asked one careful question. You would write it again, faster.
    - outside: People forward what you say with commentary attached: brilliant, careful, look at this. Your one-pass writing outperforms other people’s fourth drafts, publicly, which wins you fans and a folder in somebody’s records. Nobody is neutral about your output. That is the point of it.
- **Keyword ledger, friction:**
  - **Toxic**
    - trait: Your words work on people the way water works on iron, slowly, invisibly, and completely. The little digs, the accurate observations shared at the wrong moment, the humor with acid in it: nothing dramatic, ever. Just gradual damage that everyone attributes to time.
    - scene: You have a nickname for a coworker that is funny, accurate, and has quietly followed them through two promotions like rust. You would be startled to learn they know it exists. They have known for three years. It reached them in an afternoon.
    - outside: People leave conversations with you feeling slightly reduced and unable to file a complaint, since every individual sentence was technically fine. The effect is cumulative, like weather on a statue. Old friends have weathered into acquaintances without either of you naming the process.
  - **Mocking**
    - trait: Ridicule is your reflex response to sincerity, including your own. The earnest attempt, the heartfelt post, the brave little dream: something in you must comment, and the comment must have teeth. Everything is material. The people who love you have learned to bring their material pre-shrunk.
    - scene: Your brother announced the marathon plan and your impression of his jogging arrived within the minute, flawless and fatal. The table laughed. He ran it anyway, eight months later, and you noticed your invitation to the finish line had gone to other people.
    - outside: Around you, people announce less. The promotions get mentioned after the fact, the engagements are revealed in safe company, the drafts stay in drawers. You experience this as being spared the boring parts. It is actually the sound of doors, closing gently, everywhere.
  - **Uncontainable**
    - trait: What you know, feel, or suspect will exit your mouth, and timing has no vote. The secret, the observation, the truth the dinner was structured around avoiding: your current finds the crack. Afterward you apologize sincerely, which changes nothing about the flood next time.
    - scene: The surprise party survived until you saw the birthday girl on Tuesday, at which point your face and then your mouth handed over everything. Four weeks of planning, undone in nine seconds. You felt terrible. You also, everyone noted, felt terrible audibly and at length.
    - outside: Friends now sort information into what you can hold, a short list, and what you cannot, everything else. Being trusted less hurts you, genuinely. But the leak record reads like a tide table, and the people who love you have simply stopped building below the waterline.

---

### 水_偏印 · Water × 偏印

- **Structural interaction:** Water generating Wood same-polarity — depth as nourishing source of reach
- **Overview (k2_overview):** Your Water moves as the Alchemist: depth studying itself. Knowledge does not sit in you, it dissolves, becoming a dark solution where fields merge and strange clarities precipitate. You understand what people have not said yet. The depth is real and isolating. Surface on a schedule, carrying one crystal at a time.
- **Functional line (k2_functional):** You think in solution: everything dissolved together until the pattern precipitates.
- **Adjective chips:** catalyst Deep-diving · Tide-reading · Subtle | friction Submerged · Fixated · Unreachable
- **Ruling domain · Learning:** You learn by immersion: total absorption until a field saturates and understanding crystallizes whole. Interrupted immersion loses everything, so defend the deep dives. Come up between them.
- **Ruling domain · Intuition:** Your intuition is sonar: reading what moves beneath speech, sensing the shape of the unsaid. It is uncannily accurate about people. Verify before acting. Sonar shows shape, never color.
- **Ruling domain · Solitude:** Your solitude is the deep itself: home pressure, true thinking depth. The danger is forgetting the surface has weather worth feeling. Schedule the ascent. Bring someone a pearl.
- **Keyword ledger, catalyst:**
  - **Deep-diving**
    - trait: Your mind goes down where others skim across. A subject catches you and you vanish into it for weeks, surfacing with pearls nobody knew were down there. The depth is the method: what you understand, you understand from the floor up.
    - scene: The two-hour documentary became a four-month descent through library loans, forum archives, and one email exchange with a retired professor in Finland. When you finally explained it at dinner, simply and completely, the family sat quiet. The dive had reached the bottom of something.
    - outside: People ask you questions the way they lower buckets into wells, knowing the answer will come up cold and clear and from further down than expected. Experts double-check their own fields after talking to you. Nobody can tell where you find the time. The time is underwater.
  - **Tide-reading**
    - trait: You sense turns before they announce themselves. The market mood, the friendship cooling, the industry current reversing: something in you registers the shift while the surface still looks calm. You rarely explain the read, because the read arrives without paperwork.
    - scene: You moved your savings in September, citing a feeling with no citation. In November the sector everyone loved gave back three years of gains. Your brother-in-law asked how you knew. You said the water felt different, which was true and did not help him.
    - outside: People have learned to note your quiet exits: from stocks, from projects, from certain gatherings. The reasons surface months later wearing headlines. Being early looks like luck each individual time. Across twenty years it looks like an instrument nobody else was issued.
  - **Subtle**
    - trait: Your influence works below the surface, in word choices and timing rather than announcements. You adjust one sentence in the proposal, one name on the invite list, one pause in the conversation, and outcomes shift downstream. Watching for your fingerprints is pointless. Water does not leave any.
    - scene: The reconciliation between your two feuding friends took place, they believe, by accident, at a dinner that happened to include both, seated apart, near topics that happened to soften them. The accident took you three weeks to arrange. Neither has ever suspected a current.
    - outside: People experience your presence as things going strangely smoothly. Meetings you attend reach agreement sooner, disputes near you lose their heat, and nobody can attribute any of it. Credit slides off you like rain, which is how you prefer it. The results stay.
- **Keyword ledger, friction:**
  - **Submerged**
    - trait: You live below your own surface. The real opinions, the real feelings, the real plans sit in deep water while a calm, pleasant version of you handles the daylight. People know the surface fluently. The rest of you has not taken visitors in years.
    - scene: At your own birthday dinner, surrounded by people who love you, you had the familiar sensation of attending remotely. The laughing went fine. The thank-you speech went fine. On the drive home the quiet person in the deep finally exhaled, alone again, at last.
    - outside: The people closest to you describe a wall of perfect friendliness with something unreadable behind the glass. They stopped diving for you after enough attempts came back empty-handed. Now everyone treads water together politely, and calls it knowing each other.
  - **Fixated**
    - trait: When a subject takes you, it takes all of you. The research dive eats the evenings, the meals, the errands, and the surface duties of your life tread water while you are down there. The depth is real. So is everything floating unattended above it.
    - scene: Three weeks into the deep dive, the fridge held ketchup and little else, the inbox held forty-one unread, and you knew more about the subject than almost anyone alive. Nobody had seen you. The obsession was fed daily. Everything else in the house was not.
    - outside: People learn to date your disappearances by topic. Mention the current one and you surface, bright and full. Mention dinner and you drift back down. What you bring up from these dives is genuinely rare. What it costs is everything scheduled during them.
  - **Unreachable**
    - trait: There is a depth in you that no line reaches. Partners, parents, and two good therapists have all paid out rope and come up short. It is not defense, exactly. It is that some final fathom of you has never once felt like surfacing was worth the pressure change.
    - scene: In the middle of the hardest conversation of the marriage, the honest one, the one you both needed, your partner watched you descend mid-sentence: present, nodding, and gone. The words kept coming. The person behind them had left for somewhere deeper, and both of you knew it.
    - outside: The people who love you have made peace, separately, with loving a horizon. They get the warmth, the humor, the company, everything but the bottom. Some stopped needing it. One or two still sit on the shore some evenings, watching the water not say anything.

---

### 水_偏财 · Water × 偏财

- **Structural interaction:** Earth directing Water broadly — stability ranging across depth as distributed material
- **Overview (k2_overview):** Your Water moves as the Horizon: current that finds every sea. Opportunity reaches you through flow, conversations, crossings, currents of information arriving before the news does. Your fortune is distributive: many streams, wide deltas, wealth that moves. Dam a portion. Deltas are rich and hard to hold.
- **Functional line (k2_functional):** You move liquidly between chances, in early, out clean, rarely anchored.
- **Adjective chips:** catalyst Far-flowing · Adaptive · Magnetic | friction Up and down · Ungrounded · Everywhere at once
- **Ruling domain · Opportunity:** Your chances arrive by water: distant markets, moving information, the current nobody else has felt yet. Act while it is early. Your edge is timing, and timing evaporates.
- **Ruling domain · Ventures:** Your ventures should float: trade, media, logistics, anything that moves. Portfolios over monuments. Keep each light enough to steer and honest enough to dock anywhere.
- **Ruling domain · Father:** The father-thread flows distant or briny: a paternal figure of travel, commerce, or currents that carried him elsewhere. From him, your range. The mooring you may have to build yourself.
- **Keyword ledger, catalyst:**
  - **Far-flowing**
    - trait: Your reach extends the way rivers extend, finding distant ground that stay-at-home currents never touch. The overseas client, the cousin of a stranger, the market two time zones away: your opportunities live at range, and distance has never once read as an obstacle to you.
    - scene: The apartment in another country got rented through a chain of four people, none of whom you had met a year ago: a hostel conversation, a wedding, a group chat, a landlord. Your friends redraw the sequence on napkins and get lost. You just followed the water.
    - outside: Your address book spans cities you have not visited yet, and somehow those entries pay off too. People far away describe you as the person to know locally, a math nobody can check. When anything needs to happen at distance, yours is the number that gets called.
  - **Adaptive**
    - trait: You take the shape of whatever situation holds you, instantly and without losing yourself. The boardroom register, the market-stall banter, the funeral tone: each arrives on cue, native-sounding, no seams. Change of plans, change of country, change of fortune: you pour into the new container and proceed.
    - scene: The flight got cancelled, the conference moved online, the currency dipped, and the deal closed anyway, renegotiated from a hotel lobby in a format invented that morning. Your colleague framed the itinerary as a souvenir of chaos. You framed the signed contract.
    - outside: People stopped worrying about throwing you into new situations, since you land at operating temperature. New team, new city, new industry: within a month the locals assume you have always been there. The only constant across all your shapes, colleagues note, is the results.
  - **Magnetic**
    - trait: Opportunity and company drift toward you the way streams find the low ground. You do not chase the introduction, the invitation, the tip: they arrive, carried by people who felt like telling you first. Something about your current makes things want to join it.
    - scene: You sat alone at the airport bar for forty minutes and left with a job lead, a restaurant recommendation you later used, and the number of a supplier who now handles half your inventory. You had said maybe two hundred words. People just kept sitting down.
    - outside: Hosts seat you strategically, having noticed the effect: conversation pools around your chair, introductions form near you unprompted, and the evening’s best story usually gets told in your direction. Networks assemble themselves around you while other people are still icebreaking.
- **Keyword ledger, friction:**
  - **Up and down**
    - trait: Your fortunes rise and fall on currents you ride but never steer. The windfall month, the wipeout quarter, the rescue that arrives from nowhere, the loss that follows it out: your financial life reads like a tide chart with no moon to blame.
    - scene: March brought the surprise contract that fixed everything, and August took it away with a client bankruptcy nobody saw coming. You have been rich twice and rinsed twice in four years, and your budgeting app has given up on trend lines. It just shows waves now.
    - outside: People around you have stopped asking how business is going, because the answer has a tide in it. Family celebrates your peaks carefully, having attended the troughs. Somewhere in the up-and-down is an average that would support a calm life. Nobody, including you, has ever met it.
  - **Ungrounded**
    - trait: Nothing anchors. The city is temporary, the job is a stepping stone, the relationship is seeing where things go, and this has been true for eleven years. Your life is all current and no bed. Movement this constant looks free from the shore. From inside, lately, it just looks like water.
    - scene: The storage unit in your old city still holds boxes from the move before last, paid monthly, visited never. Its contents would furnish the settled life you keep almost starting. The invoice arrives on the third of each month, a small bill for keeping every option open and none taken.
    - outside: Old friends tell stories about you in the past tense while you are still alive and reachable, mostly because your presence never stays anywhere long enough for new chapters. You are missed in four cities, which sounds romantic. The visits stopped being planned around you years ago.
  - **Everywhere at once**
    - trait: Your energy spreads across so many channels that no single one carries real depth. The five ventures, the three cities, the dozen half-relationships: everything gets a trickle, and trickles evaporate. The delta looks impressive from above. At ground level, none of the streams can float a boat.
    - scene: Tuesday touched four projects in three currencies and finished none of anything. The calls overlapped, the follow-ups queued, and at midnight you were answering messages for the venture that earns the least, because it shouts the loudest. The one that could actually flourish got eleven minutes.
    - outside: Partners in each of your streams believe they have a quarter of you, and the math says less. They compare schedules sometimes, your various people, and find the sum does not close. Everything you touch stays alive and nothing thrives, and everyone waits for a consolidation the current keeps postponing.

---

### 水_劫财 · Water × 劫财

- **Structural interaction:** Depth meeting depth cross-polarity — intelligence competing with intelligence
- **Overview (k2_overview):** Your Water moves as the Rival: current that races current. You compete the way tides do, quietly, continuously, gaining by inches that look like accidents. Shared flows suit you: pooled funds, joint journeys, split winnings. Just remember that merged water is hard to unmix. Mark what is yours before the confluence.
- **Functional line (k2_functional):** Your energy ebbs and floods: read your own tide chart and schedule accordingly.
- **Adjective chips:** catalyst Competitive · Unafraid · Agile | friction Undermining · Envious · Slippery
- **Ruling domain · Rivalry:** Your rivalries run underwater: unspoken races, silent measurements, positions gained without visible waves. Surface one or two. A named, laughing rivalry refreshes you more than ten secret ones.
- **Ruling domain · Shared stakes:** Money and effort pool around you like watersheds: group funds, family flows, blended accounts. You track it all mentally and forgive it all eventually. Put banks around what must not flood away.
- **Ruling domain · Boldness:** Your daring is fluid: risks taken by drift and momentum more than announcement. It carries you far. Just check occasionally that the current you are riding is one you chose.
- **Keyword ledger, catalyst:**
  - **Competitive**
    - trait: Rivalry wakes you up. A competitor in the water and your stroke sharpens, your pace lifts, and the race becomes the point of the day. You measure yourself against real people, openly, and you move faster for it than any plan could make you.
    - scene: Someone at work started tracking the same clients, and your quarter, flat since spring, jumped within a month. Nothing else changed. You printed both sets of numbers and taped yours above the desk, slightly higher than theirs.
    - outside: People perform better around you and know exactly why. Teams put you next to whoever has gone comfortable, and the comfort ends within a week. Rivals call you exhausting, and most of them improved because you existed. Some even say so, at retirement parties.
  - **Unafraid**
    - trait: Your nerves hold exactly when the other side hopes they will not. The staring contest of a negotiation, the final round, the moment someone raises the stakes to scare you: your pulse spikes and your voice does not. Opponents read calm. It is actually appetite.
    - scene: The other bidder raised twice to shake you loose, and your third bid came back before the echo faded, at a number you had chosen for exactly this moment. They folded in the parking lot. You had been enjoying yourself since the second raise.
    - outside: People bring you along to hard tables the way swimmers bring a strong current. When the other side pushes, you push back in real time, and your side stops shrinking. The invitations always sound casual. The seating never is.
  - **Agile**
    - trait: Mid-contest, you change course faster than anyone can cover you. The blocked route becomes a new route, the lost argument becomes a different argument, and by the time a rival adjusts, you have moved twice more. Beating you requires predicting you. Nobody manages it consistently.
    - scene: The rival shop matched your prices on a Monday, and by Wednesday you had shifted the whole pitch to speed and service, ground they could not follow you onto. They spent a month matching a position you no longer held.
    - outside: Competitors describe planning against you with real fatigue: every counter they prepare answers your last move, never your next one. Colleagues stopped betting on where you will take things. They just watch the water for the turn, and it always comes.
- **Keyword ledger, friction:**
  - **Undermining**
    - trait: Your competitiveness works underground. The compliment with a current in it, the help that arrives slightly late, the praise for a rival delivered where it does maximum quiet damage. On the surface, all is warmth. Below, the sand is always moving under someone.
    - scene: You recommended your colleague for the committee, warmly, in the same email thread where you mentioned, in passing, their overloaded quarter. The recommendation was real. So was the sinking. They did not get it, and thanked you for trying, and you accepted the thanks.
    - outside: People near you sometimes find their footing giving way and cannot name why: the stalled promotion, the cooled friendship, the invitation that stopped coming. Nothing traces back. But older colleagues exchange a look when newcomers praise your generosity, and the look has tenure.
  - **Envious**
    - trait: Other people’s tides hurt you. The friend’s windfall, the peer’s launch, the sibling’s easy luck: each lands somewhere unprotected, and your congratulations come out slightly waterlogged. You want the good things wanted. You just want them to arrive in your harbor first.
    - scene: The group toasted the engagement and your glass rose with everyone’s, on a two-second delay that only you noticed. You were happy for them by Thursday, sincerely. The gap between the toast and Thursday is where your friendships keep taking on water.
    - outside: Friends have started softening their good news before delivering it to you, sanding the shine off, adding disclaimers about luck. They do it out of care and do not discuss it. Your reaction was never cruel. It was just visible, every time, like weather through glass.
  - **Slippery**
    - trait: Commitments run off you when conditions change, and conditions always change. The agreement meant everything at signing and less at settlement, the story adjusts to its audience, and blame finds you already moved downstream. Nothing sticks, which was once an advantage. People notice what nothing sticks to.
    - scene: The deal you shook on in April had, by June, developed nuances nobody remembered negotiating. Your version was fluid, documented nowhere, and delivered with such ease that the other side doubted their own notes. They paid the difference. They also, quietly, retired your number.
    - outside: People who have dealt with you twice bring witnesses the third time, or paper, or both. Your reputation flows ahead of you into new ventures, arriving before your charm does. The charm still works in the moment. It is the mornings after that have stopped cooperating.

---

### 水_正印 · Water × 正印

- **Structural interaction:** Water generating Wood cross-polarity — depth nourishing reach and opening form
- **Overview (k2_overview):** Your Water moves as the Sage: the source spring, nourishment that never announces itself. Care flows from you the way aquifers feed valleys, invisibly, constantly, taken for granted precisely because it never fails. You absorb others’ storms and hand back calm. Watch your own water table. Springs fail silently first.
- **Functional line (k2_functional):** You think in absorbed understanding: knowledge soaked up whole, recalled as instinct.
- **Adjective chips:** catalyst Replenishing · Serene · Receptive | friction Passive · Waterlogged · Cocooned
- **Ruling domain · Knowledge:** Your knowledge is absorbed rather than studied: understanding soaked from every source you touch. You know more than your credentials admit. Let it surface. Springs are meant to be found.
- **Ruling domain · Shelter:** Your shelter is stillness: people pour out their storms and you hand back a level surface. That absorption has a cost curve. Drain what you take in somewhere safe.
- **Ruling domain · Mother:** The mother-thread runs like groundwater: nurture that seeped in early and constant, or a dryness you learned to spring against. You became water for others either way. Refill upstream.
- **Keyword ledger, catalyst:**
  - **Replenishing**
    - trait: You restore people by being the place where nothing is asked of them. The advice waits until requested, the clock stays out of it, and the visit can be silent without being strange. Their levels rise in your company because your company charges nothing. The mechanism is shelter.
    - scene: Your brother let himself in with the spare key, sat in your kitchen for two hours, and said almost nothing. You read nearby and refilled his glass once. He left standing straighter. The visit will never be mentioned, which is exactly why it worked.
    - outside: People route their worst weeks through your place: the call made from your driveway before going home, the couch that has caught every crisis since 2015. Nobody plans it out loud. The harbor is simply known, the way water is known to be downhill.
  - **Serene**
    - trait: Your calm is deep water, not thin ice. Provocations sink into it and are absorbed, deadlines land softly on it, and chaos arrives to find no surface tension to grab. It is not detachment. Everything registers. It just registers into stillness instead of splash.
    - scene: The kitchen caught fire, briefly, at the family gathering, and your voice never left its usual register: pan lid, baking soda, window, done. The story afterward was all about the flames. You remember it as four small tasks that happened to be slightly warm.
    - outside: Storms wear themselves out on you without your doing anything. The furious arrive, talk, slow down, and leave merely tired, their weather absorbed into something deeper than it was. You never argue anyone calm. They pour it in, and the water takes it.
  - **Receptive**
    - trait: You take things in fully before responding, which has become rare enough to feel like a gift. The half-formed idea, the clumsy confession, the criticism with truth in it: all get received whole, unjudged on arrival, given somewhere calm to finish becoming what they meant.
    - scene: Your friend rehearsed the coming-out speech for weeks, and your entire response was to refill their glass and ask how long they had known. The speech had prepared for weather. Your table offered none, and the rest of the evening was just dinner, which was everything.
    - outside: People tell you things they have told no one, over ordinary kitchen tables, at ordinary volumes, startled to hear themselves. The secret is that nothing bounces off you. Whatever arrives is received at depth, held without ripples, and everyone somehow knows this before they test it.
- **Keyword ledger, friction:**
  - **Passive**
    - trait: The current decides, and you call it flexibility. The job found you, the apartment happened, the relationship drifted into being and later drifted elsewhere. Choosing feels like swimming upstream, so you float, and your life is largely the record of where the water went.
    - scene: The promotion required a one-paragraph application, and the deadline passed while the paragraph existed fully formed in your head. Someone else applied and got it. You felt something for a week, then adjusted, as you always adjust. Adjustment is the one thing you never postpone.
    - outside: The people who love you have learned that wanting things for you is a solo activity. They set up the interview, the introduction, the viewing, and watch the opening drift past unclaimed. You thank them warmly. The warmth is real. So is the drift, every time.
  - **Waterlogged**
    - trait: You absorbed everyone’s everything for years, and the saturation is starting to show. Other people’s moods soak into you and stay, their crises sit in your tissue, and lately your own feelings need a day to surface through the accumulated weather of everybody else’s.
    - scene: After your friend’s two-hour download of her divorce, she felt wonderful and you slept badly, again, carrying cargo that was never yours to store. You woke tired in a specific way that has become your baseline. Somewhere under all of it, presumably, your own mood waits.
    - outside: People treat you as infinite absorbency and you have never corrected the impression. The tears land on you at every gathering, and nobody asks what you do with the volume. Loved ones have started noticing the water line. You change the subject, which is itself the water line.
  - **Cocooned**
    - trait: Comfort has slowly sealed you in. The soft routine, the safe circle, the familiar cup in the familiar chair: each layer was reasonable, and together they have become a membrane between you and anything with weather in it. Inside is warm. Inside is also where everything now has to happen.
    - scene: The invitation to teach abroad, the one that would have thrilled you at thirty, got a full day of consideration and a gentle no. The reasons were practical and real and also, you noticed at two in the morning, identical to last year’s reasons, and the year before’s.
    - outside: Friends have stopped proposing the ambitious version of anything to you, pre-shrinking plans to fit what you will accept: nearer, shorter, softer. The cocoon is comfortable and communal now. Everyone helps maintain it, and everyone, including you, wonders occasionally what it was for.

---

### 水_正官 · Water × 正官

- **Structural interaction:** Water setting standard for Fire cross-polarity — depth asking whether warmth is sustainable
- **Overview (k2_overview):** Your Water moves as the Magistrate: navigable law, order that flows. You govern the way good rivers govern valleys, setting course without shouting, adjusting to terrain while staying a river. Your rules bend around cases and still arrive at the sea. It is the subtlest authority, and people obey it thinking they chose to.
- **Functional line (k2_functional):** Your order runs like a canal: dug once with care, then carrying everyone’s traffic for decades.
- **Adjective chips:** catalyst Clockwork · Composed · Far-sighted | friction Overcautious · Muted · On rails
- **Ruling domain · Career:** Your career advances by navigation: reading currents, timing passages, arriving at rank without visible strain. Diplomacy, coordination, the harbor-master roles. Your course is quiet and it compounds.
- **Ruling domain · Status:** Your standing spreads like watershed reputation: carried by word of mouth into places you have never been. Tend the source. Everything downstream tastes of it.
- **Ruling domain · Order:** Your order is current-shaped: rules that adapt to terrain yet keep direction. People experience your governance as ease. Document the channel, or it evaporates when you do.
- **Keyword ledger, catalyst:**
  - **Clockwork**
    - trait: Your discipline flows in built channels: the routine, the process, the documented way. Where others improvise and flood, you move the same water through the same course daily, and things downstream can rely on it. Order, in your hands, is irrigation rather than dam.
    - scene: The morning sequence has not changed in nine years: the walk, the list, the first hard task before mail. Colleagues set meetings around it like farmers around rainfall. On the rare day the sequence breaks, three people ask if everything is alright. It usually is, by ten.
    - outside: Systems you build keep working after you leave them, which people discover with surprise and gratitude. The handover document from your last role is still in use, word for word, four successors later. Somebody described inheriting your process as moving into a house with the plumbing already perfect.
  - **Composed**
    - trait: You hold your shape under pressure the way deep water holds its level: visibly, reassuringly, without effort you would admit to. The difficult meeting, the public mistake, the audit: your surface stays level, and everyone in the region borrows a little of it.
    - scene: When your name was mentioned unfairly in the all-hands, forty faces turned to watch yours. It gave them nothing: a nod, a note taken, a follow-up requested calmly afterward through channels. The retraction came within the week, and your pulse, whatever it did, did it privately.
    - outside: People bring you bad news first, specifically, because your reaction never adds to the problem. The messengers relax mid-sentence, watching it land in still water. What it costs you to keep the surface level is a figure nobody has ever seen, which is the point of paying it.
  - **Far-sighted**
    - trait: You plan at distances other people reserve for fantasy. The pension started at twenty-three, the succession question asked a decade early, the consequence spotted three moves before it forms. Present-tense people find it eerie. Future-tense people find it, eventually, in their interest.
    - scene: The clause you insisted on in 2019, the one everyone called paranoid, activated last spring and saved the partnership six figures. You accepted the apologies without ceremony. The next contract contains four such clauses. Nobody calls them paranoid now. They call them yours.
    - outside: People check plans against your horizon the way ships check charts, especially for the waters nobody has entered yet. Your predictions are unglamorous and mostly correct, delivered early enough to act on. The ones who listened compound the benefit. The ones who did not become examples.
- **Keyword ledger, friction:**
  - **Overcautious**
    - trait: Every risk gets weighed until it drowns. The checking, the double-checking, the waiting for conditions: your prudence has a thoroughness that outlives most opportunities. Nothing bad happens to you, statistically. The cost is that remarkably little of anything happens, and the ledger never shows it.
    - scene: The investment you researched for six months appreciated forty percent while the research matured. You printed the analysis anyway, complete and correct, a beautiful audit of a ship that had sailed. It sits in the drawer with its siblings. The drawer is thick with correct conclusions.
    - outside: People stopped waiting for your green light years ago, since it arrives after the intersection has cleared. They proceed, and you catch up, cautiously, once the road is proven. Your record contains no disasters and no adventures, and only one of those absences was chosen.
  - **Muted**
    - trait: Your voice arrives pre-softened, and the softening costs content. The objection becomes a question, the question becomes a pause, the pause gets read as agreement. What you actually think is audible only at very close range, and most decisions get made from further away.
    - scene: You disagreed with the plan in the meeting where it could have mattered, silently, and again in the hallway, quietly, to someone with no vote. The plan proceeded and failed roughly as you had predicted. Your prediction exists in no record. It was a very correct whisper.
    - outside: Colleagues dig up your opinions years later, over drinks: you had doubts about that? The doubts were real and beautifully reasoned and entirely internal. People would have listened, they insist. You nod, unconvinced, quietly, which is of course the whole mechanism in miniature.
  - **On rails**
    - trait: The channel decides your route. The established procedure, the way it has always flowed, the course set by someone upstream years ago: you follow it faithfully, even where the banks have visibly moved. Freedom to reroute exists on paper. The water has never once tested it.
    - scene: The weekly report you compile takes three hours and, as of the reorg two years ago, has no remaining readers. You suspected as much and confirmed it once, gently, then continued compiling. The channel was dug and the water flows. Somewhere that is still a reason.
    - outside: People watch you execute obsolete instructions with a loyalty that would be moving on a battlefield and is puzzling in an office. New options get presented to you and acknowledged and left on the bank. The current knows one direction. Everyone has stopped suggesting there are others.

---

### 水_正财 · Water × 正财

- **Structural interaction:** Earth directing Water cross-polarity — stability containing depth into productive form
- **Overview (k2_overview):** Your Water moves as the Steward: current disciplined into irrigation. You manage flows, income streams, schedules, family logistics, with the calm of a well-run canal. Nothing floods, nothing dries. It is unglamorous mastery, and every life around you runs smoother because your channels hold.
- **Functional line (k2_functional):** You administer gracefully: systems, budgets, routines that run without drought.
- **Adjective chips:** catalyst Careful · Steady-flowing · Well-prepared | friction Dammed-up · Wary · Can’t let go
- **Ruling domain · Wealth:** Your wealth is flow-managed: salaries channeled, streams diversified, leaks found early. You prosper by routing, not risking. Map the canals once a year and fortune stays irrigated.
- **Ruling domain · Savings:** You save in reservoirs: automatic diversions filling quiet pools. Name each pool’s purpose, storm, harvest, joy, and the discipline becomes drinkable.
- **Ruling domain · Steady love:** You love in reliable supply: presence delivered daily, needs anticipated, storms weathered by good infrastructure. Choose someone who notices plumbing. Then surprise the schedule occasionally. Even canals enjoy weather.
- **Keyword ledger, catalyst:**
  - **Careful**
    - trait: You handle resources the way careful water handles a landscape, never taking more than the channel can hold. The purchase gets slept on, the debt gets declined, the plan keeps a margin. Boring, people say, until their own accounts get interesting in the bad way.
    - scene: The car was chosen after the insurance quote, the reliability data, and one conversation with a mechanic you trust. It has now outlasted three of your friends’ flashier choices, at half the total cost. The spreadsheet that picked it is still on your laptop, mildly famous.
    - outside: Friends consult you before their big decisions the way travelers check the depth of a river before driving in. Your questions are unexciting and save fortunes: what does it cost per year, what happens if it breaks. Several disasters in your circle simply never happened. That was you.
  - **Steady-flowing**
    - trait: Your resources move like a reliable stream, in on schedule, out with intention, never flash-flooding. The salary lands, the transfers fire, the obligations get met a little early. Drama has no purchase on your finances, and the calm compounds as quietly as the interest.
    - scene: Rent has arrived on the first for eleven consecutive years, across three landlords, one recession, and a broken leg. The current landlord once called to check the transfer was real, so rare is the species. You are the tenant reference other applicants wish existed.
    - outside: The people downstream of you, family, dependents, one perpetually struggling friend, plan their lives around a reliability they have stopped noticing. The support just arrives, monthly, like weather in a fortunate climate. Nobody asks what maintaining a stream that steady requires. It requires everything, daily.
  - **Well-prepared**
    - trait: The future finds you already provisioned. The renewal date is in the calendar, the emergency fund holds six months, the umbrella lives in the car. Your readiness is so habitual it looks like luck: things simply never seem to catch you without the relevant item.
    - scene: When the layoffs came, your household absorbed the news with a strange calm: the fund was there, the resume was current, the numbers had been run in advance during a peaceful January. The panic that visited every other affected house found yours already interviewed and hired.
    - outside: People tease the preparations right up until they need them, at which point you become briefly, intensely popular. The jump cables, the spare charger, the printed copy: someone borrows one weekly. You have become the reason other people can afford to be spontaneous. Nobody sends a card.
- **Keyword ledger, friction:**
  - **Dammed-up**
    - trait: Your resources pool behind walls you keep raising. The money accumulates and does not move, the generosity is rationed through a narrow spillway, and downstream, things that needed watering are visibly dry. The reservoir is impressive. Reservoirs, unvisited, are just deep places holding still.
    - scene: The account crossed the threshold you once named as enough, and the threshold moved the same week, upward, as it always moves. Your niece’s tuition request took three weeks to answer and came back a loan, papered, at interest. Family dinners since have had a different acoustics.
    - outside: People stopped asking, which you registered as peace. The requests dried up, the little fundraisers route around you, and the reputation settled like silt: comfortable, careful, closed. The wealth is real and growing. What it is for remains, to everyone including you, the open question.
  - **Wary**
    - trait: Every offer arrives at your door pre-suspected. The deal has a catch, the kindness has an angle, the stranger has a reason: your default read is downstream contamination, and proof of purity is a standard almost nothing meets. You are rarely cheated. You are also rarely surprised by joy.
    - scene: The neighbor’s offer to water your plants during your trip triggered a full risk assessment: motive, key custody, precedent. You declined with thanks and paid a service. The plants did fine. The neighbor waved differently afterward, from slightly further away, permanently.
    - outside: People approach you with their cards face up and their movements slow, having learned that anything else reads as an angle. The honest ones find the screening mildly insulting and mostly stop volunteering. What gets through your filter is genuinely safe. So little gets through.
  - **Can’t let go**
    - trait: Letting go, of money, of objects, of the way Sunday is supposed to run, activates something in your grip that logic cannot pry open. The sunk cost stays sunk and held, the worn-out thing stays shelved, and your hands, at any given moment, are completely full.
    - scene: The vacation fund has existed for nine years and never once been spent, each proposed trip failing the final review at the moment of booking. The money is for vacations. The vacations are somehow never quite worth the money. The fund grows, a monument to trips unrisked.
    - outside: Prying anything from you, a concession, an old coat for the charity bag, an admission that plans changed, has a known difficulty rating among your people. They mostly stopped trying and started working around the grip. Your hands hold everything. Notably, lately, that includes very little of theirs.

---

### 水_比肩 · Water × 比肩

- **Structural interaction:** Depth amplifying depth — perceptual intelligence running without form
- **Overview (k2_overview):** Your Water moves as the Twin: a current that keeps its own channel while running beside others. You match people without merging into them, fluent in company, private in depth. Two rivers to the same sea is your model of friendship: shared direction, separate water, and no argument about whose current is whose.
- **Functional line (k2_functional):** Your energy runs in currents: even output for weeks, then a quiet season to refill the source.
- **Adjective chips:** catalyst Self-contained · Even-keeled · Independent | friction Cold-running · Isolated · Impenetrable
- **Ruling domain · Peers:** Your peers are parallel currents: fellow travelers heading the same direction by different beds. You collect companions across every landscape you cross. Keep a few for the whole length of the river, not just the pretty stretches.
- **Ruling domain · Independence:** Water independence is having your own source: income, opinions, and inner weather that no one else controls upstream. Protect the headwaters. Everything else about you can flex.
- **Ruling domain · Self-reliance:** You route around what others need rescuing from, so smoothly that nobody notices there was an obstacle. Occasionally say the obstacle out loud. Even self-sufficient rivers deserve witnesses.
- **Keyword ledger, catalyst:**
  - **Self-contained**
    - trait: You carry your own weather system. Mood, motivation, entertainment, repair: all generated onboard, no docking required. Days alone pass without friction, and company, when chosen, is a preference rather than a need. People sense the completeness and find it either restful or quietly unnerving.
    - scene: The solo trip lasted eighteen days, and the postcards home were cheerful and unnecessary. You ate well, navigated fine, and had exactly the conversations you wanted, several with strangers, none from loneliness. Friends asked if it got hard. It got, you said accurately, quiet.
    - outside: People stop worrying about you early in the acquaintance, sensing a system that maintains itself. You are nobody’s project and nobody’s dependent. The freedom this grants your relationships is enormous and mostly invisible: everyone who stays, stays for the company, not the maintenance contract.
  - **Even-keeled**
    - trait: Your levels hold. The praise does not inflate you, the setback does not sink you, and Tuesday-you is recognizably Friday-you. In a world of dramatic weather you are open water on a calm day, and people steer toward you when their own seas get theatrical.
    - scene: You received the promotion email and the rejection letter in the same afternoon, and your dinner plans survived both unchanged. Your partner, telling the story later, could not remember which arrived first. Neither, notably, could you. The pasta was good. The week continued.
    - outside: Teammates map their own volatility against your baseline, which has not moved in recorded history. In crises, the group instinctively checks your face before choosing a panic level, and your face declines to authorize one. Whole storms have been downgraded this way, repeatedly, to weather.
  - **Independent**
    - trait: You run your own race in your own lane at your own pace, and the pace is honest. Opinions get consulted and then decided past, help gets accepted without becoming structure, and your decisions, right or wrong, are recognizably yours. Ownership like that is rarer than talent.
    - scene: You moved cities without a committee, changed careers on your own research, and told everyone after the deposits were paid. The announcements were calm and finished. Family learned years ago that input windows open before decisions, briefly, and that missing them is missing them.
    - outside: People trust your choices with a specific confidence: whatever happens, you chose it, and you will handle it. Nobody hedges around you or manages your expectations. The respect is quiet and total, and it was purchased with years of never once outsourcing the blame.
- **Keyword ledger, friction:**
  - **Cold-running**
    - trait: Your warmth exists and runs deep and rarely surfaces where people can feel it. The care comes out as errands, the affection as usefulness, and the words themselves stay below. People eventually stop swimming down to check. The temperature at the surface is what they live with.
    - scene: Your partner mentioned, quietly, that you had not said anything warm in some weeks. You had fixed the brakes, renewed the insurance, and prepaid the winter heating that same month. You cited these. There was a silence in which both of you were right, and only one warm.
    - outside: People describe you as reliable first and affectionate somewhere after the pause. The love is inferred from your actions the way deep currents are inferred from instruments: real, documented, unfelt on the skin. Some loved ones adjusted. The ones who needed sun moved toward it, elsewhere.
  - **Isolated**
    - trait: Your self-sufficiency built a shoreline nobody lands on anymore. The company you technically enjoy gets postponed, the calls ring out, and the distance, initially a preference, has become the geography. You are fine, genuinely. Fine, and further out than anyone can comfortably swim.
    - scene: The last name in your call log is eleven days old and belongs to a delivery service. The weekend held reading, a long walk, good coffee, and no voices. You noticed the quiet the way you notice weather: fully, neutrally, and without doing anything about it.
    - outside: Friends debated whether to worry and settled on a rotation of light check-ins, which you answer promptly and pleasantly, closing each door as gently as it was opened. Nobody can locate a problem. There is just an ocean where a neighborhood used to be, and it is widening.
  - **Impenetrable**
    - trait: Nothing gets in past the surface. Feedback beads up and rolls off, affection finds no porous surface, and the hard conversations everyone rehearses with you simply do not land: you agree, calmly, and remain exactly as you were. The consistency is impressive. It is also the wall.
    - scene: The intervention was loving and well-prepared, three people who care, specific examples, warm intent. You listened fully, thanked them sincerely, and changed nothing, without any spite in it, because nothing had, as far as you could tell, actually touched anything. They compare notes still, baffled.
    - outside: People who love you describe conversations with you as skipping stones: beautiful contact, no entry. Over the years they have stopped throwing. What remains is pleasant and shallow by mutual, unspoken arrangement, and everyone involved calls it peace, in the tone reserved for treaties.

---

### 水_食神 · Water × 食神

- **Structural interaction:** Metal generating Water same-polarity — precision as natural source of flowing depth
- **Overview (k2_overview):** Your Water moves as the Artisan: a spring that feeds everything downstream. Your output flows, words, ideas, comfort, care, without visible effort, and people drink from it more than you notice. You nourish by permeating: the right thing said gently, the mood eased, the story that waters a dry week.
- **Functional line (k2_functional):** Your expression pours: fluent, warm, endlessly refilled. Writing and talk both come as flow.
- **Adjective chips:** catalyst Fluent · Nourishing · Easygoing | friction Drifting · Indulgent · Unmoved
- **Ruling domain · Expression:** Your expression is the stream itself: writing, conversation, comfort flowing daily. Volume is natural to you, so add channels: publish, record, send. Water that reaches others is what turns gift to harvest.
- **Ruling domain · Enjoyment:** You enjoy in gentle currents: long baths, slow music, conversation into the night. Honor these as necessities. A spring that is never let pool goes brackish.
- **Ruling domain · Children:** With the young you nourish invisibly: the listening, the softening, the words that raise them without their noticing. They will quote you for life, usually without knowing whom they are quoting.
- **Keyword ledger, catalyst:**
  - **Fluent**
    - trait: Expression comes to you the way walking comes to other people, without assembly or rehearsal. What costs everyone else three drafts costs you a breath, and the ease is invisible from inside. You genuinely do not know where the words are before they arrive. They just do.
    - scene: The toast happened because someone handed you a glass and the moment was there. There were no notes and there was no plan, and it landed so well the couple still quotes it. You forgot it by dessert, the way a river forgets water it has already carried.
    - outside: People prepare for days to do what you do between bites. They notice, too. Half the invitations you get are really requests for you to come and make the talking easy, and you have never once thought of it as work.
  - **Nourishing**
    - trait: Whatever you make leaves people fuller than it strictly had to, and that surplus is the signature. Your output feeds: conversation, cooking, company, all of it lands as sustenance rather than display. Feeding people is simply the shape your talent takes, in every medium.
    - scene: They arrive wound tight, sit down at your kitchen table, and something loosens over the second hour. Soup helps, and so does the way you ask questions. By the door they are lighter and cannot name what happened. You can. It happens every time.
    - outside: Nobody leaves your table the way they arrived, and word of that travels. You are the number people call on the bad night, the kitchen they route the heartbroken friend toward. It is a strange kind of fame, warm and unlisted, and you earned it a bowl at a time.
  - **Easygoing**
    - trait: Your tempo stays loose where other people clench, which is temperament rather than effort. Pressure has never found your dial, and around you it loses track of everyone else’s too. Ease like yours cannot be faked under load. Its realness is what makes it contagious.
    - scene: The flight is cancelled, the line is furious, and somehow you are at the counter making the gate agent laugh while the rebooking happens. Nothing about it was strategy. Loose is just the setting you run at, and pressure has never found the dial.
    - outside: Tense people collect near you without being invited, the way cold hands find a warm mug. Whatever they came in carrying weighs less within the hour. You rarely notice the effect, which is precisely why it works, and precisely why nobody believes you when you shrug.
- **Keyword ledger, friction:**
  - **Drifting**
    - trait: Following the day’s current instead of steering it is a habit now, whatever it started as. The Tuesday you set aside for writing became errands, a nap, and a show, and at no point did anyone decide that. The not-deciding is the whole mechanism.
    - scene: The Tuesday reserved for writing turned into a pharmacy run, then a nap, then just one episode. Each step was reasonable. By eleven at night the day had been fully spent and nobody had ever actually spent it, which is how most of your Tuesdays go missing.
    - outside: Anyone auditing your week would find no disasters, just a soft trail of almosts. Plans that dissolved politely. People stopped expecting the novel, the channel, the business, and you noticed them stopping, and even that noticing drifted off downstream with the rest.
  - **Indulgent**
    - trait: Treating yourself is your first answer to most feelings, and by now the treats have a routing system. Stress orders dessert, boredom opens the app, sadness books the trip. The card statement reads like a mood diary, and the moods are winning.
    - scene: Last month’s card statement, read honestly, is a diary. The dessert on the stressful ninth, the flights browsed at midnight on the lonely seventeenth, the gadget that arrived after the argument. Every feeling got fed. The one thing still hungry at the end was the work.
    - outside: You are famously good to yourself, and friends joke about it right up to the line where it stops being funny. Comfort was supposed to be the refill between efforts. Lately nobody, including you, can point to the effort it is refilling for.
  - **Unmoved**
    - trait: It takes a great deal to move you, and less would honestly serve you better. The deadline, the news, the argument all get the same shrug and the same tea. Calm this deep is a talent right up until it becomes a moat.
    - scene: The deadline got a shrug and a fresh cup of tea. So did the news, and the argument, and the email marked urgent twice. Then one Thursday everything landed at once, and the calm you had been so proud of turned out to be a backlog.
    - outside: People have stopped bringing you their urgency, since it comes back to them unshaken and slightly damp. What reads as depth is sometimes just distance. The things that should reach you do not, and downstream of that, neither do the people attached to them.
