# No chart in this package

This is a batch package (REA_18 §5): the cells are written for every chart with a Wood core, not for one chart. No percentage, no band and no state of a particular chart may appear in any value; the engine owns the numbers. Each skeleton's facts carry the pair law and the band table facts for its poles (REA_02 §5c): which band's case each pole is, the remedy verb, and the cure set on the friction pole.

Manifest: `batch-2-wood-core.json` (copied into this package as `manifest.json`).
