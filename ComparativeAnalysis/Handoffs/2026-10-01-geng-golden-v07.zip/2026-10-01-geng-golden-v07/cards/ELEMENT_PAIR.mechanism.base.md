# ELEMENT_PAIR.mechanism.base

_Prompt file (data). Edit here; the harness reads this file. Born 2026-09-21 from REA_17 v0.3 §3; the source rulings are cited at the bottom of the card. Where this file and a source document disagree, the source wins and this file is corrected._

| | |
|---|---|
| **Field** | `ELEMENT_PAIR.mechanism.base` |
| **Axis** | ELEMENT_PAIR |
| **Header** | energy page detail · classical (ledger) · fully third person · 45–75 words · LOCKED |
| **Harness field key** | ELEMENT_PAIR.mechanism.base |
| **Status** | LOCKED |

## The card

- Construct: the two-energy chemistry only: what 生 or 克 means in this pair, physically, grounded in the 相生/相克 doctrine (白虎通 / 五行大義 lineage), rendered poetically.
- Reasoning chain: the law sentence and its image line (Earth feeds Metal: ore grows in the mountain) → what physically happens between these two materials, one word of the pair's chemistry, the energy's or the core's material, somewhere in the field (an arena noun, the material's verb, or either element as a common noun: "Metal is born of earth", "water is metal's child") → why that seats the energy as this function → stay in the material world.
- Style: no "you", no function claim (the thumbnail and titles teach those), no persona; poetic and descriptive; "the old texts say" is allowed as texture.
- Checks: 45–75w, no second person, zero dashes, one word of the pair's chemistry, the energy's or the core's material, in the field (an arena noun, the material's verb, or either element as a common noun, matched as word stems: the harness blocks, owner 2026-09-30, the list widened the same day), the repetition law blocks on this cell (no four-word run shared with the turns, definitions or advice).
- Exemplar (金_土): "Metal is born of earth, the old texts say: it lies in the mountain, gathered in stone, grown by slow pressure and the moisture of deep ground. Nothing hurries it. The mountain holds the ore for ages before any edge is struck from it, and every blade remembers the patience of the rock that made it."
- Sources: REA_16 §2c (v2 register, 2026-09-02); REA_02 §5d; the 金_水 template construct note.

## Assembly

PROMPT = `00_MASTER_PROMPT.md` + `01_INPUT_PACK.md` (the axis pack, filled from the station with the target field redacted) + this card + the task line the harness writes for the cell (`ComparativeAnalysis/Prompts/assemble.mjs`). The gate (`validate.mjs`) enforces the checks above plus the register rules in `02_RULES_REGISTER.md`.

## Iteration log

| Date | Change | Ruling |
|---|---|---|
| 2026-09-21 | Born from REA_17 v0.3 | compilation, no new rule |
| 2026-09-30 | The energy's material named anywhere in the field (E7, blocking); no shipping base fails it under the whole-field rule | owner 2026-09-30, Q1c of the v0.6 questionnaire (REA_16 §6) |
| 2026-09-30 | E7 widened: one word of the pair's chemistry, the energy's or the core's material, matched as word stems; no shipping base fails it | owner 2026-09-30, row 7 of the v0.6 review rulings (`backlog/2026-09-30_v06-review-rulings.md`; the review samples §7) |
